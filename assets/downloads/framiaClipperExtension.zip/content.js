(function() {
  "use strict";
  const FRAMIA_ORIGIN = "https://framia.pro";
  const COLLECT_MIN_SIZE = 80;
  const COLLECT_MIN_RENDERED_SIZE = 180;
  const COLLECT_MIN_RENDERED_PIXELS = 32400;
  const HOVER_DISABLED_STORAGE_PREFIX = "framia_hover_disabled_";
  function hoverDisabledStorageKey(hostname) {
    return `${HOVER_DISABLED_STORAGE_PREFIX}${hostname}`;
  }
  function isFramiaHostname(hostname) {
    return hostname === "framia.pro" || hostname.endsWith(".framia.pro");
  }
  const OPEN_IN_INSTRUCTION = `Please recreate this image with high fidelity. Pay close attention to:
- Overall composition, layout, and framing
- Subject positioning, scale, and spatial relationships
- Color palette, lighting, and atmosphere
- Textures, materials, and surface details
- Any text, logos, or graphic elements
- Style, mood, and artistic treatment
Preserve all visual characteristics as accurately as possible.
---

`;
  const UTM_PARAMS = {
    source: "chrome_extension",
    medium: "extension"
  };
  const VARIATION_PROMPTS = {
    zh: {
      "vary-strong": "基于这张图片帮我生成3种变体",
      shuffle: "基于这张图片帮我重新排版"
    },
    en: {
      "vary-strong": "Generate 3 variations based on this image",
      shuffle: "Re-layout this image"
    }
  };
  function extractPageImages() {
    const seen = /* @__PURE__ */ new Set();
    const images = [];
    const add = (url, fromEl) => {
      if (!url || url.startsWith("data:") || seen.has(url)) return;
      try {
        const host = new URL(url).hostname;
        if (host.endsWith("framia.pro")) return;
      } catch {
        return;
      }
      seen.add(url);
      images.push({ url, htmlElement: fromEl });
    };
    document.querySelectorAll("img").forEach((img) => {
      if (img.naturalWidth >= COLLECT_MIN_SIZE && img.naturalHeight >= COLLECT_MIN_SIZE) {
        const src = img.currentSrc || img.src;
        if (src) add(src, img);
      }
    });
    document.querySelectorAll("picture source").forEach((source) => {
      const srcset = source.srcset;
      if (srcset) {
        srcset.split(",").map((s) => s.trim().split(/\s+/)[0]).filter(Boolean).forEach((url) => add(url));
      }
    });
    document.querySelectorAll("*").forEach((el) => {
      const style = window.getComputedStyle(el);
      const bg = style.backgroundImage;
      if (bg && bg !== "none") {
        const matches = bg.matchAll(/url\(['"]?(.*?)['"]?\)/g);
        for (const m of matches) {
          if (m[1] && !m[1].startsWith("data:")) add(m[1], el);
        }
      }
    });
    document.querySelectorAll("video[poster]").forEach((video) => {
      if (video.poster) add(video.poster, video);
    });
    return images;
  }
  const DEFAULT_LOCALE = "zh";
  function runtime() {
    const r = globalThis.__framia_i18n__;
    if (!r) {
      throw new Error(
        "[Framia] i18n runtime not loaded (expected globalThis.__framia_i18n__)."
      );
    }
    return r;
  }
  function getLocale() {
    return runtime().getLocale();
  }
  function t(key, locale) {
    return runtime().t(key, locale);
  }
  function format(str, vars) {
    return runtime().format(str, vars);
  }
  function onLocaleChange(cb) {
    return runtime().onLocaleChange(cb);
  }
  let cachedAuthState = false;
  const onLogoutListeners = [];
  void chrome.storage.local.get("authToken").then((r) => {
    cachedAuthState = !!r["authToken"];
  }).catch(() => {
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes["authToken"]) return;
    const next = !!changes["authToken"].newValue;
    const wasAuth = cachedAuthState;
    cachedAuthState = next;
    if (wasAuth && !next) {
      for (const cb of onLogoutListeners) {
        try {
          cb();
        } catch {
        }
      }
    }
  });
  function isAuthenticatedSync() {
    return cachedAuthState;
  }
  function onLogout(cb) {
    onLogoutListeners.push(cb);
    return () => {
      const idx = onLogoutListeners.indexOf(cb);
      if (idx >= 0) onLogoutListeners.splice(idx, 1);
    };
  }
  function showToast(message, isError = false) {
    const existing = document.querySelector(".framia-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.className = `framia-toast${isError ? " framia-toast-error" : ""}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add("framia-toast-show"), 10);
    setTimeout(() => {
      toast.classList.remove("framia-toast-show");
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }
  function formatPromptError(resp, locale) {
    const base = resp.error === "NOT_AUTHENTICATED" ? t("toast.not_authenticated", locale) : resp.error === "RATE_LIMITED" ? format(t("toast.extract_rate_limited", locale), { limit: resp.limit ?? 30 }) : resp.error === "IMAGE_TOO_SMALL" ? t("toast.extract_image_too_small", locale) : resp.error === "IMAGE_TOO_LARGE" ? t("toast.extract_image_too_large", locale) : resp.error === "INVALID_IMAGE_FORMAT" ? t("toast.extract_invalid_image", locale) : resp.message ? `${t("toast.extract_failed", locale)}: ${resp.message}` : `${t("toast.extract_failed", locale)}: ${resp.error ?? "UNKNOWN"}`;
    return resp.requestId ? `${base}
${format(t("toast.extract_request_id", locale), {
      requestId: resp.requestId
    })}` : base;
  }
  const CAMPAIGN_TO_EVENT = {
    login: "extension_open_login",
    open_in: "extension_open_in_framia",
    agent_submit: "extension_agent_submit",
    extract_prompt: "extension_extract_prompt",
    import_image: "extension_import_image"
  };
  function buildFramiaUrl(path = "/", campaign, extraParams = {}) {
    const url = new URL(path, FRAMIA_ORIGIN);
    url.searchParams.set("utm_source", UTM_PARAMS.source);
    url.searchParams.set("utm_medium", UTM_PARAMS.medium);
    url.searchParams.set("utm_campaign", campaign);
    url.searchParams.set("utm_content", CAMPAIGN_TO_EVENT[campaign]);
    Object.entries(extraParams).forEach(([key, value]) => {
      if (value === void 0) return;
      url.searchParams.set(key, String(value));
    });
    return url.toString();
  }
  let currentLocale$3 = DEFAULT_LOCALE;
  void getLocale().then((locale) => {
    currentLocale$3 = locale;
  });
  onLocaleChange((locale) => {
    currentLocale$3 = locale;
  });
  const FRAMIA_PRODUCT = {
    name: "Framia",
    url: (src) => buildFramiaUrl("/", "open_in", { import: src }),
    // The SVG keeps crisp edges inside the popover's rendered size on
    // HiDPI displays; the older PNG icon rasterized at a fixed size.
    iconUrl: chrome.runtime.getURL("icons/icon.svg")
  };
  function buildOpenInSection(ctx) {
    const section = document.createElement("div");
    section.className = "framia-open-in-section framia-open-in-section-single";
    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "framia-open-in-trigger";
    const label = document.createElement("span");
    label.className = "framia-open-in-label";
    label.textContent = t("popover.open_in_label", currentLocale$3);
    const productWrap = document.createElement("span");
    productWrap.className = "framia-open-in-name framia-open-in-name-active";
    const icon = document.createElement("img");
    icon.className = "framia-open-in-product-icon is-colored";
    icon.src = FRAMIA_PRODUCT.iconUrl;
    icon.alt = FRAMIA_PRODUCT.name;
    const productLabel = document.createElement("span");
    productLabel.className = "framia-open-in-product-label";
    productLabel.textContent = FRAMIA_PRODUCT.name;
    const suffix = document.createElement("span");
    suffix.className = "framia-open-in-suffix";
    suffix.textContent = t("popover.open_in_suffix", currentLocale$3);
    productWrap.append(icon, productLabel);
    trigger.append(label, productWrap, suffix);
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      void handleSelect(FRAMIA_PRODUCT, ctx);
    });
    const copyOnly = document.createElement("span");
    copyOnly.className = "framia-open-in-copy-only";
    copyOnly.textContent = t("popover.copy_text_only", currentLocale$3);
    section.append(trigger, copyOnly);
    return section;
  }
  async function handleSelect(product, ctx) {
    const src = ctx.getImageSrc();
    if (!src) {
      showToast(t("toast.no_image", currentLocale$3), true);
      return;
    }
    const prompt = ctx.getPrompt();
    const clipText = prompt ? OPEN_IN_INSTRUCTION + prompt : "";
    try {
      if (clipText) {
        await navigator.clipboard.writeText(clipText);
      }
    } catch {
    }
    window.open(product.url(src, prompt), "_blank", "noopener");
    showToast(format(t("toast.open_in", currentLocale$3), { name: product.name }));
  }
  const SHOW_CLASS = "framia-custom-generate-show";
  let popover = null;
  let currentCallback = null;
  let currentAnchor = null;
  let listenersBound = false;
  let activeLocale = DEFAULT_LOCALE;
  void getLocale().then((locale) => {
    activeLocale = locale;
    if (popover) applyI18n$1(popover, activeLocale);
  });
  onLocaleChange((locale) => {
    activeLocale = locale;
    if (popover) applyI18n$1(popover, activeLocale);
  });
  function showCustomGeneratePopover(anchor, onSubmit, locale = activeLocale) {
    closePromptPopover();
    activeLocale = locale;
    currentCallback = onSubmit;
    currentAnchor = anchor;
    if (!popover) {
      popover = buildPopover();
      document.body.appendChild(popover);
    }
    applyI18n$1(popover, activeLocale);
    popover.classList.add(SHOW_CLASS);
    positionPopover(popover, anchor);
    if (!listenersBound) {
      listenersBound = true;
      window.addEventListener("resize", () => {
        if (popover && currentAnchor && popover.classList.contains(SHOW_CLASS)) {
          positionPopover(popover, currentAnchor);
        }
      });
      window.addEventListener(
        "scroll",
        () => {
          if (popover && currentAnchor && popover.classList.contains(SHOW_CLASS)) {
            positionPopover(popover, currentAnchor);
          }
        },
        { passive: true, capture: true }
      );
    }
    const textarea = popover.querySelector(
      ".framia-custom-generate-textarea"
    );
    if (textarea) {
      textarea.value = "";
      textarea.focus();
    }
  }
  function closeCustomGeneratePopover() {
    popover?.classList.remove(SHOW_CLASS);
  }
  function buildPopover() {
    const el = document.createElement("div");
    el.className = "framia-custom-generate";
    el.innerHTML = `
        <div class="framia-custom-generate-header">
            <div class="framia-custom-generate-title"></div>
            <button type="button" class="framia-custom-generate-close" aria-label="">×</button>
        </div>
        <div class="framia-custom-generate-hint"></div>
        <textarea
            class="framia-custom-generate-textarea"
            rows="4"
        ></textarea>
        <div class="framia-custom-generate-footer">
            <button type="button" class="framia-custom-generate-submit"></button>
        </div>
    `;
    el.querySelector(".framia-custom-generate-close")?.addEventListener("click", () => {
      closeCustomGeneratePopover();
    });
    el.querySelector(".framia-custom-generate-submit")?.addEventListener("click", () => {
      submit(el);
    });
    el.querySelector(".framia-custom-generate-textarea")?.addEventListener(
      "keydown",
      (e) => {
        if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          submit(el);
        }
        if (e.key === "Escape") {
          closeCustomGeneratePopover();
        }
      }
    );
    document.addEventListener("mousedown", (e) => {
      if (!popover) return;
      if (!popover.classList.contains(SHOW_CLASS)) return;
      if (!popover.contains(e.target)) closeCustomGeneratePopover();
    });
    return el;
  }
  function applyI18n$1(el, locale) {
    const title = el.querySelector(".framia-custom-generate-title");
    if (title) title.textContent = t("custom.title", locale);
    const close = el.querySelector(".framia-custom-generate-close");
    if (close) close.setAttribute("aria-label", t("custom.close", locale));
    const hint = el.querySelector(".framia-custom-generate-hint");
    if (hint) hint.textContent = t("custom.hint", locale);
    const textarea = el.querySelector(
      ".framia-custom-generate-textarea"
    );
    if (textarea) textarea.placeholder = t("custom.placeholder", locale);
    const submitBtn = el.querySelector(".framia-custom-generate-submit");
    if (submitBtn) submitBtn.textContent = t("custom.submit", locale);
  }
  function submit(el) {
    const textarea = el.querySelector(".framia-custom-generate-textarea");
    const text = textarea?.value.trim() ?? "";
    if (!text) return;
    currentCallback?.(text);
    closeCustomGeneratePopover();
  }
  const TAB_TO_FIELD = {
    json: "json",
    cn: "chinese",
    en: "english"
  };
  let state = null;
  let currentLocale$2 = DEFAULT_LOCALE;
  void getLocale().then((locale) => {
    currentLocale$2 = locale;
    if (state) {
      applyI18n(state.el, currentLocale$2);
      populate(state);
    }
  });
  onLocaleChange((locale) => {
    currentLocale$2 = locale;
    if (state) {
      applyI18n(state.el, currentLocale$2);
      populate(state);
    }
  });
  const promptCache = /* @__PURE__ */ new Map();
  function getCachedPrompt(imageSrc) {
    return promptCache.get(imageSrc);
  }
  function showLoadingPromptPopover(anchor, imageSrc) {
    closeCustomGeneratePopover();
    const s = ensurePopover();
    if (s.editing) setEditMode(s, false);
    s.imageSrc = imageSrc;
    s.extraction = null;
    s.anchor = anchor;
    setLoading(s, true);
    populate(s);
    reveal(s);
    s.reposition();
  }
  function showCachedPromptPopover(anchor, imageSrc, extraction) {
    closeCustomGeneratePopover();
    const s = ensurePopover();
    if (s.editing) setEditMode(s, false);
    s.imageSrc = imageSrc;
    s.extraction = extraction;
    s.anchor = anchor;
    setLoading(s, false);
    setError(s, false);
    populate(s);
    reveal(s);
    s.reposition();
  }
  function updatePromptPopover(extraction) {
    if (!state) return;
    if (state.editing) setEditMode(state, false);
    state.extraction = extraction;
    if (state.imageSrc) promptCache.set(state.imageSrc, extraction);
    setLoading(state, false);
    setError(state, false);
    populate(state);
  }
  function showPromptError(message) {
    if (!state) return;
    if (state.editing) setEditMode(state, false);
    setLoading(state, false);
    setError(state, true);
    const panels = state.el.querySelectorAll(".framia-prompt-tab-panel");
    panels.forEach((panel) => {
      panel.textContent = message;
    });
  }
  function closePromptPopover() {
    if (!state) return;
    if (state.editing) setEditMode(state, false);
    state.el.classList.remove("framia-prompt-popover-show");
  }
  function ensurePopover() {
    if (state) return state;
    const el = document.createElement("div");
    el.className = "framia-prompt-popover";
    el.innerHTML = `
        <div class="framia-prompt-popover-header">
            <div class="framia-prompt-popover-title"></div>
            <button type="button" class="framia-prompt-popover-close" aria-label="">×</button>
        </div>
        <div class="framia-prompt-tabs">
            <button type="button" class="framia-prompt-tab is-active" data-tab="json"></button>
            <button type="button" class="framia-prompt-tab" data-tab="cn"></button>
            <button type="button" class="framia-prompt-tab" data-tab="en"></button>
        </div>
        <div class="framia-prompt-toolbar">
            <button type="button" class="framia-prompt-edit-btn"></button>
        </div>
        <div class="framia-prompt-tab-panels framia-scroll-area">
            <div class="framia-prompt-tab-panel is-active" data-panel="json"></div>
            <div class="framia-prompt-tab-panel" data-panel="cn"></div>
            <div class="framia-prompt-tab-panel" data-panel="en"></div>
        </div>
    `;
    document.body.appendChild(el);
    state = {
      el,
      imageSrc: "",
      extraction: null,
      activeTab: "json",
      anchor: null,
      editing: false,
      reposition: () => {
        if (state?.anchor) positionPopover(state.el, state.anchor);
      }
    };
    window.addEventListener("resize", () => state?.reposition());
    window.addEventListener("scroll", () => state?.reposition(), { passive: true, capture: true });
    el.querySelectorAll(".framia-prompt-tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        const key = tab.dataset["tab"];
        if (!key || !state) return;
        if (state.editing) setEditMode(state, false);
        setActiveTab(state, key);
      });
    });
    el.querySelector(".framia-prompt-popover-close")?.addEventListener("click", () => {
      closePromptPopover();
    });
    el.querySelector(".framia-prompt-edit-btn")?.addEventListener(
      "click",
      (e) => {
        e.stopPropagation();
        if (!state) return;
        setEditMode(state, !state.editing);
      }
    );
    const openIn = buildOpenInSection({
      getImageSrc: () => state?.imageSrc ?? null,
      getPrompt: () => getActivePanelText(state)
    });
    el.appendChild(openIn);
    document.addEventListener("mousedown", (e) => {
      if (!state) return;
      if (!state.el.classList.contains("framia-prompt-popover-show")) return;
      const target = e.target;
      if (!target) return;
      if (!state.el.contains(target)) {
        closePromptPopover();
        return;
      }
      if (state.editing && target instanceof Element) {
        const stayEditing = !!target.closest(".framia-prompt-tab-panel.is-active") || !!target.closest(".framia-prompt-edit-btn");
        if (!stayEditing) setEditMode(state, false);
      }
    });
    applyI18n(el, currentLocale$2);
    return state;
  }
  function applyI18n(el, locale) {
    const title = el.querySelector(".framia-prompt-popover-title");
    if (title) title.textContent = t("popover.title", locale);
    const close = el.querySelector(".framia-prompt-popover-close");
    if (close) close.setAttribute("aria-label", t("popover.close", locale));
    const tabs = el.querySelectorAll(".framia-prompt-tab");
    tabs.forEach((tab) => {
      const key = tab.dataset["tab"];
      if (!key) return;
      tab.textContent = key === "json" ? t("popover.tab_json", locale) : key === "cn" ? t("popover.tab_zh", locale) : t("popover.tab_en", locale);
    });
    const editBtn = el.querySelector(".framia-prompt-edit-btn");
    if (editBtn) {
      const editing = state?.editing ?? false;
      editBtn.textContent = t(editing ? "popover.done" : "popover.edit", locale);
    }
    const openInLabel = el.querySelector(".framia-open-in-label");
    if (openInLabel) openInLabel.textContent = t("popover.open_in_label", locale);
    const openInSuffix = el.querySelector(".framia-open-in-suffix");
    if (openInSuffix) openInSuffix.textContent = t("popover.open_in_suffix", locale);
    const copyOnly = el.querySelector(".framia-open-in-copy-only");
    if (copyOnly) copyOnly.textContent = t("popover.copy_text_only", locale);
  }
  function setActiveTab(s, key) {
    s.activeTab = key;
    s.el.querySelectorAll(".framia-prompt-tab").forEach((tab) => {
      tab.classList.toggle("is-active", tab.dataset["tab"] === key);
    });
    s.el.querySelectorAll(".framia-prompt-tab-panel").forEach((panel) => {
      panel.classList.toggle("is-active", panel.dataset["panel"] === key);
    });
  }
  function setEditMode(s, on) {
    if (s.editing === on) return;
    if (!on) {
      commitActivePanel(s);
    }
    s.editing = on;
    const active = s.el.querySelector(
      `.framia-prompt-tab-panel[data-panel="${s.activeTab}"]`
    );
    if (active) {
      if (on) {
        active.setAttribute("contenteditable", "plaintext-only");
        active.classList.add("is-editing");
        requestAnimationFrame(() => {
          active.focus();
          placeCaretAtEnd(active);
        });
      } else {
        active.removeAttribute("contenteditable");
        active.classList.remove("is-editing");
        populatePanel(s, active, s.activeTab);
      }
    }
    refreshEditButtonLabel(s);
  }
  function commitActivePanel(s) {
    if (!s.extraction) return;
    const text = getActivePanelText(s);
    const field = TAB_TO_FIELD[s.activeTab];
    s.extraction[field] = text || null;
    if (s.imageSrc) promptCache.set(s.imageSrc, s.extraction);
  }
  function refreshEditButtonLabel(s) {
    const editBtn = s.el.querySelector(".framia-prompt-edit-btn");
    if (!editBtn) return;
    editBtn.textContent = t(s.editing ? "popover.done" : "popover.edit", currentLocale$2);
    editBtn.classList.toggle("is-active", s.editing);
  }
  function placeCaretAtEnd(el) {
    const sel = window.getSelection();
    if (!sel) return;
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    sel.removeAllRanges();
    sel.addRange(range);
  }
  function populate(s) {
    s.el.querySelectorAll(".framia-prompt-tab-panel").forEach((panel) => {
      const key = panel.dataset["panel"];
      if (!key) return;
      populatePanel(s, panel, key);
    });
  }
  function populatePanel(s, panel, key) {
    if (!s.extraction) {
      panel.textContent = t("popover.loading", currentLocale$2);
      return;
    }
    const field = TAB_TO_FIELD[key];
    const value = s.extraction[field];
    if (typeof value !== "string" || !value) {
      panel.textContent = t("popover.empty", currentLocale$2);
      return;
    }
    panel.textContent = formatPanelText(key, value);
  }
  function formatPanelText(key, raw) {
    if (key !== "json") return raw;
    const trimmed = raw.trim();
    if (!trimmed) return raw;
    try {
      const parsed = JSON.parse(trimmed);
      return JSON.stringify(parsed, null, 2);
    } catch {
      return raw;
    }
  }
  function getActivePanelText(s) {
    const panel = s.el.querySelector(
      `.framia-prompt-tab-panel[data-panel="${s.activeTab}"]`
    );
    if (!panel) return "";
    return (panel.innerText ?? panel.textContent ?? "").trim();
  }
  function setLoading(s, loading) {
    s.el.classList.toggle("framia-prompt-popover-loading", loading);
  }
  function setError(s, error) {
    s.el.classList.toggle("framia-prompt-popover-error", error);
  }
  function reveal(s) {
    s.el.classList.add("framia-prompt-popover-show");
  }
  function positionPopover(el, anchor) {
    const margin = 12;
    const gap = 10;
    const ar = anchor.getBoundingClientRect();
    const w = el.offsetWidth || 380;
    const h = el.offsetHeight || 200;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (ar.width === 0 && ar.height === 0 && ar.top === 0 && ar.left === 0) {
      el.style.top = `${Math.max(margin, (vh - h) / 2)}px`;
      el.style.left = `${Math.max(margin, (vw - w) / 2)}px`;
      return;
    }
    const spaceRight = vw - ar.right;
    const spaceLeft = ar.left;
    let left;
    if (spaceRight >= w + gap + margin) {
      left = ar.right + gap;
    } else if (spaceLeft >= w + gap + margin) {
      left = ar.left - w - gap;
    } else {
      left = spaceRight >= spaceLeft ? Math.min(ar.right + gap, vw - margin - w) : Math.max(margin, ar.left - w - gap);
    }
    if (left < margin) left = margin;
    if (left + w > vw - margin) left = vw - margin - w;
    let top = ar.top;
    if (top + h > vh - margin) top = vh - margin - h;
    if (top < margin) top = margin;
    el.style.top = `${top}px`;
    el.style.left = `${left}px`;
  }
  const AUTHED_MENU_ITEMS = [
    {
      id: "extract-prompt",
      labelKey: "menu.extract_prompt",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`
    },
    {
      id: "import-framia",
      labelKey: "menu.import_to_project",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>`
    },
    {
      id: "vary-strong",
      labelKey: "menu.generate_variations",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/></svg>`
    },
    {
      id: "shuffle",
      labelKey: "menu.re_layout",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>`
    },
    {
      id: "custom-generate",
      labelKey: "menu.custom",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>`
    }
  ];
  const GUEST_MENU_ITEMS = [
    {
      id: "open-login",
      labelKey: "menu.please_login",
      icon: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>`
    }
  ];
  const MENU_CLASS = "framia-collect-menu";
  const MENU_SHOW_CLASS = "framia-collect-menu-show";
  const MENU_ITEM_CLASS = "framia-collect-menu-item";
  const ICON_CLASS = "framia-menu-icon";
  const LABEL_CLASS = "framia-menu-label";
  const CLOSE_BTN_CLASS = "framia-menu-close-btn";
  const HIDE_DELAY_MS = 350;
  const POSITION_GAP_PX = 8;
  const DISMISS_SUPPRESS_MS = 5e3;
  const HOVER_THROTTLE_MS = 50;
  let hoverThrottleTimer = null;
  let currentLocale$1 = DEFAULT_LOCALE;
  let menuEl = null;
  let anchorImg = null;
  let hideTimer = null;
  let rafToken = 0;
  let initialized$1 = false;
  const suppressedUntil = /* @__PURE__ */ new WeakMap();
  let siteHoverDisabled = false;
  async function loadSiteHoverSetting() {
    try {
      const key = hoverDisabledStorageKey(window.location.hostname);
      const stored = await chrome.storage.local.get(key);
      siteHoverDisabled = Boolean(stored[key]);
    } catch (err) {
      console.debug("[Framia] failed to load site hover setting:", err);
    }
  }
  function listenSiteHoverSetting() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        const key = hoverDisabledStorageKey(window.location.hostname);
        if (key in changes) {
          siteHoverDisabled = Boolean(changes[key]?.newValue);
          if (siteHoverDisabled) hideMenuImmediate();
        }
      });
    } catch (err) {
      console.debug("[Framia] failed to subscribe site hover setting:", err);
    }
  }
  void getLocale().then((locale) => {
    currentLocale$1 = locale;
    if (menuEl) refreshMenuLabels();
  });
  onLocaleChange((locale) => {
    currentLocale$1 = locale;
    if (menuEl) refreshMenuLabels();
  });
  function initHoverMenu() {
    if (initialized$1) return;
    initialized$1 = true;
    if (isFramiaHostname(window.location.hostname)) return;
    void loadSiteHoverSetting();
    listenSiteHoverSetting();
    document.addEventListener("mouseover", handleMouseOver, true);
    document.addEventListener("mouseout", handleMouseOut, true);
    window.addEventListener("scroll", scheduleReposition, { passive: true, capture: true });
    window.addEventListener("resize", scheduleReposition, { passive: true });
    onLogout(() => {
      if (anchorImg) {
        const el = ensureMenu(currentAuthMode());
        repositionTo(anchorImg, el);
        el.classList.add(MENU_SHOW_CLASS);
      } else if (menuEl) {
        rebuildMenu("guest");
      }
    });
  }
  function currentAuthMode() {
    return isAuthenticatedSync() ? "authed" : "guest";
  }
  function ensureMenu(mode) {
    if (menuEl && menuEl.dataset["authMode"] === mode) return menuEl;
    return rebuildMenu(mode);
  }
  function rebuildMenu(mode) {
    if (menuEl) {
      menuEl.remove();
      menuEl = null;
    }
    const el = document.createElement("div");
    el.className = MENU_CLASS;
    el.dataset["authMode"] = mode;
    const items = mode === "authed" ? AUTHED_MENU_ITEMS : GUEST_MENU_ITEMS;
    items.forEach(({ id, labelKey, icon }) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = MENU_ITEM_CLASS;
      btn.dataset["action"] = id;
      btn.dataset["labelKey"] = labelKey;
      const iconSpan = document.createElement("span");
      iconSpan.className = ICON_CLASS;
      iconSpan.setAttribute("aria-hidden", "true");
      iconSpan.innerHTML = icon;
      const labelSpan = document.createElement("span");
      labelSpan.className = LABEL_CLASS;
      labelSpan.textContent = t(labelKey, currentLocale$1);
      btn.append(iconSpan, labelSpan);
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        void handleMenuAction(id);
      });
      el.appendChild(btn);
    });
    const closeBtn2 = document.createElement("button");
    closeBtn2.type = "button";
    closeBtn2.className = CLOSE_BTN_CLASS;
    closeBtn2.setAttribute("aria-label", t("popover.close", currentLocale$1));
    closeBtn2.innerHTML = `<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="1.5" y1="1.5" x2="8.5" y2="8.5"/><line x1="8.5" y1="1.5" x2="1.5" y2="8.5"/></svg>`;
    closeBtn2.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      dismissMenu();
    });
    el.appendChild(closeBtn2);
    el.addEventListener("mouseenter", cancelHide);
    el.addEventListener("mouseleave", scheduleHide);
    document.body.appendChild(el);
    menuEl = el;
    return el;
  }
  function refreshMenuLabels() {
    if (!menuEl) return;
    menuEl.querySelectorAll(`.${MENU_ITEM_CLASS}`).forEach((btn) => {
      const key = btn.dataset["labelKey"];
      if (!key) return;
      const labelSpan = btn.querySelector(`.${LABEL_CLASS}`);
      if (labelSpan) labelSpan.textContent = t(key, currentLocale$1);
    });
    menuEl.querySelector(`.${CLOSE_BTN_CLASS}`)?.setAttribute("aria-label", t("popover.close", currentLocale$1));
  }
  function notifyOpenLogin() {
    chrome.runtime.sendMessage({ action: "OPEN_LOGIN_PAGE" }).catch(() => {
    });
  }
  function handleMouseOver(e) {
    if (siteHoverDisabled) {
      if (anchorImg) hideMenuImmediate();
      return;
    }
    const target = e.target;
    if (target instanceof Node && menuEl?.contains(target)) {
      cancelHide();
      return;
    }
    let img = target instanceof HTMLImageElement ? target : null;
    if (!img) {
      const stack = document.elementsFromPoint(e.clientX, e.clientY);
      for (const el of stack) {
        if (el instanceof HTMLImageElement) {
          img = el;
          break;
        }
        if (menuEl && el === menuEl) break;
      }
    }
    if (img && !isEligibleImage$1(img)) {
      hideMenuImmediate();
      return;
    }
    if (!img) {
      if (anchorImg) scheduleHide();
      return;
    }
    if (img === anchorImg && menuEl?.classList.contains(MENU_SHOW_CLASS) && menuEl.dataset["authMode"] === currentAuthMode()) {
      cancelHide();
      return;
    }
    if (hoverThrottleTimer !== null && img === anchorImg) return;
    hoverThrottleTimer = window.setTimeout(() => {
      hoverThrottleTimer = null;
    }, HOVER_THROTTLE_MS);
    const suppressExpiry = suppressedUntil.get(img);
    if (suppressExpiry !== void 0 && Date.now() < suppressExpiry) return;
    setAnchor(img);
  }
  function handleMouseOut(e) {
    const related = e.relatedTarget;
    if (related instanceof Node && menuEl?.contains(related)) return;
    if (related instanceof Node && related === anchorImg) return;
    if (anchorImg) {
      const rect = anchorImg.getBoundingClientRect();
      const x = e.clientX;
      const y = e.clientY;
      if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) return;
    }
    scheduleHide();
  }
  function isEligibleImage$1(img) {
    if (img.naturalWidth < COLLECT_MIN_SIZE || img.naturalHeight < COLLECT_MIN_SIZE) return false;
    const rect = img.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    if (Math.min(rect.width, rect.height) < COLLECT_MIN_RENDERED_SIZE || rect.width * rect.height < COLLECT_MIN_RENDERED_PIXELS) {
      return false;
    }
    const src = img.currentSrc || img.src;
    if (!src || src.startsWith("data:")) return false;
    try {
      if (isFramiaHostname(new URL(src, window.location.href).hostname)) return false;
    } catch {
      return false;
    }
    return true;
  }
  function setAnchor(img) {
    cancelHide();
    anchorImg = img;
    const el = ensureMenu(currentAuthMode());
    repositionTo(img, el);
    el.classList.add(MENU_SHOW_CLASS);
  }
  function repositionTo(img, el) {
    const rect = img.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      hideMenuImmediate();
      return;
    }
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (rect.bottom < 0 || rect.top > vh || rect.right < 0 || rect.left > vw) {
      hideMenuImmediate();
      return;
    }
    if (!el.classList.contains(MENU_SHOW_CLASS)) {
      el.style.visibility = "hidden";
      el.classList.add(MENU_SHOW_CLASS);
    }
    const menuW = el.offsetWidth || 160;
    const menuH = el.offsetHeight || 200;
    el.style.visibility = "";
    let left = rect.right - menuW - POSITION_GAP_PX;
    let top = rect.top + POSITION_GAP_PX;
    if (left < 4) left = 4;
    if (left + menuW > vw - 4) left = vw - 4 - menuW;
    if (top < 4) top = 4;
    if (top + menuH > vh - 4) top = vh - 4 - menuH;
    el.style.left = `${left}px`;
    el.style.top = `${top}px`;
  }
  function scheduleReposition() {
    if (!anchorImg || !menuEl?.classList.contains(MENU_SHOW_CLASS)) return;
    if (rafToken) return;
    rafToken = requestAnimationFrame(() => {
      rafToken = 0;
      if (!anchorImg || !menuEl) return;
      repositionTo(anchorImg, menuEl);
    });
  }
  function scheduleHide() {
    cancelHide();
    hideTimer = window.setTimeout(hideMenuImmediate, HIDE_DELAY_MS);
  }
  function cancelHide() {
    if (hideTimer !== null) {
      clearTimeout(hideTimer);
      hideTimer = null;
    }
  }
  function hideMenuImmediate() {
    cancelHide();
    if (menuEl) menuEl.classList.remove(MENU_SHOW_CLASS);
    anchorImg = null;
  }
  function dismissMenu() {
    if (anchorImg) {
      suppressedUntil.set(anchorImg, Date.now() + DISMISS_SUPPRESS_MS);
    }
    hideMenuImmediate();
  }
  async function handleMenuAction(actionId) {
    if (actionId === "open-login") {
      notifyOpenLogin();
      hideMenuImmediate();
      return;
    }
    if (!anchorImg) return;
    if (!isAuthenticatedSync()) {
      showToast(t("toast.not_authenticated", currentLocale$1), true);
      const el = ensureMenu("guest");
      repositionTo(anchorImg, el);
      el.classList.add(MENU_SHOW_CLASS);
      return;
    }
    const img = anchorImg;
    const src = img.currentSrc || img.src;
    const popoverAnchor = img;
    switch (actionId) {
      case "extract-prompt": {
        const cached = getCachedPrompt(src);
        if (cached) {
          showCachedPromptPopover(popoverAnchor, src, cached);
          break;
        }
        showLoadingPromptPopover(popoverAnchor, src);
        try {
          const rect = img.getBoundingClientRect();
          const resp = await chrome.runtime.sendMessage({
            action: "EXTRACT_IMAGE_PROMPT",
            srcUrl: src,
            renderedWidth: Math.round(rect.width),
            renderedHeight: Math.round(rect.height)
          });
          if ("error" in resp && resp.error === "NOT_AUTHENTICATED") {
            showPromptError(t("toast.not_authenticated", currentLocale$1));
            showToast(t("toast.not_authenticated", currentLocale$1), true);
            break;
          }
          if ("error" in resp && resp.error) {
            const msg = formatPromptError(resp, currentLocale$1);
            showPromptError(msg);
            showToast(msg, true);
            break;
          }
          updatePromptPopover(resp);
        } catch (err) {
          const msg = err.message;
          showPromptError(`${t("toast.extract_failed", currentLocale$1)}: ${msg}`);
          showToast(`${t("toast.extract_failed", currentLocale$1)}: ${msg}`, true);
        }
        break;
      }
      case "import-framia": {
        showToast(t("toast.importing", currentLocale$1));
        try {
          const resp = await chrome.runtime.sendMessage({
            action: "QUICK_SAVE_IMAGE",
            srcUrl: src
          });
          if (resp.error === "NO_PROJECT_BOUND") {
            showToast(t("toast.no_project_bound", currentLocale$1), true);
          } else if (resp.error === "NOT_AUTHENTICATED") {
            showToast(t("toast.not_authenticated", currentLocale$1), true);
          } else if (resp.ok) {
            showToast(
              resp.inserted ? t("toast.import_ok_canvas", currentLocale$1) : t("toast.import_ok", currentLocale$1)
            );
          } else {
            showToast(t("toast.import_fail", currentLocale$1), true);
          }
        } catch (err) {
          showToast(
            `${t("toast.import_fail", currentLocale$1)}: ${err.message}`,
            true
          );
        }
        break;
      }
      case "vary-strong":
      case "shuffle": {
        const prompt = VARIATION_PROMPTS[currentLocale$1][actionId];
        await submitToAgent(src, prompt);
        break;
      }
      case "custom-generate": {
        showCustomGeneratePopover(
          popoverAnchor,
          (instruction) => {
            void submitToAgent(src, instruction);
          },
          currentLocale$1
        );
        break;
      }
    }
  }
  async function submitToAgent(srcUrl, prompt) {
    const trimmed = prompt.trim();
    if (!trimmed) return;
    showToast(t("toast.submitting", currentLocale$1));
    try {
      const resp = await chrome.runtime.sendMessage({
        action: "AGENT_SUBMIT_WITH_IMAGE",
        srcUrl,
        prompt: trimmed
      });
      if (resp.ok) {
        showToast(t("toast.agent_submitted", currentLocale$1));
      } else if (resp.error === "NOT_AUTHENTICATED") {
        showToast(t("toast.not_authenticated", currentLocale$1), true);
      } else {
        showToast(
          resp.error ? `${t("toast.agent_failed", currentLocale$1)}: ${resp.error}` : t("toast.agent_failed", currentLocale$1),
          true
        );
      }
    } catch (err) {
      showToast(
        `${t("toast.agent_failed", currentLocale$1)}: ${err.message}`,
        true
      );
    }
  }
  const PANEL_CLASS = "framia-drop-panel";
  const PANEL_SHOW_CLASS = "framia-drop-panel-show";
  const ZONE_CLASS = "framia-drop-panel-zone";
  const ZONE_READY_CLASS = "is-ready";
  const ZONE_ACTIVE_CLASS = "is-active";
  const ZONE_UPLOADING_CLASS = "is-uploading";
  const ITEM_CLASS = "framia-drop-panel-item";
  const ITEM_SELECTED_CLASS = "is-selected";
  const ITEM_UPLOADING_CLASS = "is-uploading";
  const ITEM_DRAG_HOVER_CLASS = "is-drag-hover";
  const STORAGE_LAST_PROJECT = "dropPanelLastProjectId";
  const AUTO_HIDE_MS = 15e3;
  const SUCCESS_HIDE_MS = 2e3;
  const MIN_IMG_SIZE = 60;
  let initialized = false;
  let currentLocale = DEFAULT_LOCALE;
  let panelEl = null;
  let zoneEl = null;
  let zoneTextEl = null;
  let listEl = null;
  let titleEl = null;
  let closeBtn = null;
  let projects = [];
  let projectsLoaded = false;
  let projectsLoading = false;
  let projectsError = false;
  let dropPanelSearchKeyword = "";
  let selectedProjectId = null;
  let dragSrcUrl = null;
  let dragStartX = 0;
  let dragStartY = 0;
  let autoHideTimer = null;
  let isUploading = false;
  let externalDragCounter = 0;
  let siteDropDisabled = false;
  async function loadSiteDropSetting() {
    try {
      const key = hoverDisabledStorageKey(window.location.hostname);
      const stored = await chrome.storage.local.get(key);
      siteDropDisabled = Boolean(stored[key]);
    } catch (err) {
      console.debug("[Framia] failed to load site drop setting:", err);
    }
  }
  function listenSiteDropSetting() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const key = hoverDisabledStorageKey(window.location.hostname);
      if (key in changes) {
        siteDropDisabled = Boolean(changes[key]?.newValue);
        if (siteDropDisabled) hidePanel();
      }
    });
  }
  void getLocale().then((l) => {
    currentLocale = l;
    refreshLocaleStrings();
  });
  onLocaleChange((l) => {
    currentLocale = l;
    refreshLocaleStrings();
    renderProjectList();
  });
  function initDropPanel() {
    if (initialized) return;
    initialized = true;
    if (isFramiaHostname(window.location.hostname)) return;
    void loadSiteDropSetting();
    listenSiteDropSetting();
    document.addEventListener("dragstart", handleDocDragStart, true);
    document.addEventListener("dragend", handleDocDragEnd, true);
    document.addEventListener("dragenter", handleExternalDragEnter, true);
    document.addEventListener("dragleave", handleExternalDragLeave, true);
    onLogout(() => hidePanel());
  }
  function handleDocDragStart(e) {
    if (!isAuthenticatedSync()) return;
    if (siteDropDisabled) return;
    const target = e.target;
    if (!(target instanceof HTMLImageElement)) return;
    if (!isEligibleImage(target)) return;
    dragSrcUrl = target.currentSrc || target.src;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    showPanel();
  }
  function handleDocDragEnd() {
    if (zoneEl) zoneEl.classList.remove(ZONE_ACTIVE_CLASS);
    dragSrcUrl = null;
  }
  function handleExternalDragEnter(e) {
    if (!isAuthenticatedSync()) return;
    if (siteDropDisabled) return;
    if (!e.dataTransfer) return;
    const types = Array.from(e.dataTransfer.types);
    const hasFiles = types.includes("Files");
    const hasUri = types.includes("text/uri-list");
    if (!hasFiles && !hasUri) return;
    externalDragCounter++;
    if (externalDragCounter === 1) {
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      showPanel();
    }
  }
  function handleExternalDragLeave(e) {
    if (!e.dataTransfer) return;
    const types = Array.from(e.dataTransfer.types);
    const hasFiles = types.includes("Files");
    const hasUri = types.includes("text/uri-list");
    if (!hasFiles && !hasUri) return;
    externalDragCounter--;
    if (externalDragCounter <= 0) externalDragCounter = 0;
  }
  function isEligibleImage(img) {
    if (img.naturalWidth < MIN_IMG_SIZE || img.naturalHeight < MIN_IMG_SIZE) return false;
    const src = img.currentSrc || img.src;
    if (!src || src.startsWith("data:")) return false;
    try {
      if (isFramiaHostname(new URL(src, window.location.href).hostname)) return false;
    } catch {
      return false;
    }
    return true;
  }
  function showPanel() {
    ensurePanel();
    if (!panelEl) return;
    positionPanelNearDrag();
    panelEl.classList.add(PANEL_SHOW_CLASS);
    refreshZoneState();
    scheduleAutoHide();
    if (!projectsLoaded && !projectsLoading) {
      void loadProjects();
    }
  }
  function positionPanelNearDrag() {
    if (!panelEl) return;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const pw = panelEl.offsetWidth || 380;
    const ph = panelEl.offsetHeight || 440;
    const margin = 16;
    let left = dragStartX + 24;
    let top = dragStartY - ph / 2;
    if (left + pw > vw - margin) {
      left = dragStartX - pw - 24;
    }
    if (left < margin) left = margin;
    if (left + pw > vw - margin) left = vw - margin - pw;
    if (top < margin) top = margin;
    if (top + ph > vh - margin) top = vh - margin - ph;
    panelEl.style.right = "auto";
    panelEl.style.bottom = "auto";
    panelEl.style.left = `${left}px`;
    panelEl.style.top = `${top}px`;
  }
  function hidePanel() {
    if (!panelEl) return;
    panelEl.classList.remove(PANEL_SHOW_CLASS);
    cancelAutoHide();
    if (zoneEl) zoneEl.classList.remove(ZONE_ACTIVE_CLASS, ZONE_UPLOADING_CLASS);
  }
  function scheduleAutoHide() {
    cancelAutoHide();
    autoHideTimer = window.setTimeout(() => {
      if (!isUploading) hidePanel();
    }, AUTO_HIDE_MS);
  }
  function cancelAutoHide() {
    if (autoHideTimer !== null) {
      clearTimeout(autoHideTimer);
      autoHideTimer = null;
    }
  }
  function ensurePanel() {
    if (panelEl) return;
    const root = document.createElement("div");
    root.className = PANEL_CLASS;
    const header = document.createElement("div");
    header.className = "framia-drop-panel-header";
    const title = document.createElement("div");
    title.className = "framia-drop-panel-title";
    title.textContent = t("dropPanel.title", currentLocale);
    titleEl = title;
    const close = document.createElement("button");
    close.type = "button";
    close.className = "framia-drop-panel-close";
    close.setAttribute("aria-label", t("dropPanel.close", currentLocale));
    close.textContent = "✕";
    close.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      hidePanel();
    });
    closeBtn = close;
    header.append(title, close);
    const body = document.createElement("div");
    body.className = "framia-drop-panel-body";
    const zone = document.createElement("div");
    zone.className = ZONE_CLASS;
    const zoneText = document.createElement("div");
    zoneText.textContent = t("dropPanel.zone_idle", currentLocale);
    zone.appendChild(zoneText);
    zoneEl = zone;
    zoneTextEl = zoneText;
    bindZoneDnd(zone);
    const listCol = document.createElement("div");
    listCol.className = "framia-drop-panel-list-col";
    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.className = "framia-drop-panel-search";
    searchInput.placeholder = t("popup.search_placeholder", currentLocale);
    searchInput.addEventListener("input", () => {
      dropPanelSearchKeyword = searchInput.value.trim();
      renderProjectList();
    });
    const list = document.createElement("div");
    list.className = "framia-drop-panel-list framia-scroll-area";
    listEl = list;
    listCol.append(searchInput, list);
    body.append(zone, listCol);
    root.append(header, body);
    root.addEventListener("mouseenter", cancelAutoHide);
    root.addEventListener("mouseleave", () => {
      if (!isUploading) scheduleAutoHide();
    });
    root.addEventListener("dragover", (e) => {
      e.preventDefault();
      cancelAutoHide();
    });
    document.body.appendChild(root);
    panelEl = root;
    void chrome.storage.local.get([STORAGE_LAST_PROJECT, "boundProject"]).then((r) => {
      const bound = r["boundProject"];
      const last = r[STORAGE_LAST_PROJECT];
      const resolvedId = typeof last === "string" && last || bound?.project_id;
      if (resolvedId) {
        selectedProjectId = resolvedId;
        refreshZoneState();
        renderProjectList();
      }
    }).catch((err) => {
      console.debug("[Framia] failed to load drop panel project preference:", err);
    });
  }
  function refreshLocaleStrings() {
    if (!panelEl) return;
    if (titleEl) titleEl.textContent = t("dropPanel.title", currentLocale);
    if (closeBtn) closeBtn.setAttribute("aria-label", t("dropPanel.close", currentLocale));
    refreshZoneState();
  }
  function refreshZoneState() {
    if (!zoneEl || !zoneTextEl) return;
    zoneEl.classList.remove(ZONE_READY_CLASS, ZONE_UPLOADING_CLASS);
    if (isUploading) {
      zoneEl.classList.add(ZONE_UPLOADING_CLASS);
      zoneTextEl.textContent = t("dropPanel.zone_uploading", currentLocale);
      return;
    }
    if (selectedProjectId) {
      zoneEl.classList.add(ZONE_READY_CLASS);
      const proj = projects.find((p) => p.project_id === selectedProjectId);
      zoneTextEl.textContent = proj?.title ? `↓ ${proj.title}` : t("dropPanel.zone_ready", currentLocale);
    } else {
      zoneTextEl.textContent = t("dropPanel.zone_idle", currentLocale);
    }
  }
  function bindZoneDnd(zone) {
    zone.addEventListener("dragenter", (e) => {
      e.preventDefault();
      cancelAutoHide();
      if (!isUploading) zone.classList.add(ZONE_ACTIVE_CLASS);
    });
    zone.addEventListener("dragover", (e) => {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = selectedProjectId ? "copy" : "none";
      cancelAutoHide();
    });
    zone.addEventListener("dragleave", (e) => {
      if (e.target !== zone) return;
      zone.classList.remove(ZONE_ACTIVE_CLASS);
    });
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove(ZONE_ACTIVE_CLASS);
      if (!selectedProjectId) {
        showToast(t("dropPanel.pick_project_first", currentLocale), true);
        return;
      }
      void handleDropOnProject(e, selectedProjectId);
    });
  }
  function setUploadingState(uploading, projectId) {
    isUploading = uploading;
    if (listEl) {
      listEl.querySelectorAll(`.${ITEM_CLASS}`).forEach((row) => {
        if (uploading && row.dataset["projectId"] === projectId) {
          row.classList.add(ITEM_UPLOADING_CLASS);
        } else {
          row.classList.remove(ITEM_UPLOADING_CLASS);
        }
      });
    }
    refreshZoneState();
  }
  async function handleDropOnProject(e, projectId) {
    e.preventDefault();
    e.stopPropagation();
    if (isUploading) return;
    const dt = e.dataTransfer;
    const payload = await extractDropImage(dt);
    if (!payload) {
      showToast(t("dropPanel.no_image_in_drop", currentLocale), true);
      return;
    }
    setUploadingState(true, projectId);
    cancelAutoHide();
    showToast(t("dropPanel.uploading", currentLocale));
    try {
      const resp = await chrome.runtime.sendMessage({
        action: "DROP_SAVE_IMAGE",
        projectId,
        srcUrl: payload.srcUrl,
        dataUrl: payload.dataUrl,
        filename: payload.filename
      });
      if (resp?.ok) {
        selectedProjectId = projectId;
        void chrome.storage.local.set({ [STORAGE_LAST_PROJECT]: projectId }).catch(() => {
        });
        void chrome.runtime.sendMessage({ action: "BIND_PROJECT", project: { project_id: projectId } }).catch(() => {
        });
        showToast(t("dropPanel.upload_ok", currentLocale));
        window.setTimeout(hidePanel, SUCCESS_HIDE_MS);
      } else if (resp?.error === "NOT_AUTHENTICATED") {
        showToast(t("dropPanel.please_login", currentLocale), true);
      } else {
        showToast(
          resp?.error ? `${t("dropPanel.upload_fail", currentLocale)}: ${resp.error}` : t("dropPanel.upload_fail", currentLocale),
          true
        );
      }
    } catch (err) {
      showToast(
        `${t("dropPanel.upload_fail", currentLocale)}: ${err.message}`,
        true
      );
    } finally {
      setUploadingState(false, null);
      scheduleAutoHide();
      renderProjectList();
    }
  }
  async function extractDropImage(dt) {
    if (dt) {
      const file = dt.files && dt.files[0];
      if (file && file.type.startsWith("image/")) {
        const dataUrl = await readFileAsDataUrl(file);
        return { dataUrl, filename: file.name };
      }
      const uri = dt.getData("text/uri-list") || dt.getData("text/plain");
      const firstUri = uri?.split(/\r?\n/).find((line) => line && !line.startsWith("#"));
      if (firstUri && /^https?:\/\//i.test(firstUri)) {
        return { srcUrl: firstUri };
      }
      const html = dt.getData("text/html");
      if (html) {
        const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
        if (match && /^https?:\/\//i.test(match[1])) {
          return { srcUrl: match[1] };
        }
      }
    }
    if (dragSrcUrl) return { srcUrl: dragSrcUrl };
    return null;
  }
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error ?? new Error("FileReader failed"));
      reader.readAsDataURL(file);
    });
  }
  async function loadProjects() {
    if (!listEl) return;
    projectsLoading = true;
    projectsError = false;
    renderProjectList();
    try {
      const resp = await chrome.runtime.sendMessage({ action: "LIST_PROJECTS" });
      if (resp?.error) throw new Error(resp.error);
      projects = resp?.projects ?? [];
      projectsLoaded = true;
    } catch {
      projectsError = true;
    } finally {
      projectsLoading = false;
      renderProjectList();
    }
  }
  function renderProjectList() {
    if (!listEl) return;
    listEl.replaceChildren();
    if (projectsLoading) {
      listEl.appendChild(statusNode(t("dropPanel.loading_projects", currentLocale)));
      return;
    }
    if (projectsError) {
      listEl.appendChild(statusNode(t("dropPanel.please_login", currentLocale)));
      return;
    }
    const filtered = dropPanelSearchKeyword ? projects.filter(
      (p) => p.title?.toLowerCase().includes(dropPanelSearchKeyword.toLowerCase())
    ) : projects;
    if (!filtered.length) {
      listEl.appendChild(
        statusNode(
          projects.length ? t("popup.no_projects", currentLocale) : t("dropPanel.empty_projects", currentLocale)
        )
      );
      return;
    }
    for (const project of filtered) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = ITEM_CLASS;
      row.dataset["projectId"] = project.project_id;
      if (project.project_id === selectedProjectId) row.classList.add(ITEM_SELECTED_CLASS);
      const dot = document.createElement("span");
      dot.className = "framia-drop-panel-item-dot";
      const title = document.createElement("span");
      title.className = "framia-drop-panel-item-title";
      title.textContent = project.title ?? t("popup.unnamed_project", currentLocale);
      row.append(dot, title);
      row.addEventListener("dragenter", (e) => {
        e.preventDefault();
        if (isUploading) return;
        listEl?.querySelectorAll(`.${ITEM_CLASS}`).forEach((r) => {
          r.classList.toggle(
            ITEM_DRAG_HOVER_CLASS,
            r.dataset["projectId"] === project.project_id
          );
        });
      });
      row.addEventListener("dragover", (e) => {
        e.preventDefault();
        if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
      });
      row.addEventListener("dragleave", (e) => {
        const related = e.relatedTarget;
        if (e.target !== row && related instanceof Node && row.contains(related)) return;
        row.classList.remove(ITEM_DRAG_HOVER_CLASS);
      });
      row.addEventListener("drop", (e) => {
        listEl?.querySelectorAll(`.${ITEM_CLASS}`).forEach(
          (r) => r.classList.remove(ITEM_DRAG_HOVER_CLASS)
        );
        void handleDropOnProject(e, project.project_id);
      });
      row.addEventListener("click", () => {
        selectedProjectId = project.project_id;
        void chrome.storage.local.set({ [STORAGE_LAST_PROJECT]: project.project_id }).catch(() => {
        });
        void chrome.runtime.sendMessage({ action: "BIND_PROJECT", project }).catch(() => {
        });
        refreshZoneState();
        renderProjectList();
      });
      listEl.appendChild(row);
    }
  }
  function statusNode(text) {
    const el = document.createElement("div");
    el.className = "framia-drop-panel-status";
    el.textContent = text;
    return el;
  }
  const PAGE_SCRIPT_ID = "framia-page-token-extractor";
  async function tryExtractToken() {
    try {
      const result = await chrome.storage.local.get("authToken");
      const token = result["authToken"];
      if (token) return token;
    } catch {
    }
    if (window.location.origin === FRAMIA_ORIGIN || window.location.origin.endsWith(".framia.pro")) {
      return injectAndExtract();
    }
    return null;
  }
  function injectAndExtract() {
    return new Promise((resolve) => {
      if (document.getElementById(PAGE_SCRIPT_ID)) {
        listenForToken(resolve);
        return;
      }
      const script = document.createElement("script");
      script.id = PAGE_SCRIPT_ID;
      script.src = chrome.runtime.getURL("page-token-extractor.js");
      script.type = "text/javascript";
      (document.head ?? document.documentElement).appendChild(script);
      listenForToken(resolve);
    });
  }
  function listenForToken(resolve) {
    const expectedOrigin = window.location.origin;
    const timeout = setTimeout(() => {
      window.removeEventListener("message", handler);
      resolve(null);
    }, 3e3);
    const handler = (event) => {
      if (event.source !== window || event.origin !== expectedOrigin || event.data.type !== "FRAMIA_EXT_TOKEN")
        return;
      clearTimeout(timeout);
      window.removeEventListener("message", handler);
      const token = event.data.token ?? null;
      if (token) {
        chrome.runtime.sendMessage({ action: "SET_AUTH_TOKEN", token }).catch(() => {
        });
      }
      resolve(token);
    };
    window.addEventListener("message", handler);
  }
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      const msg = message;
      switch (msg.action) {
        case "PING":
          sendResponse({ ok: true });
          return;
        case "EXTRACT_IMAGES": {
          const images = extractPageImages().map((img) => img.url);
          sendResponse({ images });
          return;
        }
        case "CTX_EXTRACT_PROMPT": {
          const srcUrl = msg.srcUrl;
          if (!srcUrl) break;
          void (async () => {
            const locale = await getLocale().catch(() => DEFAULT_LOCALE);
            const cached = getCachedPrompt(srcUrl);
            if (cached) {
              showCachedPromptPopover(document.body, srcUrl, cached);
              return;
            }
            showLoadingPromptPopover(document.body, srcUrl);
            try {
              const resp = await chrome.runtime.sendMessage({
                action: "EXTRACT_IMAGE_PROMPT",
                srcUrl
              });
              if (isContextExtractError(resp)) {
                const message2 = formatPromptError(resp, locale);
                showPromptError(message2);
                showToast(message2, true);
              } else {
                updatePromptPopover(resp);
              }
            } catch (err) {
              showPromptError(err.message);
              showToast(err.message, true);
            }
          })();
          sendResponse({ ok: true });
          return;
        }
        case "CTX_CUSTOM_GENERATE": {
          const srcUrl = msg.srcUrl;
          if (!srcUrl) break;
          void (async () => {
            const locale = await getLocale().catch(() => DEFAULT_LOCALE);
            showCustomGeneratePopover(
              document.body,
              (instruction) => {
                void submitContextInstruction(srcUrl, instruction, locale);
              },
              locale
            );
          })();
          sendResponse({ ok: true });
          return;
        }
      }
    }
  );
  tryExtractToken().catch(() => {
  });
  initHoverMenu();
  initDropPanel();
  function isContextExtractError(resp) {
    return typeof resp.error === "string";
  }
  async function submitContextInstruction(srcUrl, instruction, locale) {
    const prompt = instruction.trim();
    if (!prompt) return;
    showToast(t("toast.submitting", locale));
    try {
      const resp = await chrome.runtime.sendMessage({
        action: "AGENT_SUBMIT_WITH_IMAGE",
        srcUrl,
        prompt
      });
      if (resp.ok) {
        showToast(t("toast.agent_submitted", locale));
      } else if (resp.error === "NOT_AUTHENTICATED") {
        showToast(t("toast.not_authenticated", locale), true);
      } else {
        showToast(
          resp.error ? `${t("toast.agent_failed", locale)}: ${resp.error}` : t("toast.agent_failed", locale),
          true
        );
      }
    } catch (err) {
      showToast(
        `${t("toast.agent_failed", locale)}: ${err.message}`,
        true
      );
    }
  }
})();
