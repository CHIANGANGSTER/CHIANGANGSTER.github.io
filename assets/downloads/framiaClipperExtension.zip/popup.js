(function() {
  "use strict";
  const DEFAULT_LOCALE = "zh";
  const LOCALE_STORAGE_KEY = "framia_locale";
  function runtime() {
    const r = globalThis.__framia_i18n__;
    if (!r) {
      throw new Error(
        "[Framia] i18n runtime not loaded (expected globalThis.__framia_i18n__)."
      );
    }
    return r;
  }
  function isLocale(value) {
    return runtime().isLocale(value);
  }
  function getLocale() {
    return runtime().getLocale();
  }
  function setLocale(locale) {
    return runtime().setLocale(locale);
  }
  function t(key, locale) {
    return runtime().t(key, locale);
  }
  function onLocaleChange(cb) {
    return runtime().onLocaleChange(cb);
  }
  const FRAMIA_ORIGIN = "https://framia.pro";
  const HOVER_DISABLED_STORAGE_PREFIX = "framia_hover_disabled_";
  function hoverDisabledStorageKey(hostname) {
    return `${HOVER_DISABLED_STORAGE_PREFIX}${hostname}`;
  }
  function isFramiaHostname(hostname) {
    return hostname === "framia.pro" || hostname.endsWith(".framia.pro");
  }
  const UTM_PARAMS = {
    source: "chrome_extension",
    medium: "extension"
  };
  const CAMPAIGN_TO_EVENT = {
    login: "extension_open_login",
    open_in: "extension_open_in_framia",
    agent_submit: "extension_agent_submit",
    extract_prompt: "extension_extract_prompt",
    import_image: "extension_import_image"
  };
  function buildFramiaUrl(path = "/", campaign, extraParams = {}) {
    const url = new URL(path, FRAMIA_ORIGIN);
    url.searchParams.set("utm_source", UTM_PARAMS.source);
    url.searchParams.set("utm_medium", UTM_PARAMS.medium);
    url.searchParams.set("utm_campaign", campaign);
    url.searchParams.set("utm_content", CAMPAIGN_TO_EVENT[campaign]);
    Object.entries(extraParams).forEach(([key, value]) => {
      if (value === void 0) return;
      url.searchParams.set(key, String(value));
    });
    return url.toString();
  }
  function setupAuthView() {
    const loginBtn = document.getElementById("login-btn");
    if (!loginBtn) return;
    loginBtn.addEventListener("click", () => {
      chrome.tabs.create({ url: buildFramiaUrl("/", "login") });
    });
  }
  const POPUP_CACHE_KEY = "popup_boot_cache";
  async function updateCachedBoundProject(project) {
    try {
      const result = await chrome.storage.local.get(POPUP_CACHE_KEY);
      const cached = result[POPUP_CACHE_KEY];
      if (cached) {
        await chrome.storage.local.set({
          [POPUP_CACHE_KEY]: { ...cached, boundProject: project }
        });
      }
    } catch {
    }
  }
  let allProjects = [];
  let onProjectBound = null;
  let currentLocale$2 = DEFAULT_LOCALE;
  let boundProjectId;
  void getLocale().then((locale) => {
    currentLocale$2 = locale;
    rerenderFromCache();
  });
  onLocaleChange((locale) => {
    currentLocale$2 = locale;
    rerenderFromCache();
  });
  function initProjectList(onBound) {
    onProjectBound = onBound;
  }
  function renderProjectListFromBundle(projects, bound, error) {
    boundProjectId = bound;
    const listEl = document.getElementById("project-list");
    if (!listEl) return;
    if (error) {
      const div = document.createElement("div");
      div.className = "loading";
      div.textContent = `${t("popup.load_failed", currentLocale$2)}: ${error}`;
      listEl.replaceChildren(div);
      return;
    }
    allProjects = projects;
    renderProjectList(allProjects, boundProjectId);
  }
  function filterProjects(keyword) {
    const listEl = document.getElementById("project-list");
    if (!listEl) return;
    const filtered = keyword ? allProjects.filter(
      (p) => p.title?.toLowerCase().includes(keyword.toLowerCase())
    ) : allProjects;
    renderProjectList(filtered, boundProjectId);
  }
  function rerenderFromCache() {
    if (!allProjects.length) return;
    renderProjectList(allProjects, boundProjectId);
  }
  function renderProjectList(projects, bound) {
    const listEl = document.getElementById("project-list");
    if (!listEl) return;
    if (!projects.length) {
      listEl.innerHTML = `<div class="loading">${t("popup.no_projects", currentLocale$2)}</div>`;
      return;
    }
    listEl.innerHTML = "";
    projects.forEach((project) => {
      const item = document.createElement("div");
      item.className = "project-item";
      item.dataset["projectId"] = project.project_id;
      if (project.project_id === bound) item.classList.add("project-item--bound");
      const cover = document.createElement("div");
      cover.className = "project-cover";
      const coverImg = typeof project.cover_image === "object" ? project.cover_image : void 0;
      if (coverImg?.small ?? coverImg?.large) {
        const img = document.createElement("img");
        img.src = coverImg.small ?? coverImg.large;
        img.alt = "";
        cover.appendChild(img);
      } else {
        cover.textContent = project.title?.charAt(0)?.toUpperCase() ?? "P";
      }
      const info = document.createElement("div");
      info.className = "project-info";
      const title = document.createElement("div");
      title.className = "project-title";
      title.textContent = project.title ?? t("popup.unnamed_project", currentLocale$2);
      info.appendChild(title);
      item.append(cover, info);
      item.addEventListener("click", () => bindProject(project));
      listEl.appendChild(item);
    });
  }
  async function bindProject(project) {
    if (boundProjectId === project.project_id) return;
    try {
      await chrome.runtime.sendMessage({ action: "BIND_PROJECT", project });
      boundProjectId = project.project_id;
      onProjectBound?.(project);
      showStatus(
        `${t("popup.bound", currentLocale$2)}: ${project.title ?? t("popup.unnamed_project", currentLocale$2)}`
      );
      document.querySelectorAll(".project-item").forEach((el) => {
        el.classList.toggle(
          "project-item--bound",
          el.dataset["projectId"] === project.project_id
        );
      });
      void updateCachedBoundProject(project);
    } catch (err) {
      showError(`${t("popup.bind_failed", currentLocale$2)}: ${err.message}`);
    }
  }
  const MAX_LOG_LINES = 20;
  let currentLocale$1 = DEFAULT_LOCALE;
  function setCurrentLocale(locale) {
    currentLocale$1 = locale;
    const nameEl = document.getElementById("bound-project-name");
    if (nameEl && nameEl.dataset["bound"] !== "1") {
      nameEl.textContent = t("popup.not_bound", currentLocale$1);
    }
  }
  function setupMainView(onLogoutRequest) {
    setupButtons(onLogoutRequest);
    setupProjectSearch();
    updateActionListState();
    void setupSiteSettings();
  }
  function hydrateMainViewFromBundle(bundle) {
    document.body.classList.add("no-transition");
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        document.body.classList.remove("no-transition");
      });
    });
    if (bundle.boundProject?.project_id) {
      setBoundProjectDisplay(bundle.boundProject);
    }
    initProjectList((bound) => setBoundProjectDisplay(bound));
    renderProjectListFromBundle(
      bundle.projects,
      bundle.boundProject?.project_id,
      bundle.projectsError
    );
  }
  function setupButtons(onLogoutRequest) {
    const screenshotBtn = document.getElementById("screenshot-btn");
    const collectBtn = document.getElementById("collect-btn");
    const logoutBtn = document.getElementById("logout-btn");
    screenshotBtn?.addEventListener("click", async () => {
      screenshotBtn.disabled = true;
      showProgress(t("popup.progress.screenshot", currentLocale$1));
      try {
        const resp = await chrome.runtime.sendMessage({
          action: "SCREENSHOT_VISIBLE"
        });
        if (resp.ok) showStatus(t("popup.status.screenshot_ok", currentLocale$1));
        else showError(resp.error ?? t("popup.error.screenshot", currentLocale$1));
      } catch (err) {
        showError(err.message);
      } finally {
        screenshotBtn.disabled = false;
      }
    });
    collectBtn?.addEventListener("click", async () => {
      collectBtn.disabled = true;
      showProgress(t("popup.progress.collect", currentLocale$1));
      try {
        const resp = await chrome.runtime.sendMessage({
          action: "COLLECT_ALL_IMAGES"
        });
        if (resp.ok) {
          showStatus(`${t("popup.status.collect_ok", currentLocale$1)}: ${resp.count ?? 0}`);
        } else {
          showError(resp.error ?? t("popup.error.collect", currentLocale$1));
        }
      } catch (err) {
        showError(err.message);
      } finally {
        collectBtn.disabled = false;
      }
    });
    logoutBtn?.addEventListener("click", async () => {
      if (logoutBtn.disabled) return;
      logoutBtn.disabled = true;
      onLogoutRequest?.();
      await chrome.runtime.sendMessage({ action: "LOGOUT" });
      window.location.reload();
    });
  }
  function setupProjectSearch() {
    const searchInput = document.getElementById("project-search");
    searchInput?.addEventListener("input", () => {
      filterProjects(searchInput.value.trim());
    });
  }
  function setBoundProjectDisplay(project) {
    const el = document.getElementById("bound-project-name");
    if (!el) return;
    el.textContent = project.title ?? t("popup.unnamed_project", currentLocale$1);
    el.dataset["bound"] = "1";
    updateActionListState();
    collapseProjectList();
    setupChangeBtn();
    try {
      chrome.storage.local.set({ dropPanelLastProjectId: project.project_id });
    } catch {
    }
  }
  function updateActionListState() {
    const actionList = document.getElementById("section-actions");
    if (!actionList) return;
    const nameEl = document.getElementById("bound-project-name");
    const isBound = nameEl?.dataset["bound"] === "1";
    actionList.classList.toggle("disabled", !isBound);
  }
  function collapseProjectList() {
    const section = document.getElementById("section-project");
    if (section) section.classList.add("is-bound");
  }
  function expandProjectList() {
    const section = document.getElementById("section-project");
    if (section) section.classList.remove("is-bound");
  }
  function setupChangeBtn() {
    const btn = document.getElementById("bound-change-btn");
    if (!btn || btn.dataset["init"]) return;
    btn.dataset["init"] = "1";
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      expandProjectList();
    });
  }
  function showStatus(message) {
    appendLog(message, "success");
  }
  function showProgress(message) {
    appendLog(message, "progress");
  }
  function showError(message) {
    appendLog(message, "error");
  }
  async function setupSiteSettings() {
    const toggle = document.getElementById("hover-menu-toggle");
    if (!toggle) return;
    let hostname = "";
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url) hostname = new URL(tab.url).hostname;
    } catch {
    }
    if (!hostname || isFramiaHostname(hostname)) {
      const row = document.getElementById("site-settings");
      if (row) row.style.display = "none";
      return;
    }
    const key = hoverDisabledStorageKey(hostname);
    try {
      const stored = await chrome.storage.local.get(key);
      const isDisabled = Boolean(stored[key]);
      toggle.setAttribute("aria-checked", String(isDisabled));
    } catch {
    }
    toggle.addEventListener("click", async () => {
      const current = toggle.getAttribute("aria-checked") === "true";
      const next = !current;
      toggle.setAttribute("aria-checked", String(next));
      try {
        await chrome.storage.local.set({ [key]: next });
      } catch {
        toggle.setAttribute("aria-checked", String(current));
      }
    });
  }
  function appendLog(message, kind) {
    const logEl = document.getElementById("status-log");
    if (!logEl) return;
    const line = document.createElement("div");
    line.className = `status-line ${kind}`;
    line.textContent = message;
    logEl.appendChild(line);
    const lines = logEl.querySelectorAll(".status-line");
    if (lines.length > MAX_LOG_LINES) {
      lines[0]?.remove();
    }
    logEl.scrollTop = logEl.scrollHeight;
  }
  let currentLocale = DEFAULT_LOCALE;
  let hydrated = false;
  const earlyBootCache = readBootCache();
  async function init() {
    setupLangToggle();
    onLocaleChange((locale) => {
      currentLocale = locale;
      setCurrentLocale(locale);
      applyI18n(locale);
      updateLangToggleActive(locale);
    });
    const cache = await earlyBootCache;
    currentLocale = cache?.locale ?? DEFAULT_LOCALE;
    setCurrentLocale(currentLocale);
    applyI18n(currentLocale);
    updateLangToggleActive(currentLocale);
    renderViewForAuth(cache?.authenticated ?? false);
    if (cache?.authenticated) {
      hydrated = true;
      hydrateMainViewFromBundle({
        boundProject: cache.boundProject,
        projects: cache.projects,
        projectsError: null
      });
    }
    const fresh = await chrome.runtime.sendMessage({ action: "INIT_POPUP" });
    if (!fresh) return;
    const authChanged = (cache?.authenticated ?? false) !== fresh.authenticated;
    const projectsChanged = JSON.stringify(cache?.projects ?? []) !== JSON.stringify(fresh.projects);
    if (authChanged) renderViewForAuth(fresh.authenticated);
    if (fresh.authenticated && (authChanged || projectsChanged || !hydrated)) {
      hydrateMainViewFromBundle({
        // 优先使用已渲染的实时存储 boundProject，而非 SW 返回的值——
        // 某些边界情况下 SW 响应会比 storage 写入滞后几次点击。
        boundProject: cache?.boundProject ?? fresh.boundProject,
        projects: fresh.projects,
        projectsError: fresh.projectsError
      });
    }
    void writeBootCache({
      locale: currentLocale,
      authenticated: fresh.authenticated,
      boundProject: cache?.boundProject ?? fresh.boundProject,
      projects: fresh.projects,
      cacheTime: Date.now()
    });
    if (!fresh.authenticated) {
      const unwatch = watchForTokenGain(() => {
        unwatch();
        window.location.reload();
      });
    }
  }
  function watchForTokenGain(onGain) {
    const handler = (changes, area) => {
      if (area === "local" && changes["authToken"]?.newValue) {
        onGain();
      }
    };
    chrome.storage.onChanged.addListener(handler);
    return () => chrome.storage.onChanged.removeListener(handler);
  }
  function renderViewForAuth(authenticated) {
    if (authenticated) {
      showView("view-main");
      setupMainView(() => {
        showView("view-auth");
        setupAuthView();
      });
    } else {
      showView("view-auth");
      setupAuthView();
    }
  }
  async function readBootCache() {
    try {
      const result = await chrome.storage.local.get([
        POPUP_CACHE_KEY,
        LOCALE_STORAGE_KEY,
        "authToken",
        "boundProject"
      ]);
      const liveLocale = result[LOCALE_STORAGE_KEY];
      const cached = result[POPUP_CACHE_KEY];
      const liveAuth = !!result["authToken"];
      const liveBoundProject = result["boundProject"] ?? null;
      const locale = isLocale(liveLocale) ? liveLocale : isLocale(cached?.locale) ? cached.locale : DEFAULT_LOCALE;
      return {
        locale,
        authenticated: liveAuth,
        boundProject: liveBoundProject,
        projects: Array.isArray(cached?.projects) ? cached.projects : []
      };
    } catch {
      return null;
    }
  }
  async function writeBootCache(cache) {
    try {
      await chrome.storage.local.set({ [POPUP_CACHE_KEY]: cache });
    } catch {
    }
  }
  function applyI18n(locale) {
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.dataset["i18n"];
      if (!key) return;
      el.textContent = t(key, locale);
    });
    document.querySelectorAll("[data-i18n-html]").forEach((el) => {
      const key = el.dataset["i18nHtml"];
      if (!key) return;
      el.innerHTML = t(key, locale);
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
      const key = el.dataset["i18nPlaceholder"];
      if (!key) return;
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        el.placeholder = t(key, locale);
      }
    });
    document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => {
      const key = el.dataset["i18nAriaLabel"];
      if (!key) return;
      el.setAttribute("aria-label", t(key, locale));
    });
  }
  function setupLangToggle() {
    const btn = document.getElementById("lang-toggle");
    if (!btn) return;
    btn.addEventListener("click", async (e) => {
      const target = e.target;
      const seg = target?.closest("[data-locale]");
      const explicit = seg?.dataset["locale"];
      const next = explicit ?? (currentLocale === "zh" ? "en" : "zh");
      if (next === currentLocale) return;
      await setLocale(next);
    });
  }
  function updateLangToggleActive(locale) {
    document.querySelectorAll(".lang-toggle__seg").forEach((seg) => {
      seg.classList.toggle("is-active", seg.dataset["locale"] === locale);
    });
  }
  chrome.runtime.onMessage.addListener((message) => {
    const msg = message;
    if (msg.action === "NOTIFICATION" && msg.message) {
      const logEl = document.getElementById("status-log");
      if (logEl) {
        const line = document.createElement("div");
        line.className = "status-line progress";
        line.textContent = msg.message;
        logEl.appendChild(line);
        logEl.scrollTop = logEl.scrollHeight;
      }
    }
  });
  function showView(viewId) {
    document.querySelectorAll("[data-view]").forEach((el) => {
      el.classList.toggle("is-active", el.id === viewId);
    });
  }
  function startPopup() {
    init().catch((err) => {
      console.error("[Framia popup]", err);
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startPopup, { once: true });
  } else {
    startPopup();
  }
})();
