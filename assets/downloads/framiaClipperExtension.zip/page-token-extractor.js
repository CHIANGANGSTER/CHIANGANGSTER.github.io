(function() {
  "use strict";
  (function() {
    const MSG_TYPE = "FRAMIA_EXT_TOKEN";
    function tryAuth0Client() {
      return new Promise((resolve) => {
        setTimeout(async () => {
          try {
            const w = window;
            if (w.__auth0Client?.getTokenSilently) {
              const token = await w.__auth0Client.getTokenSilently();
              resolve(token ?? null);
            } else {
              resolve(null);
            }
          } catch {
            resolve(null);
          }
        }, 100);
      });
    }
    function trySessionStorage() {
      try {
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i) ?? "";
          if (key.startsWith("@@auth0spajs@@") || key.includes("auth0")) {
            const raw = sessionStorage.getItem(key);
            if (!raw) continue;
            try {
              const parsed = JSON.parse(raw);
              const token = parsed.body?.access_token ?? parsed.access_token ?? null;
              if (token) return token;
            } catch {
            }
          }
        }
      } catch {
      }
      return null;
    }
    function isFramiaApiUrl(rawUrl) {
      try {
        const u = new URL(rawUrl, window.location.origin);
        const host = u.hostname.toLowerCase();
        return host === "framia.pro" || host.endsWith(".framia.pro");
      } catch {
        return false;
      }
    }
    function patchFetch() {
      return new Promise((resolve) => {
        const originalFetch = window.fetch;
        let resolved = false;
        window.fetch = function(...args) {
          const [input, init] = args;
          const url = typeof input === "string" ? input : input.url;
          if (isFramiaApiUrl(url)) {
            const authHeader = init?.headers?.["Authorization"] ?? init?.headers?.["authorization"];
            if (authHeader?.startsWith("Bearer ") && !resolved) {
              resolved = true;
              window.fetch = originalFetch;
              resolve(authHeader.slice(7));
            }
          }
          return originalFetch.apply(this, args);
        };
        setTimeout(() => {
          if (!resolved) {
            resolved = true;
            window.fetch = originalFetch;
            resolve(null);
          }
        }, 1e4);
      });
    }
    async function extractToken() {
      const sameOrigin = window.location.origin;
      const ssToken = trySessionStorage();
      if (ssToken) {
        window.postMessage({ type: MSG_TYPE, token: ssToken }, sameOrigin);
        return;
      }
      const clientToken = await tryAuth0Client();
      if (clientToken) {
        window.postMessage({ type: MSG_TYPE, token: clientToken }, sameOrigin);
        return;
      }
      const fetchToken = await patchFetch();
      if (fetchToken) {
        window.postMessage({ type: MSG_TYPE, token: fetchToken }, sameOrigin);
      }
    }
    extractToken().catch(() => {
    });
  })();
})();
