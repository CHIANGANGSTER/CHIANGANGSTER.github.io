importScripts('i18n.js');
(function() {
  "use strict";
  const DEFAULT_API_BASE = "https://api.framia.pro/video/api";
  const FRAMIA_ORIGIN = "https://framia.pro";
  const EDITOR_WORKER_BASE = "https://editor-worker.framia.pro";
  const CHROME_APP_WORKER_BASE = "https://chrome-app-worker.framia.pro";
  const PROMPT_IMAGE_MIN_SHORT_EDGE = 256;
  const PROMPT_IMAGE_MIN_PIXELS = 65536;
  const PROMPT_IMAGE_MAX_LONG_EDGE = 2048;
  const PROMPT_IMAGE_MAX_PIXELS = 2048 * 2048;
  const PROMPT_IMAGE_OUTPUT_TYPE = "image/jpeg";
  const PROMPT_IMAGE_OUTPUT_QUALITY = 0.9;
  const UTM_PARAMS = {
    source: "chrome_extension",
    medium: "extension"
  };
  const VARIATION_PROMPTS = {
    zh: {
      "vary-strong": "基于这张图片帮我生成3种变体",
      shuffle: "基于这张图片帮我重新排版"
    },
    en: {
      "vary-strong": "Generate 3 variations based on this image",
      shuffle: "Re-layout this image"
    }
  };
  const CAMPAIGN_TO_EVENT = {
    login: "extension_open_login",
    open_in: "extension_open_in_framia",
    agent_submit: "extension_agent_submit",
    extract_prompt: "extension_extract_prompt",
    import_image: "extension_import_image"
  };
  function buildFramiaUrl(path = "/", campaign, extraParams = {}) {
    const url = new URL(path, FRAMIA_ORIGIN);
    url.searchParams.set("utm_source", UTM_PARAMS.source);
    url.searchParams.set("utm_medium", UTM_PARAMS.medium);
    url.searchParams.set("utm_campaign", campaign);
    url.searchParams.set("utm_content", CAMPAIGN_TO_EVENT[campaign]);
    Object.entries(extraParams).forEach(([key, value]) => {
      if (value === void 0) return;
      url.searchParams.set(key, String(value));
    });
    return url.toString();
  }
  function runtime() {
    const r = globalThis.__framia_i18n__;
    if (!r) {
      throw new Error(
        "[Framia] i18n runtime not loaded (expected globalThis.__framia_i18n__)."
      );
    }
    return r;
  }
  function getLocale() {
    return runtime().getLocale();
  }
  function t(key, locale) {
    return runtime().t(key, locale);
  }
  function format(str, vars) {
    return runtime().format(str, vars);
  }
  function onLocaleChange(cb) {
    return runtime().onLocaleChange(cb);
  }
  async function getApiBase() {
    const result = await chrome.storage.local.get("apiBase");
    return result["apiBase"] ?? DEFAULT_API_BASE;
  }
  async function getAuthToken() {
    const result = await chrome.storage.local.get("authToken");
    return result["authToken"] ?? null;
  }
  async function saveAuthToken(token) {
    await chrome.storage.local.set({ authToken: token });
  }
  async function clearAuthToken() {
    await chrome.storage.local.remove("authToken");
  }
  async function requireAuthToken() {
    const token = await getAuthToken();
    if (!token) throw new Error("NOT_AUTHENTICATED");
    return token;
  }
  async function getBoundProjectId() {
    const result = await chrome.storage.local.get("boundProject");
    const project = result["boundProject"];
    if (!project?.project_id) {
      const locale = await getLocale();
      throw new Error(t("toast.no_project_bound", locale));
    }
    return project.project_id;
  }
  function dedupRequest(fn, options) {
    const { cacheMs = 0, keyResolver } = options ?? {};
    const inflight2 = /* @__PURE__ */ new Map();
    const cache = /* @__PURE__ */ new Map();
    const resolveKey = keyResolver ?? ((...args) => {
      if (args.length === 0) return "";
      if (args.length === 1) {
        const arg = args[0];
        if (typeof arg === "string" || typeof arg === "number" || typeof arg === "boolean") {
          return String(arg);
        }
      }
      return JSON.stringify(args);
    });
    return (...args) => {
      const key = resolveKey(...args);
      if (cacheMs > 0) {
        const entry = cache.get(key);
        if (entry && Date.now() < entry.expiresAt) {
          return entry.promise;
        }
      }
      const existing = inflight2.get(key);
      if (existing) return existing;
      const promise = fn(...args).then(
        (result) => {
          inflight2.delete(key);
          if (cacheMs > 0) {
            cache.set(key, { promise: Promise.resolve(result), expiresAt: Date.now() + cacheMs });
          }
          return result;
        },
        (error) => {
          inflight2.delete(key);
          throw error;
        }
      );
      inflight2.set(key, promise);
      return promise;
    };
  }
  const fetchCreditsRaw = dedupRequest((http) => http.get("/v1/user/credits"));
  const fetchProjectRaw = dedupRequest(
    (http, projectId, config) => http.get(`/v2/projects/${projectId}`, config),
    {
      cacheMs: 1e4,
      keyResolver: (_http, projectId, _config) => projectId
    }
  );
  const fetchProjectResourceListRaw = dedupRequest(
    (http, projectId) => http.get(`/v2/projects/${projectId}/resources`),
    { cacheMs: 3e4, keyResolver: (_http, projectId) => projectId }
  );
  class GenerateApi {
    http;
    constructor(http) {
      this.http = http;
    }
    /**
     * 创建新项目
     * POST /v2/projects
     * @param workspaceId 可选，当前 workspace ID，创建后项目归属该 workspace
     */
    async createProject(executionMode = "auto", source = "user", workspaceId, category) {
      const body = {
        execution_mode: executionMode,
        source
      };
      if (workspaceId) {
        body.workspace_id = workspaceId;
      }
      if (category) {
        body.category = category;
      }
      const response = await this.http.post("/v2/projects", body);
      return response.data;
    }
    /**
     * 更新项目信息
     * POST /v2/projects/:project_id/update
     * @param projectId 项目 ID
     * @param params 更新参数（title、thumbnail、share_image_key）
     */
    async updateProject(projectId, params) {
      const response = await this.http.post(`/v2/projects/${projectId}/update`, params);
      return response.data;
    }
    /**
     * 删除项目
     * DELETE /v2/projects/:project_id
     */
    async deleteProject(projectId) {
      const response = await this.http.delete(`/v2/projects/${projectId}`);
      return response.data;
    }
    /**
     * 获取用户项目列表（全量）
     * GET /v2/projects
     * @param workspaceId 可选，当前 workspace ID，不同 workspace 下项目列表不同
     */
    async getProjectList(workspaceId) {
      const params = workspaceId ? { workspace_id: workspaceId } : void 0;
      const response = await this.http.get("/v2/projects", { params });
      return response.data;
    }
    /**
     * 获取用户项目列表（分页）
     * GET /v2/projects/page
     * @param page 页码，从 1 开始，默认 1
     * @param pageSize 每页条数，默认 20
     * @param workspaceId 可选，当前 workspace ID，不同 workspace 下项目列表不同
     * @param category 可选，项目分类筛选（与 Projects 页 Tab 对齐；需后端支持 `category` query）
     */
    async getProjectListPaged(page = 1, pageSize = 20, workspaceId, category) {
      const params = { page: page || 1, page_size: pageSize || 20 };
      if (workspaceId) {
        params.workspace_id = workspaceId;
      }
      const resolvedCategory = category ?? "all";
      if (resolvedCategory !== "all") {
        params.category = resolvedCategory;
      }
      const response = await this.http.get("/v2/projects/page", { params });
      return response.data;
    }
    /**
     * 获取项目详情
     * GET /v2/projects/:project_id
     */
    async getProject(projectId, config) {
      const response = await fetchProjectRaw(this.http, projectId, config);
      return response.data;
    }
    /**
     * 获取文件上传预签名 URL
     * POST /v2/get_upload_presigned_url
     */
    async getSignedUrlWithProject({
      projectId,
      filename,
      scene
    }) {
      const response = await this.http.post(`/v2/get_upload_presigned_url`, {
        project_id: projectId,
        filename,
        scene
      });
      return response.data;
    }
    /**
     * 通知服务器文件上传完成
     * POST /v2/projects/:project_id/upload_done
     */
    async uploadFileDoneWithProject(projectId, filename, key, threadId, scene = "main_chat", extraParams = {}) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/upload_done`,
        {
          thread_id: threadId,
          filename,
          key,
          scene,
          params: extraParams
        }
      );
      return response.data;
    }
    /**
     * 获取项目资源列表
     * GET /v2/projects/:project_id/resources
     */
    async getProjectResourceList(projectId) {
      const response = await fetchProjectResourceListRaw(this.http, projectId);
      return response.data;
    }
    /**
     * 获取项目单个资源信息
     * GET /v2/projects/:project_id/resource/info
     */
    async getProjectResource(projectId, threadId, path) {
      const response = await this.http.get(
        `/v2/projects/${projectId}/resource/info`,
        {
          params: {
            thread_id: threadId,
            path
          }
        }
      );
      return response.data;
    }
    /**
     * 批量获取项目资源信息
     * POST /v2/projects/:project_id/resource/info
     */
    async getProjectResourcesWithPathList(projectId, threadId, pathList) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/resource/info`,
        {
          thread_id: threadId,
          paths: Array.from(new Set(pathList))
        }
      );
      const record = {};
      const resourceList = response?.data?.data?.resources || [];
      for (const resource of resourceList) {
        if (resource.exists) {
          record[resource.path] = resource;
        }
      }
      return record;
    }
    /**
     * 向指定线程提交用户查询
     * POST /v2/video_agent/user_query
     */
    async submitUserQuery(content, threadId) {
      const response = await this.http.post(`/v2/video_agent/user_query`, {
        thread_id: threadId,
        content
      });
      return response.data;
    }
    /**
     * 停止指定线程的当前轮次
     * POST /v2/thread/:thread_id/stop
     */
    async stopThread(threadId) {
      const response = await this.http.post(`/v2/thread/${threadId}/stop`);
      return response.data;
    }
    /**
     * 获取文件上传的预签名 URL (V1)
     * POST /v1/thread/:thread_id/get_upload_presigned_url
     */
    async getSignedUrl(filename, threadId) {
      const response = await this.http.post(
        `/v1/thread/${threadId}/get_upload_presigned_url`,
        {
          filename
        }
      );
      return response.data;
    }
    /**
     * 通知服务器文件上传完成 (V1)
     * POST /v1/thread/:thread_id/upload_done
     */
    async uploadFileDone(threadId, filename, key) {
      const response = await this.http.post(`/v1/thread/${threadId}/upload_done`, {
        filename,
        key
      });
      return response.data;
    }
    /**
     * 获取用户列表
     * GET /v1/users
     */
    async listUsers(offset = 0, limit = 10) {
      const response = await this.http.get("/v1/users", {
        params: { offset, limit }
      });
      return response.data;
    }
    /**
     * 获取当前用户的个人资料
     * GET /v1/user/profile
     */
    async getUserProfile() {
      const response = await this.http.get("/v1/user/profile");
      return response.data;
    }
    /**
     * 获取当前用户的所有会话线程
     * GET /v1/threads
     */
    async listThreads() {
      const response = await this.http.get("/v1/threads");
      return response.data;
    }
    /**
     * 获取指定线程的详细信息
     * GET /v1/thread/:thread_id
     */
    async getThread(threadId) {
      const response = await this.http.get(`/v1/thread/${threadId}`);
      return response.data;
    }
    /**
     * 创建新的会话线程
     * POST /v1/threads
     */
    async createThread() {
      const response = await this.http.post("/v1/threads", {});
      return response.data;
    }
    /**
     * 创建项目会话线程
     * POST /v2/projects/:project_id/threads
     */
    async createProjectThread(projectId) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/threads`,
        null
      );
      return response.data;
    }
    /**
     * 删除用户的所有会话线程
     * DELETE /v1/threads
     */
    async deleteUserThreads() {
      const response = await this.http.delete("/v1/threads");
      return response.data;
    }
    /**
     * 删除指定会话线程
     * DELETE /v1/thread/:thread_id
     */
    async deleteThread(threadId) {
      const response = await this.http.delete(`/v1/thread/${threadId}`);
      return response.data;
    }
    /**
     * 获取指定线程的资源列表
     * GET /v1/thread/:thread_id/resources
     */
    async listResourcesByThread(threadId) {
      const response = await this.http.get(`/v1/thread/${threadId}/resources`);
      return response.data;
    }
    /**
     * 获取用户积分余额
     * GET /v1/user/credits
     */
    async getCredits() {
      const response = await fetchCreditsRaw(this.http);
      const creditsBalance = response.data?.data?.credits?.credits_balance || 0;
      return Math.floor(creditsBalance);
    }
    /**
     * 获取用户积分明细（含批次列表）
     * GET /v1/user/credits
     *
     * 与 getCredits 共用同一 dedup 通道，不会触发额外请求。
     * 返回原始批次以便上层按 package_type/package_subtype 做分类（见 useCreditsBreakdown）。
     */
    async getCreditsDetail() {
      const response = await fetchCreditsRaw(this.http);
      const credits = response.data?.data?.credits;
      return {
        credits_balance: credits?.credits_balance ?? 0,
        credit_cent_balance: credits?.credit_cent_balance ?? 0,
        batches: Array.isArray(credits?.batches) ? credits.batches : []
      };
    }
    /**
     * 获取用户 ID
     * GET /v1/user/credits
     */
    async getUserId() {
      const response = await fetchCreditsRaw(this.http);
      const userId = response.data?.data?.credits?.user_id;
      if (userId == null) {
        throw new Error("Missing user_id in credits response");
      }
      return userId;
    }
    /**
     * 获取指定资源的详细信息
     * GET /v1/thread/:thread_id/resource/info
     */
    async getResourceInfo(threadId, path) {
      const response = await this.http.get(
        `/v1/thread/${threadId}/resource/info`,
        {
          params: { path }
        }
      );
      return response.data;
    }
    /**
     * 删除指定资源
     * DELETE /v1/thread/:thread_id/resources/:resource_id
     */
    async deleteResource(threadId, resourceId) {
      const response = await this.http.delete(
        `/v1/thread/${threadId}/resources/${resourceId}`
      );
      return response.data;
    }
    /**
     * 获取指定用户的资源列表
     * GET /v1/resources
     */
    async listResourcesByUser() {
      const response = await this.http.get(`/v1/resources`);
      return response.data;
    }
    /**
     * 获取提示词模板列表
     * GET /v2/prompt_starters
     */
    async getPromptTemplates() {
      const response = await this.http.get("/v2/prompt_starters");
      return response.data;
    }
    /**
     * 获取聊天配置
     * GET /v2/get_chat_configs
     */
    async getChatConfigs() {
      const response = await this.http.get(
        "/v2/get_chat_configs"
      );
      return response.data;
    }
    /**
     * 获取指定线程的消息列表
     * GET /v2/thread/:thread_id/messages
     * @param threadId - 线程 ID
     * @param options - 查询选项
     * @param options.turn - 精确匹配单个 turn
     * @param options.startTurn - 范围查询起始 turn（包含）
     * @param options.endTurn - 范围查询结束 turn（包含）
     * @param options.detail - 是否返回详细信息
     */
    async listMessagesByThread(threadId, options = {}) {
      const { turn, startTurn, endTurn, detail = false } = options;
      const response = await this.http.get(`/v2/thread/${threadId}/messages`, {
        params: {
          ...turn !== void 0 && { turn },
          ...startTurn !== void 0 && { start_turn: startTurn },
          ...endTurn !== void 0 && { end_turn: endTurn },
          detail
        }
      });
      return response.data;
    }
    /**
     * 获取物料 tool 任务状态
     * GET /v2/tasks/:thread_id/status
     *
     * 用途：
     * - 前端轮询查询物料 tool 任务状态
     * - 重点关注任务是否失败及失败原因
     *
     * @param threadId - 线程 ID
     * @returns 任务状态响应
     *
     * @example
     * 成功：{ thread_id: "xxx", status: "completed" }
     * 失败：{ thread_id: "xxx", status: "failed", error_message: "生成失败：模型不可用" }
     * 进行中：{ thread_id: "xxx", status: "running" }
     */
    async getTaskStatus(threadId) {
      const response = await this.http.get(
        `/v2/tasks/${threadId}/status`
      );
      return response.data.data;
    }
    /**
     * 获取当前用户的活动
     * GET /api/activity/user/current
     *
     * 描述：获取当前登录用户应该看到的活动。根据活动状态、时间范围和用户已查看次数判断，
     * 如果用户已经查看过 max_show_times 次，则返回 null。
     *
     * @returns 活动信息，如果无活动或已查看超过最大次数则返回 null
     *
     * @example
     * 有活动：{ id: 1, title: "新年活动", ... }
     * 无活动：null
     */
    async getCurrentUserActivity() {
      const response = await this.http.get(
        `/activity/user/current`
      );
      return response.data;
    }
    /**
     * 记录活动查看
     * POST /api/activity/:id/view
     *
     * 描述：记录用户查看了某个活动，增加查看次数。同时用于检查用户是否已查看过该活动。
     *
     * @param activityId - 活动ID
     * @returns 响应结果
     *   - code: 0 表示已查看过（之前已经记录过），不显示弹窗
     *   - code: 1 表示没看过（首次查看，已记录），显示弹窗
     *
     * @example
     * 已查看过：{ code: 0, message: "success" }
     * 首次查看：{ code: 1, message: "success" }
     */
    async recordActivityView(activityId) {
      const response = await this.http.post(
        `/activity/${activityId}/view`
      );
      return response.data;
    }
    /**
     * 更新项目封面和标题
     * POST /v2/projects/:project_id/cover
     *
     * @param projectId - 项目 ID
     * @param s3Key - 封面图片的 S3 Key
     * @param title - 项目标题（可选）
     * @returns 更新后的项目信息
     */
    async updateProjectCover(projectId, s3Key, title) {
      const response = await this.http.post(`/v2/projects/${projectId}/cover`, {
        s3_key: s3Key,
        ...title !== void 0 && { title }
      });
      return response.data;
    }
  }
  class EditorWorkerApi {
    http;
    constructor(http) {
      this.http = http;
    }
    /**
     * 列出（或按条件过滤）某画布的元素。
     * GET /api/v1/canvas/:canvasId/elements
     */
    async listElements(canvasId, query) {
      const response = await this.http.get(
        `/api/v1/canvas/${encodeURIComponent(canvasId)}/elements`,
        { params: query }
      );
      return response.data;
    }
    /**
     * 在画布中创建新元素。返回 worker 序列化后的完整 element（含服务端补齐的
     * elementId / position / metadata 等），方便调用方拿到 elementId 做后续
     * patch / delete。
     * POST /api/v1/canvas/:canvasId/elements
     */
    async createElement(canvasId, payload) {
      const response = await this.http.post(
        `/api/v1/canvas/${encodeURIComponent(canvasId)}/elements`,
        payload
      );
      return response.data;
    }
  }
  const fetchCanvasResourcesRaw = dedupRequest(
    (http, projectId) => http.get(`v2/projects/${projectId}/resources`),
    { cacheMs: 1e4 }
  );
  class CanvasApi {
    http;
    constructor(http) {
      this.http = http;
    }
    /**
     * 获取预签名 URL
     * POST /v2/get_upload_presigned_url
     */
    async getUploadPresignedUrl(projectId, params) {
      const response = await this.http.post(`/v2/get_upload_presigned_url`, {
        ...params,
        project_id: projectId
      });
      return response.data;
    }
    /**
     * 确认上传完成
     * POST /v2/projects/:project_id/upload_done
     */
    async uploadDone(projectId, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/upload_done`,
        params
      );
      return response.data;
    }
    /**
     * AI 增强接口
     * POST /v2/projects/:project_id/ai/resoure_process
     */
    async resourceProcess(projectId, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/ai/resoure_process`,
        params
      );
      return response.data;
    }
    /**
     * 获取 Shot 详情
     * GET /v2/projects/:project_id/shots/:shot_name
     */
    async getShot(projectId, shotName) {
      const response = await this.http.get(
        `/v2/projects/${projectId}/shots/${encodeURIComponent(shotName)}`
      );
      return response.data;
    }
    /**
     * 获取 Shot 版本列表
     * GET /v2/projects/:project_id/shots/:shot_name/versions
     */
    async getShotVersions(projectId, shotName, type) {
      const response = await this.http.get(
        `/v2/projects/${projectId}/shots/${encodeURIComponent(shotName)}/versions`,
        { params: type ? { type } : void 0 }
      );
      return response.data;
    }
    /**
     * 应用 Shot 版本
     * POST /v2/projects/:project_id/shots/:shot_name/apply_version
     */
    async applyShotVersion(projectId, shotName, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/shots/${encodeURIComponent(shotName)}/apply_version`,
        params
      );
      return response.data;
    }
    /**
     * Shot 版本行为上报（如 view 已读）
     * POST /v2/projects/:project_id/shots/:shot_name/action
     */
    async shotAction(projectId, shotName, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/shots/${encodeURIComponent(shotName)}/action`,
        params
      );
      return response.data;
    }
    /**
     * OCR 检测接口 - 同步返回图片中的文字
     * POST /v2/projects/:project_id/ai/ocr
     *
     * 注意：这是同步 API，直接返回 OCR 结果，不需要 WebSocket
     * 结果会缓存 7 天，相同图片再次调用时直接返回缓存
     * 
     * OCR 处理可能需要较长时间，因此设置超时为 90 秒以提供缓冲
     */
    async ocrDetect(projectId, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/ai/ocr`,
        params,
        {
          timeout: 9e4
          // 90 秒超时
        }
      );
      return response.data;
    }
    /**
     * Subject 检测接口 - 根据点击位置识别图片主体
     * POST /v2/projects/:project_id/ai/subject-detect
     */
    async subjectDetect(projectId, params) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/ai/subject-detect`,
        params,
        {
          timeout: 9e4
        }
      );
      return response.data;
    }
    /**
     * 获取音色列表
     * GET /v2/common/tts/get_model_configs
     */
    async getTTSModelConfig() {
      const response = await this.http.get(`/v2/common/tts/get_model_configs`);
      return response.data;
    }
    /**
     * 获取所有模型配置
     * GET /v2/common/get_model_configs
     */
    async getModelConfigs() {
      const response = await this.http.get(`/v2/common/get_model_configs`);
      return response.data.data;
    }
    /**
     * 获取画布元素
     * GET /v2/projects/:project_id/canvas
     */
    async getElements(projectId) {
      const response = await this.http.get(`/v2/projects/${projectId}/canvas`);
      return response.data;
    }
    /**
     * 批量移除画布元素
     * DELETE /v2/projects/:project_id/canvas/elements
     */
    async removeElements(projectId, elementIds) {
      const response = await this.http.delete(
        `/v2/projects/${projectId}/canvas/elements`,
        { data: { element_ids: elementIds } }
      );
      return response.data;
    }
    /**
     * 批量复制画布元素
     * POST /v2/projects/:project_id/canvas/elements/duplicate
     */
    async pasteElements(projectId, duplications) {
      const response = await this.http.post(
        `/v2/projects/${projectId}/canvas/elements/duplicate`,
        { data: { duplications } }
      );
      return response.data;
    }
    /**
     * 批量更新画布元素
     * PUT /v2/projects/:project_id/canvas/positions
     */
    async updateElements(projectId, params) {
      const response = await this.http.put(
        `v2/projects/${projectId}/canvas/positions`,
        params
      );
      return response.data;
    }
    /**
     * 初始化画布首次插入元素位置
     * PUT /v2/projects/:project_id/canvas/initial-position
     */
    async initPosition(projectId, params) {
      const response = await this.http.put(
        `v2/projects/${projectId}/canvas/initial-position`,
        params
      );
      return response.data;
    }
    /**
     * 获取当前画布资源
     * GET /v2/projects/:project_id/resources
     */
    async getResources(projectId) {
      const response = await fetchCanvasResourcesRaw(this.http, projectId);
      return response.data;
    }
    /**
     * 通过资源ID获取单个资源详情
     * GET /v2/resources/:resource_id/info
     *
     * 后端接口：internal/api/handlers/hertz/video/resource.go - GetResourceInfoByID
     */
    async getResourceInfoById(resourceId) {
      const response = await this.http.get(`v1/resources/${resourceId}/info`);
      return response.data;
    }
    /**
     * 下载资源
     * GET /v2/resources/:resource_id/download
     */
    async downloadResource(resourceId) {
      const response = await this.http.get(
        `v2/resources/${resourceId}/download`,
        { responseType: "blob" }
      );
      return response.data;
    }
    /**
     * 获取 credits 预估消耗
     * POST /v2/projects/:project_id/ai/resource_process_pricing
     */
    async getCreditsConsume(projectId, params) {
      const response = await this.http.post(
        `v2/projects/${projectId}/ai/resource_process_pricing`,
        params
      );
      return response.data;
    }
    /**
     * 获取下载资源 url
     * GET /v1/resources/:resource_id/download_url
     */
    async getDownloadUrl(resourceId) {
      const response = await this.http.get(
        `v1/resources/${resourceId}/download_url`
      );
      return response.data.data;
    }
  }
  dedupRequest(
    (http) => http.get("/api/payment/subscription/status"),
    { cacheMs: 3e4 }
  );
  function bind(fn, thisArg) {
    return function wrap() {
      return fn.apply(thisArg, arguments);
    };
  }
  const { toString } = Object.prototype;
  const { getPrototypeOf } = Object;
  const { iterator, toStringTag } = Symbol;
  const kindOf = /* @__PURE__ */ ((cache) => (thing) => {
    const str = toString.call(thing);
    return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null));
  const kindOfTest = (type) => {
    type = type.toLowerCase();
    return (thing) => kindOf(thing) === type;
  };
  const typeOfTest = (type) => (thing) => typeof thing === type;
  const { isArray } = Array;
  const isUndefined = typeOfTest("undefined");
  function isBuffer(val) {
    return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction$1(val.constructor.isBuffer) && val.constructor.isBuffer(val);
  }
  const isArrayBuffer = kindOfTest("ArrayBuffer");
  function isArrayBufferView(val) {
    let result;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      result = ArrayBuffer.isView(val);
    } else {
      result = val && val.buffer && isArrayBuffer(val.buffer);
    }
    return result;
  }
  const isString = typeOfTest("string");
  const isFunction$1 = typeOfTest("function");
  const isNumber = typeOfTest("number");
  const isObject = (thing) => thing !== null && typeof thing === "object";
  const isBoolean = (thing) => thing === true || thing === false;
  const isPlainObject = (val) => {
    if (kindOf(val) !== "object") {
      return false;
    }
    const prototype2 = getPrototypeOf(val);
    return (prototype2 === null || prototype2 === Object.prototype || Object.getPrototypeOf(prototype2) === null) && !(toStringTag in val) && !(iterator in val);
  };
  const isEmptyObject = (val) => {
    if (!isObject(val) || isBuffer(val)) {
      return false;
    }
    try {
      return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
    } catch (e) {
      return false;
    }
  };
  const isDate = kindOfTest("Date");
  const isFile = kindOfTest("File");
  const isReactNativeBlob = (value) => {
    return !!(value && typeof value.uri !== "undefined");
  };
  const isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
  const isBlob = kindOfTest("Blob");
  const isFileList = kindOfTest("FileList");
  const isStream = (val) => isObject(val) && isFunction$1(val.pipe);
  function getGlobal() {
    if (typeof globalThis !== "undefined") return globalThis;
    if (typeof self !== "undefined") return self;
    if (typeof window !== "undefined") return window;
    if (typeof global !== "undefined") return global;
    return {};
  }
  const G = getGlobal();
  const FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
  const isFormData = (thing) => {
    if (!thing) return false;
    if (FormDataCtor && thing instanceof FormDataCtor) return true;
    const proto = getPrototypeOf(thing);
    if (!proto || proto === Object.prototype) return false;
    if (!isFunction$1(thing.append)) return false;
    const kind = kindOf(thing);
    return kind === "formdata" || // detect form-data instance
    kind === "object" && isFunction$1(thing.toString) && thing.toString() === "[object FormData]";
  };
  const isURLSearchParams = kindOfTest("URLSearchParams");
  const [isReadableStream, isRequest, isResponse, isHeaders] = [
    "ReadableStream",
    "Request",
    "Response",
    "Headers"
  ].map(kindOfTest);
  const trim = (str) => {
    return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  };
  function forEach(obj, fn, { allOwnKeys = false } = {}) {
    if (obj === null || typeof obj === "undefined") {
      return;
    }
    let i;
    let l;
    if (typeof obj !== "object") {
      obj = [obj];
    }
    if (isArray(obj)) {
      for (i = 0, l = obj.length; i < l; i++) {
        fn.call(null, obj[i], i, obj);
      }
    } else {
      if (isBuffer(obj)) {
        return;
      }
      const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
      const len = keys.length;
      let key;
      for (i = 0; i < len; i++) {
        key = keys[i];
        fn.call(null, obj[key], key, obj);
      }
    }
  }
  function findKey(obj, key) {
    if (isBuffer(obj)) {
      return null;
    }
    key = key.toLowerCase();
    const keys = Object.keys(obj);
    let i = keys.length;
    let _key;
    while (i-- > 0) {
      _key = keys[i];
      if (key === _key.toLowerCase()) {
        return _key;
      }
    }
    return null;
  }
  const _global = (() => {
    if (typeof globalThis !== "undefined") return globalThis;
    return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
  })();
  const isContextDefined = (context) => !isUndefined(context) && context !== _global;
  function merge() {
    const { caseless, skipUndefined } = isContextDefined(this) && this || {};
    const result = {};
    const assignValue = (val, key) => {
      if (key === "__proto__" || key === "constructor" || key === "prototype") {
        return;
      }
      const targetKey = caseless && findKey(result, key) || key;
      if (isPlainObject(result[targetKey]) && isPlainObject(val)) {
        result[targetKey] = merge(result[targetKey], val);
      } else if (isPlainObject(val)) {
        result[targetKey] = merge({}, val);
      } else if (isArray(val)) {
        result[targetKey] = val.slice();
      } else if (!skipUndefined || !isUndefined(val)) {
        result[targetKey] = val;
      }
    };
    for (let i = 0, l = arguments.length; i < l; i++) {
      arguments[i] && forEach(arguments[i], assignValue);
    }
    return result;
  }
  const extend = (a, b, thisArg, { allOwnKeys } = {}) => {
    forEach(
      b,
      (val, key) => {
        if (thisArg && isFunction$1(val)) {
          Object.defineProperty(a, key, {
            value: bind(val, thisArg),
            writable: true,
            enumerable: true,
            configurable: true
          });
        } else {
          Object.defineProperty(a, key, {
            value: val,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      },
      { allOwnKeys }
    );
    return a;
  };
  const stripBOM = (content) => {
    if (content.charCodeAt(0) === 65279) {
      content = content.slice(1);
    }
    return content;
  };
  const inherits = (constructor, superConstructor, props, descriptors) => {
    constructor.prototype = Object.create(superConstructor.prototype, descriptors);
    Object.defineProperty(constructor.prototype, "constructor", {
      value: constructor,
      writable: true,
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(constructor, "super", {
      value: superConstructor.prototype
    });
    props && Object.assign(constructor.prototype, props);
  };
  const toFlatObject = (sourceObj, destObj, filter, propFilter) => {
    let props;
    let i;
    let prop;
    const merged = {};
    destObj = destObj || {};
    if (sourceObj == null) return destObj;
    do {
      props = Object.getOwnPropertyNames(sourceObj);
      i = props.length;
      while (i-- > 0) {
        prop = props[i];
        if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
          destObj[prop] = sourceObj[prop];
          merged[prop] = true;
        }
      }
      sourceObj = filter !== false && getPrototypeOf(sourceObj);
    } while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
    return destObj;
  };
  const endsWith = (str, searchString, position) => {
    str = String(str);
    if (position === void 0 || position > str.length) {
      position = str.length;
    }
    position -= searchString.length;
    const lastIndex = str.indexOf(searchString, position);
    return lastIndex !== -1 && lastIndex === position;
  };
  const toArray = (thing) => {
    if (!thing) return null;
    if (isArray(thing)) return thing;
    let i = thing.length;
    if (!isNumber(i)) return null;
    const arr = new Array(i);
    while (i-- > 0) {
      arr[i] = thing[i];
    }
    return arr;
  };
  const isTypedArray = /* @__PURE__ */ ((TypedArray) => {
    return (thing) => {
      return TypedArray && thing instanceof TypedArray;
    };
  })(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
  const forEachEntry = (obj, fn) => {
    const generator = obj && obj[iterator];
    const _iterator = generator.call(obj);
    let result;
    while ((result = _iterator.next()) && !result.done) {
      const pair = result.value;
      fn.call(obj, pair[0], pair[1]);
    }
  };
  const matchAll = (regExp, str) => {
    let matches;
    const arr = [];
    while ((matches = regExp.exec(str)) !== null) {
      arr.push(matches);
    }
    return arr;
  };
  const isHTMLForm = kindOfTest("HTMLFormElement");
  const toCamelCase = (str) => {
    return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
      return p1.toUpperCase() + p2;
    });
  };
  const hasOwnProperty = (({ hasOwnProperty: hasOwnProperty2 }) => (obj, prop) => hasOwnProperty2.call(obj, prop))(Object.prototype);
  const isRegExp = kindOfTest("RegExp");
  const reduceDescriptors = (obj, reducer) => {
    const descriptors = Object.getOwnPropertyDescriptors(obj);
    const reducedDescriptors = {};
    forEach(descriptors, (descriptor, name) => {
      let ret;
      if ((ret = reducer(descriptor, name, obj)) !== false) {
        reducedDescriptors[name] = ret || descriptor;
      }
    });
    Object.defineProperties(obj, reducedDescriptors);
  };
  const freezeMethods = (obj) => {
    reduceDescriptors(obj, (descriptor, name) => {
      if (isFunction$1(obj) && ["arguments", "caller", "callee"].indexOf(name) !== -1) {
        return false;
      }
      const value = obj[name];
      if (!isFunction$1(value)) return;
      descriptor.enumerable = false;
      if ("writable" in descriptor) {
        descriptor.writable = false;
        return;
      }
      if (!descriptor.set) {
        descriptor.set = () => {
          throw Error("Can not rewrite read-only method '" + name + "'");
        };
      }
    });
  };
  const toObjectSet = (arrayOrString, delimiter) => {
    const obj = {};
    const define = (arr) => {
      arr.forEach((value) => {
        obj[value] = true;
      });
    };
    isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
    return obj;
  };
  const noop = () => {
  };
  const toFiniteNumber = (value, defaultValue) => {
    return value != null && Number.isFinite(value = +value) ? value : defaultValue;
  };
  function isSpecCompliantForm(thing) {
    return !!(thing && isFunction$1(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
  }
  const toJSONObject = (obj) => {
    const stack = new Array(10);
    const visit = (source, i) => {
      if (isObject(source)) {
        if (stack.indexOf(source) >= 0) {
          return;
        }
        if (isBuffer(source)) {
          return source;
        }
        if (!("toJSON" in source)) {
          stack[i] = source;
          const target = isArray(source) ? [] : {};
          forEach(source, (value, key) => {
            const reducedValue = visit(value, i + 1);
            !isUndefined(reducedValue) && (target[key] = reducedValue);
          });
          stack[i] = void 0;
          return target;
        }
      }
      return source;
    };
    return visit(obj, 0);
  };
  const isAsyncFn = kindOfTest("AsyncFunction");
  const isThenable = (thing) => thing && (isObject(thing) || isFunction$1(thing)) && isFunction$1(thing.then) && isFunction$1(thing.catch);
  const _setImmediate = ((setImmediateSupported, postMessageSupported) => {
    if (setImmediateSupported) {
      return setImmediate;
    }
    return postMessageSupported ? ((token, callbacks) => {
      _global.addEventListener(
        "message",
        ({ source, data }) => {
          if (source === _global && data === token) {
            callbacks.length && callbacks.shift()();
          }
        },
        false
      );
      return (cb) => {
        callbacks.push(cb);
        _global.postMessage(token, "*");
      };
    })(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
  })(typeof setImmediate === "function", isFunction$1(_global.postMessage));
  const asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
  const isIterable = (thing) => thing != null && isFunction$1(thing[iterator]);
  const utils$1 = {
    isArray,
    isArrayBuffer,
    isBuffer,
    isFormData,
    isArrayBufferView,
    isString,
    isNumber,
    isBoolean,
    isObject,
    isPlainObject,
    isEmptyObject,
    isReadableStream,
    isRequest,
    isResponse,
    isHeaders,
    isUndefined,
    isDate,
    isFile,
    isReactNativeBlob,
    isReactNative,
    isBlob,
    isRegExp,
    isFunction: isFunction$1,
    isStream,
    isURLSearchParams,
    isTypedArray,
    isFileList,
    forEach,
    merge,
    extend,
    trim,
    stripBOM,
    inherits,
    toFlatObject,
    kindOf,
    kindOfTest,
    endsWith,
    toArray,
    forEachEntry,
    matchAll,
    isHTMLForm,
    hasOwnProperty,
    hasOwnProp: hasOwnProperty,
    // an alias to avoid ESLint no-prototype-builtins detection
    reduceDescriptors,
    freezeMethods,
    toObjectSet,
    toCamelCase,
    noop,
    toFiniteNumber,
    findKey,
    global: _global,
    isContextDefined,
    isSpecCompliantForm,
    toJSONObject,
    isAsyncFn,
    isThenable,
    setImmediate: _setImmediate,
    asap,
    isIterable
  };
  let AxiosError$1 = class AxiosError2 extends Error {
    static from(error, code, config, request, response, customProps) {
      const axiosError = new AxiosError2(error.message, code || error.code, config, request, response);
      axiosError.cause = error;
      axiosError.name = error.name;
      if (error.status != null && axiosError.status == null) {
        axiosError.status = error.status;
      }
      customProps && Object.assign(axiosError, customProps);
      return axiosError;
    }
    /**
     * Create an Error with the specified message, config, error code, request and response.
     *
     * @param {string} message The error message.
     * @param {string} [code] The error code (for example, 'ECONNABORTED').
     * @param {Object} [config] The config.
     * @param {Object} [request] The request.
     * @param {Object} [response] The response.
     *
     * @returns {Error} The created error.
     */
    constructor(message, code, config, request, response) {
      super(message);
      Object.defineProperty(this, "message", {
        value: message,
        enumerable: true,
        writable: true,
        configurable: true
      });
      this.name = "AxiosError";
      this.isAxiosError = true;
      code && (this.code = code);
      config && (this.config = config);
      request && (this.request = request);
      if (response) {
        this.response = response;
        this.status = response.status;
      }
    }
    toJSON() {
      return {
        // Standard
        message: this.message,
        name: this.name,
        // Microsoft
        description: this.description,
        number: this.number,
        // Mozilla
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        // Axios
        config: utils$1.toJSONObject(this.config),
        code: this.code,
        status: this.status
      };
    }
  };
  AxiosError$1.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
  AxiosError$1.ERR_BAD_OPTION = "ERR_BAD_OPTION";
  AxiosError$1.ECONNABORTED = "ECONNABORTED";
  AxiosError$1.ETIMEDOUT = "ETIMEDOUT";
  AxiosError$1.ERR_NETWORK = "ERR_NETWORK";
  AxiosError$1.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
  AxiosError$1.ERR_DEPRECATED = "ERR_DEPRECATED";
  AxiosError$1.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
  AxiosError$1.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
  AxiosError$1.ERR_CANCELED = "ERR_CANCELED";
  AxiosError$1.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
  AxiosError$1.ERR_INVALID_URL = "ERR_INVALID_URL";
  AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
  const httpAdapter = null;
  function isVisitable(thing) {
    return utils$1.isPlainObject(thing) || utils$1.isArray(thing);
  }
  function removeBrackets(key) {
    return utils$1.endsWith(key, "[]") ? key.slice(0, -2) : key;
  }
  function renderKey(path, key, dots) {
    if (!path) return key;
    return path.concat(key).map(function each(token, i) {
      token = removeBrackets(token);
      return !dots && i ? "[" + token + "]" : token;
    }).join(dots ? "." : "");
  }
  function isFlatArray(arr) {
    return utils$1.isArray(arr) && !arr.some(isVisitable);
  }
  const predicates = utils$1.toFlatObject(utils$1, {}, null, function filter(prop) {
    return /^is[A-Z]/.test(prop);
  });
  function toFormData$1(obj, formData, options) {
    if (!utils$1.isObject(obj)) {
      throw new TypeError("target must be an object");
    }
    formData = formData || new FormData();
    options = utils$1.toFlatObject(
      options,
      {
        metaTokens: true,
        dots: false,
        indexes: false
      },
      false,
      function defined(option, source) {
        return !utils$1.isUndefined(source[option]);
      }
    );
    const metaTokens = options.metaTokens;
    const visitor = options.visitor || defaultVisitor;
    const dots = options.dots;
    const indexes = options.indexes;
    const _Blob = options.Blob || typeof Blob !== "undefined" && Blob;
    const maxDepth = options.maxDepth === void 0 ? 100 : options.maxDepth;
    const useBlob = _Blob && utils$1.isSpecCompliantForm(formData);
    if (!utils$1.isFunction(visitor)) {
      throw new TypeError("visitor must be a function");
    }
    function convertValue(value) {
      if (value === null) return "";
      if (utils$1.isDate(value)) {
        return value.toISOString();
      }
      if (utils$1.isBoolean(value)) {
        return value.toString();
      }
      if (!useBlob && utils$1.isBlob(value)) {
        throw new AxiosError$1("Blob is not supported. Use a Buffer instead.");
      }
      if (utils$1.isArrayBuffer(value) || utils$1.isTypedArray(value)) {
        return useBlob && typeof Blob === "function" ? new Blob([value]) : Buffer.from(value);
      }
      return value;
    }
    function defaultVisitor(value, key, path) {
      let arr = value;
      if (utils$1.isReactNative(formData) && utils$1.isReactNativeBlob(value)) {
        formData.append(renderKey(path, key, dots), convertValue(value));
        return false;
      }
      if (value && !path && typeof value === "object") {
        if (utils$1.endsWith(key, "{}")) {
          key = metaTokens ? key : key.slice(0, -2);
          value = JSON.stringify(value);
        } else if (utils$1.isArray(value) && isFlatArray(value) || (utils$1.isFileList(value) || utils$1.endsWith(key, "[]")) && (arr = utils$1.toArray(value))) {
          key = removeBrackets(key);
          arr.forEach(function each(el, index) {
            !(utils$1.isUndefined(el) || el === null) && formData.append(
              // eslint-disable-next-line no-nested-ternary
              indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]",
              convertValue(el)
            );
          });
          return false;
        }
      }
      if (isVisitable(value)) {
        return true;
      }
      formData.append(renderKey(path, key, dots), convertValue(value));
      return false;
    }
    const stack = [];
    const exposedHelpers = Object.assign(predicates, {
      defaultVisitor,
      convertValue,
      isVisitable
    });
    function build(value, path, depth = 0) {
      if (utils$1.isUndefined(value)) return;
      if (depth > maxDepth) {
        throw new AxiosError$1(
          "Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth,
          AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED
        );
      }
      if (stack.indexOf(value) !== -1) {
        throw Error("Circular reference detected in " + path.join("."));
      }
      stack.push(value);
      utils$1.forEach(value, function each(el, key) {
        const result = !(utils$1.isUndefined(el) || el === null) && visitor.call(formData, el, utils$1.isString(key) ? key.trim() : key, path, exposedHelpers);
        if (result === true) {
          build(el, path ? path.concat(key) : [key], depth + 1);
        }
      });
      stack.pop();
    }
    if (!utils$1.isObject(obj)) {
      throw new TypeError("data must be an object");
    }
    build(obj);
    return formData;
  }
  function encode$1(str) {
    const charMap = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+"
    };
    return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
      return charMap[match];
    });
  }
  function AxiosURLSearchParams(params, options) {
    this._pairs = [];
    params && toFormData$1(params, this, options);
  }
  const prototype = AxiosURLSearchParams.prototype;
  prototype.append = function append(name, value) {
    this._pairs.push([name, value]);
  };
  prototype.toString = function toString2(encoder) {
    const _encode = encoder ? function(value) {
      return encoder.call(this, value, encode$1);
    } : encode$1;
    return this._pairs.map(function each(pair) {
      return _encode(pair[0]) + "=" + _encode(pair[1]);
    }, "").join("&");
  };
  function encode(val) {
    return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
  }
  function buildURL(url, params, options) {
    if (!params) {
      return url;
    }
    const _encode = options && options.encode || encode;
    const _options = utils$1.isFunction(options) ? {
      serialize: options
    } : options;
    const serializeFn = _options && _options.serialize;
    let serializedParams;
    if (serializeFn) {
      serializedParams = serializeFn(params, _options);
    } else {
      serializedParams = utils$1.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, _options).toString(_encode);
    }
    if (serializedParams) {
      const hashmarkIndex = url.indexOf("#");
      if (hashmarkIndex !== -1) {
        url = url.slice(0, hashmarkIndex);
      }
      url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
    }
    return url;
  }
  class InterceptorManager {
    constructor() {
      this.handlers = [];
    }
    /**
     * Add a new interceptor to the stack
     *
     * @param {Function} fulfilled The function to handle `then` for a `Promise`
     * @param {Function} rejected The function to handle `reject` for a `Promise`
     * @param {Object} options The options for the interceptor, synchronous and runWhen
     *
     * @return {Number} An ID used to remove interceptor later
     */
    use(fulfilled, rejected, options) {
      this.handlers.push({
        fulfilled,
        rejected,
        synchronous: options ? options.synchronous : false,
        runWhen: options ? options.runWhen : null
      });
      return this.handlers.length - 1;
    }
    /**
     * Remove an interceptor from the stack
     *
     * @param {Number} id The ID that was returned by `use`
     *
     * @returns {void}
     */
    eject(id) {
      if (this.handlers[id]) {
        this.handlers[id] = null;
      }
    }
    /**
     * Clear all interceptors from the stack
     *
     * @returns {void}
     */
    clear() {
      if (this.handlers) {
        this.handlers = [];
      }
    }
    /**
     * Iterate over all the registered interceptors
     *
     * This method is particularly useful for skipping over any
     * interceptors that may have become `null` calling `eject`.
     *
     * @param {Function} fn The function to call for each interceptor
     *
     * @returns {void}
     */
    forEach(fn) {
      utils$1.forEach(this.handlers, function forEachHandler(h) {
        if (h !== null) {
          fn(h);
        }
      });
    }
  }
  const transitionalDefaults = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false,
    legacyInterceptorReqResOrdering: true
  };
  const URLSearchParams$1 = typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams;
  const FormData$1 = typeof FormData !== "undefined" ? FormData : null;
  const Blob$1 = typeof Blob !== "undefined" ? Blob : null;
  const platform$1 = {
    isBrowser: true,
    classes: {
      URLSearchParams: URLSearchParams$1,
      FormData: FormData$1,
      Blob: Blob$1
    },
    protocols: ["http", "https", "file", "blob", "url", "data"]
  };
  const hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
  const _navigator = typeof navigator === "object" && navigator || void 0;
  const hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || ["ReactNative", "NativeScript", "NS"].indexOf(_navigator.product) < 0);
  const hasStandardBrowserWebWorkerEnv = (() => {
    return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
    self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
  })();
  const origin = hasBrowserEnv && window.location.href || "http://localhost";
  const utils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hasBrowserEnv,
    hasStandardBrowserEnv,
    hasStandardBrowserWebWorkerEnv,
    navigator: _navigator,
    origin
  }, Symbol.toStringTag, { value: "Module" }));
  const platform = {
    ...utils,
    ...platform$1
  };
  function toURLEncodedForm(data, options) {
    return toFormData$1(data, new platform.classes.URLSearchParams(), {
      visitor: function(value, key, path, helpers) {
        if (platform.isNode && utils$1.isBuffer(value)) {
          this.append(key, value.toString("base64"));
          return false;
        }
        return helpers.defaultVisitor.apply(this, arguments);
      },
      ...options
    });
  }
  function parsePropPath(name) {
    return utils$1.matchAll(/\w+|\[(\w*)]/g, name).map((match) => {
      return match[0] === "[]" ? "" : match[1] || match[0];
    });
  }
  function arrayToObject(arr) {
    const obj = {};
    const keys = Object.keys(arr);
    let i;
    const len = keys.length;
    let key;
    for (i = 0; i < len; i++) {
      key = keys[i];
      obj[key] = arr[key];
    }
    return obj;
  }
  function formDataToJSON(formData) {
    function buildPath(path, value, target, index) {
      let name = path[index++];
      if (name === "__proto__") return true;
      const isNumericKey = Number.isFinite(+name);
      const isLast = index >= path.length;
      name = !name && utils$1.isArray(target) ? target.length : name;
      if (isLast) {
        if (utils$1.hasOwnProp(target, name)) {
          target[name] = utils$1.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
        } else {
          target[name] = value;
        }
        return !isNumericKey;
      }
      if (!target[name] || !utils$1.isObject(target[name])) {
        target[name] = [];
      }
      const result = buildPath(path, value, target[name], index);
      if (result && utils$1.isArray(target[name])) {
        target[name] = arrayToObject(target[name]);
      }
      return !isNumericKey;
    }
    if (utils$1.isFormData(formData) && utils$1.isFunction(formData.entries)) {
      const obj = {};
      utils$1.forEachEntry(formData, (name, value) => {
        buildPath(parsePropPath(name), value, obj, 0);
      });
      return obj;
    }
    return null;
  }
  const own = (obj, key) => obj != null && utils$1.hasOwnProp(obj, key) ? obj[key] : void 0;
  function stringifySafely(rawValue, parser, encoder) {
    if (utils$1.isString(rawValue)) {
      try {
        (parser || JSON.parse)(rawValue);
        return utils$1.trim(rawValue);
      } catch (e) {
        if (e.name !== "SyntaxError") {
          throw e;
        }
      }
    }
    return (encoder || JSON.stringify)(rawValue);
  }
  const defaults = {
    transitional: transitionalDefaults,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [
      function transformRequest(data, headers) {
        const contentType = headers.getContentType() || "";
        const hasJSONContentType = contentType.indexOf("application/json") > -1;
        const isObjectPayload = utils$1.isObject(data);
        if (isObjectPayload && utils$1.isHTMLForm(data)) {
          data = new FormData(data);
        }
        const isFormData2 = utils$1.isFormData(data);
        if (isFormData2) {
          return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
        }
        if (utils$1.isArrayBuffer(data) || utils$1.isBuffer(data) || utils$1.isStream(data) || utils$1.isFile(data) || utils$1.isBlob(data) || utils$1.isReadableStream(data)) {
          return data;
        }
        if (utils$1.isArrayBufferView(data)) {
          return data.buffer;
        }
        if (utils$1.isURLSearchParams(data)) {
          headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
          return data.toString();
        }
        let isFileList2;
        if (isObjectPayload) {
          const formSerializer = own(this, "formSerializer");
          if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
            return toURLEncodedForm(data, formSerializer).toString();
          }
          if ((isFileList2 = utils$1.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
            const env = own(this, "env");
            const _FormData = env && env.FormData;
            return toFormData$1(
              isFileList2 ? { "files[]": data } : data,
              _FormData && new _FormData(),
              formSerializer
            );
          }
        }
        if (isObjectPayload || hasJSONContentType) {
          headers.setContentType("application/json", false);
          return stringifySafely(data);
        }
        return data;
      }
    ],
    transformResponse: [
      function transformResponse(data) {
        const transitional = own(this, "transitional") || defaults.transitional;
        const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
        const responseType = own(this, "responseType");
        const JSONRequested = responseType === "json";
        if (utils$1.isResponse(data) || utils$1.isReadableStream(data)) {
          return data;
        }
        if (data && utils$1.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
          const silentJSONParsing = transitional && transitional.silentJSONParsing;
          const strictJSONParsing = !silentJSONParsing && JSONRequested;
          try {
            return JSON.parse(data, own(this, "parseReviver"));
          } catch (e) {
            if (strictJSONParsing) {
              if (e.name === "SyntaxError") {
                throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_RESPONSE, this, null, own(this, "response"));
              }
              throw e;
            }
          }
        }
        return data;
      }
    ],
    /**
     * A timeout in milliseconds to abort a request. If set to 0 (default) a
     * timeout is not created.
     */
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
      FormData: platform.classes.FormData,
      Blob: platform.classes.Blob
    },
    validateStatus: function validateStatus(status) {
      return status >= 200 && status < 300;
    },
    headers: {
      common: {
        Accept: "application/json, text/plain, */*",
        "Content-Type": void 0
      }
    }
  };
  utils$1.forEach(["delete", "get", "head", "post", "put", "patch"], (method) => {
    defaults.headers[method] = {};
  });
  const ignoreDuplicateOf = utils$1.toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ]);
  const parseHeaders = (rawHeaders) => {
    const parsed = {};
    let key;
    let val;
    let i;
    rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
      i = line.indexOf(":");
      key = line.substring(0, i).trim().toLowerCase();
      val = line.substring(i + 1).trim();
      if (!key || parsed[key] && ignoreDuplicateOf[key]) {
        return;
      }
      if (key === "set-cookie") {
        if (parsed[key]) {
          parsed[key].push(val);
        } else {
          parsed[key] = [val];
        }
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
      }
    });
    return parsed;
  };
  const $internals = /* @__PURE__ */ Symbol("internals");
  const INVALID_HEADER_VALUE_CHARS_RE = /[^\x09\x20-\x7E\x80-\xFF]/g;
  function trimSPorHTAB(str) {
    let start = 0;
    let end = str.length;
    while (start < end) {
      const code = str.charCodeAt(start);
      if (code !== 9 && code !== 32) {
        break;
      }
      start += 1;
    }
    while (end > start) {
      const code = str.charCodeAt(end - 1);
      if (code !== 9 && code !== 32) {
        break;
      }
      end -= 1;
    }
    return start === 0 && end === str.length ? str : str.slice(start, end);
  }
  function normalizeHeader(header) {
    return header && String(header).trim().toLowerCase();
  }
  function sanitizeHeaderValue(str) {
    return trimSPorHTAB(str.replace(INVALID_HEADER_VALUE_CHARS_RE, ""));
  }
  function normalizeValue(value) {
    if (value === false || value == null) {
      return value;
    }
    return utils$1.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
  }
  function parseTokens(str) {
    const tokens = /* @__PURE__ */ Object.create(null);
    const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let match;
    while (match = tokensRE.exec(str)) {
      tokens[match[1]] = match[2];
    }
    return tokens;
  }
  const isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
  function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
    if (utils$1.isFunction(filter)) {
      return filter.call(this, value, header);
    }
    if (isHeaderNameFilter) {
      value = header;
    }
    if (!utils$1.isString(value)) return;
    if (utils$1.isString(filter)) {
      return value.indexOf(filter) !== -1;
    }
    if (utils$1.isRegExp(filter)) {
      return filter.test(value);
    }
  }
  function formatHeader(header) {
    return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
      return char.toUpperCase() + str;
    });
  }
  function buildAccessors(obj, header) {
    const accessorName = utils$1.toCamelCase(" " + header);
    ["get", "set", "has"].forEach((methodName) => {
      Object.defineProperty(obj, methodName + accessorName, {
        value: function(arg1, arg2, arg3) {
          return this[methodName].call(this, header, arg1, arg2, arg3);
        },
        configurable: true
      });
    });
  }
  let AxiosHeaders$1 = class AxiosHeaders {
    constructor(headers) {
      headers && this.set(headers);
    }
    set(header, valueOrRewrite, rewrite) {
      const self2 = this;
      function setHeader(_value, _header, _rewrite) {
        const lHeader = normalizeHeader(_header);
        if (!lHeader) {
          throw new Error("header name must be a non-empty string");
        }
        const key = utils$1.findKey(self2, lHeader);
        if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
          self2[key || _header] = normalizeValue(_value);
        }
      }
      const setHeaders = (headers, _rewrite) => utils$1.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
      if (utils$1.isPlainObject(header) || header instanceof this.constructor) {
        setHeaders(header, valueOrRewrite);
      } else if (utils$1.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
        setHeaders(parseHeaders(header), valueOrRewrite);
      } else if (utils$1.isObject(header) && utils$1.isIterable(header)) {
        let obj = {}, dest, key;
        for (const entry of header) {
          if (!utils$1.isArray(entry)) {
            throw TypeError("Object iterator must return a key-value pair");
          }
          obj[key = entry[0]] = (dest = obj[key]) ? utils$1.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]] : entry[1];
        }
        setHeaders(obj, valueOrRewrite);
      } else {
        header != null && setHeader(valueOrRewrite, header, rewrite);
      }
      return this;
    }
    get(header, parser) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils$1.findKey(this, header);
        if (key) {
          const value = this[key];
          if (!parser) {
            return value;
          }
          if (parser === true) {
            return parseTokens(value);
          }
          if (utils$1.isFunction(parser)) {
            return parser.call(this, value, key);
          }
          if (utils$1.isRegExp(parser)) {
            return parser.exec(value);
          }
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(header, matcher) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils$1.findKey(this, header);
        return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
      }
      return false;
    }
    delete(header, matcher) {
      const self2 = this;
      let deleted = false;
      function deleteHeader(_header) {
        _header = normalizeHeader(_header);
        if (_header) {
          const key = utils$1.findKey(self2, _header);
          if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
            delete self2[key];
            deleted = true;
          }
        }
      }
      if (utils$1.isArray(header)) {
        header.forEach(deleteHeader);
      } else {
        deleteHeader(header);
      }
      return deleted;
    }
    clear(matcher) {
      const keys = Object.keys(this);
      let i = keys.length;
      let deleted = false;
      while (i--) {
        const key = keys[i];
        if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
          delete this[key];
          deleted = true;
        }
      }
      return deleted;
    }
    normalize(format2) {
      const self2 = this;
      const headers = {};
      utils$1.forEach(this, (value, header) => {
        const key = utils$1.findKey(headers, header);
        if (key) {
          self2[key] = normalizeValue(value);
          delete self2[header];
          return;
        }
        const normalized = format2 ? formatHeader(header) : String(header).trim();
        if (normalized !== header) {
          delete self2[header];
        }
        self2[normalized] = normalizeValue(value);
        headers[normalized] = true;
      });
      return this;
    }
    concat(...targets) {
      return this.constructor.concat(this, ...targets);
    }
    toJSON(asStrings) {
      const obj = /* @__PURE__ */ Object.create(null);
      utils$1.forEach(this, (value, header) => {
        value != null && value !== false && (obj[header] = asStrings && utils$1.isArray(value) ? value.join(", ") : value);
      });
      return obj;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
    }
    getSetCookie() {
      return this.get("set-cookie") || [];
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(thing) {
      return thing instanceof this ? thing : new this(thing);
    }
    static concat(first, ...targets) {
      const computed = new this(first);
      targets.forEach((target) => computed.set(target));
      return computed;
    }
    static accessor(header) {
      const internals = this[$internals] = this[$internals] = {
        accessors: {}
      };
      const accessors = internals.accessors;
      const prototype2 = this.prototype;
      function defineAccessor(_header) {
        const lHeader = normalizeHeader(_header);
        if (!accessors[lHeader]) {
          buildAccessors(prototype2, _header);
          accessors[lHeader] = true;
        }
      }
      utils$1.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
      return this;
    }
  };
  AxiosHeaders$1.accessor([
    "Content-Type",
    "Content-Length",
    "Accept",
    "Accept-Encoding",
    "User-Agent",
    "Authorization"
  ]);
  utils$1.reduceDescriptors(AxiosHeaders$1.prototype, ({ value }, key) => {
    let mapped = key[0].toUpperCase() + key.slice(1);
    return {
      get: () => value,
      set(headerValue) {
        this[mapped] = headerValue;
      }
    };
  });
  utils$1.freezeMethods(AxiosHeaders$1);
  function transformData(fns, response) {
    const config = this || defaults;
    const context = response || config;
    const headers = AxiosHeaders$1.from(context.headers);
    let data = context.data;
    utils$1.forEach(fns, function transform(fn) {
      data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
    });
    headers.normalize();
    return data;
  }
  function isCancel$1(value) {
    return !!(value && value.__CANCEL__);
  }
  let CanceledError$1 = class CanceledError extends AxiosError$1 {
    /**
     * A `CanceledError` is an object that is thrown when an operation is canceled.
     *
     * @param {string=} message The message.
     * @param {Object=} config The config.
     * @param {Object=} request The request.
     *
     * @returns {CanceledError} The created error.
     */
    constructor(message, config, request) {
      super(message == null ? "canceled" : message, AxiosError$1.ERR_CANCELED, config, request);
      this.name = "CanceledError";
      this.__CANCEL__ = true;
    }
  };
  function settle(resolve, reject, response) {
    const validateStatus = response.config.validateStatus;
    if (!response.status || !validateStatus || validateStatus(response.status)) {
      resolve(response);
    } else {
      reject(
        new AxiosError$1(
          "Request failed with status code " + response.status,
          [AxiosError$1.ERR_BAD_REQUEST, AxiosError$1.ERR_BAD_RESPONSE][Math.floor(response.status / 100) - 4],
          response.config,
          response.request,
          response
        )
      );
    }
  }
  function parseProtocol(url) {
    const match = /^([-+\w]{1,25})(:?\/\/|:)/.exec(url);
    return match && match[1] || "";
  }
  function speedometer(samplesCount, min) {
    samplesCount = samplesCount || 10;
    const bytes = new Array(samplesCount);
    const timestamps = new Array(samplesCount);
    let head = 0;
    let tail = 0;
    let firstSampleTS;
    min = min !== void 0 ? min : 1e3;
    return function push(chunkLength) {
      const now = Date.now();
      const startedAt = timestamps[tail];
      if (!firstSampleTS) {
        firstSampleTS = now;
      }
      bytes[head] = chunkLength;
      timestamps[head] = now;
      let i = tail;
      let bytesCount = 0;
      while (i !== head) {
        bytesCount += bytes[i++];
        i = i % samplesCount;
      }
      head = (head + 1) % samplesCount;
      if (head === tail) {
        tail = (tail + 1) % samplesCount;
      }
      if (now - firstSampleTS < min) {
        return;
      }
      const passed = startedAt && now - startedAt;
      return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
    };
  }
  function throttle(fn, freq) {
    let timestamp = 0;
    let threshold = 1e3 / freq;
    let lastArgs;
    let timer;
    const invoke = (args, now = Date.now()) => {
      timestamp = now;
      lastArgs = null;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      fn(...args);
    };
    const throttled = (...args) => {
      const now = Date.now();
      const passed = now - timestamp;
      if (passed >= threshold) {
        invoke(args, now);
      } else {
        lastArgs = args;
        if (!timer) {
          timer = setTimeout(() => {
            timer = null;
            invoke(lastArgs);
          }, threshold - passed);
        }
      }
    };
    const flush = () => lastArgs && invoke(lastArgs);
    return [throttled, flush];
  }
  const progressEventReducer = (listener, isDownloadStream, freq = 3) => {
    let bytesNotified = 0;
    const _speedometer = speedometer(50, 250);
    return throttle((e) => {
      const rawLoaded = e.loaded;
      const total = e.lengthComputable ? e.total : void 0;
      const loaded = total != null ? Math.min(rawLoaded, total) : rawLoaded;
      const progressBytes = Math.max(0, loaded - bytesNotified);
      const rate = _speedometer(progressBytes);
      bytesNotified = Math.max(bytesNotified, loaded);
      const data = {
        loaded,
        total,
        progress: total ? loaded / total : void 0,
        bytes: progressBytes,
        rate: rate ? rate : void 0,
        estimated: rate && total ? (total - loaded) / rate : void 0,
        event: e,
        lengthComputable: total != null,
        [isDownloadStream ? "download" : "upload"]: true
      };
      listener(data);
    }, freq);
  };
  const progressEventDecorator = (total, throttled) => {
    const lengthComputable = total != null;
    return [
      (loaded) => throttled[0]({
        lengthComputable,
        total,
        loaded
      }),
      throttled[1]
    ];
  };
  const asyncDecorator = (fn) => (...args) => utils$1.asap(() => fn(...args));
  const isURLSameOrigin = platform.hasStandardBrowserEnv ? /* @__PURE__ */ ((origin2, isMSIE) => (url) => {
    url = new URL(url, platform.origin);
    return origin2.protocol === url.protocol && origin2.host === url.host && (isMSIE || origin2.port === url.port);
  })(
    new URL(platform.origin),
    platform.navigator && /(msie|trident)/i.test(platform.navigator.userAgent)
  ) : () => true;
  const cookies = platform.hasStandardBrowserEnv ? (
    // Standard browser envs support document.cookie
    {
      write(name, value, expires, path, domain, secure, sameSite) {
        if (typeof document === "undefined") return;
        const cookie = [`${name}=${encodeURIComponent(value)}`];
        if (utils$1.isNumber(expires)) {
          cookie.push(`expires=${new Date(expires).toUTCString()}`);
        }
        if (utils$1.isString(path)) {
          cookie.push(`path=${path}`);
        }
        if (utils$1.isString(domain)) {
          cookie.push(`domain=${domain}`);
        }
        if (secure === true) {
          cookie.push("secure");
        }
        if (utils$1.isString(sameSite)) {
          cookie.push(`SameSite=${sameSite}`);
        }
        document.cookie = cookie.join("; ");
      },
      read(name) {
        if (typeof document === "undefined") return null;
        const match = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
        return match ? decodeURIComponent(match[1]) : null;
      },
      remove(name) {
        this.write(name, "", Date.now() - 864e5, "/");
      }
    }
  ) : (
    // Non-standard browser env (web workers, react-native) lack needed support.
    {
      write() {
      },
      read() {
        return null;
      },
      remove() {
      }
    }
  );
  function isAbsoluteURL(url) {
    if (typeof url !== "string") {
      return false;
    }
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
  }
  function combineURLs(baseURL, relativeURL) {
    return relativeURL ? baseURL.replace(/\/?\/$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
  }
  function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls) {
    let isRelativeUrl = !isAbsoluteURL(requestedURL);
    if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
      return combineURLs(baseURL, requestedURL);
    }
    return requestedURL;
  }
  const headersToObject = (thing) => thing instanceof AxiosHeaders$1 ? { ...thing } : thing;
  function mergeConfig$1(config1, config2) {
    config2 = config2 || {};
    const config = /* @__PURE__ */ Object.create(null);
    Object.defineProperty(config, "hasOwnProperty", {
      value: Object.prototype.hasOwnProperty,
      enumerable: false,
      writable: true,
      configurable: true
    });
    function getMergedValue(target, source, prop, caseless) {
      if (utils$1.isPlainObject(target) && utils$1.isPlainObject(source)) {
        return utils$1.merge.call({ caseless }, target, source);
      } else if (utils$1.isPlainObject(source)) {
        return utils$1.merge({}, source);
      } else if (utils$1.isArray(source)) {
        return source.slice();
      }
      return source;
    }
    function mergeDeepProperties(a, b, prop, caseless) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(a, b, prop, caseless);
      } else if (!utils$1.isUndefined(a)) {
        return getMergedValue(void 0, a, prop, caseless);
      }
    }
    function valueFromConfig2(a, b) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(void 0, b);
      }
    }
    function defaultToConfig2(a, b) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(void 0, b);
      } else if (!utils$1.isUndefined(a)) {
        return getMergedValue(void 0, a);
      }
    }
    function mergeDirectKeys(a, b, prop) {
      if (utils$1.hasOwnProp(config2, prop)) {
        return getMergedValue(a, b);
      } else if (utils$1.hasOwnProp(config1, prop)) {
        return getMergedValue(void 0, a);
      }
    }
    const mergeMap = {
      url: valueFromConfig2,
      method: valueFromConfig2,
      data: valueFromConfig2,
      baseURL: defaultToConfig2,
      transformRequest: defaultToConfig2,
      transformResponse: defaultToConfig2,
      paramsSerializer: defaultToConfig2,
      timeout: defaultToConfig2,
      timeoutMessage: defaultToConfig2,
      withCredentials: defaultToConfig2,
      withXSRFToken: defaultToConfig2,
      adapter: defaultToConfig2,
      responseType: defaultToConfig2,
      xsrfCookieName: defaultToConfig2,
      xsrfHeaderName: defaultToConfig2,
      onUploadProgress: defaultToConfig2,
      onDownloadProgress: defaultToConfig2,
      decompress: defaultToConfig2,
      maxContentLength: defaultToConfig2,
      maxBodyLength: defaultToConfig2,
      beforeRedirect: defaultToConfig2,
      transport: defaultToConfig2,
      httpAgent: defaultToConfig2,
      httpsAgent: defaultToConfig2,
      cancelToken: defaultToConfig2,
      socketPath: defaultToConfig2,
      allowedSocketPaths: defaultToConfig2,
      responseEncoding: defaultToConfig2,
      validateStatus: mergeDirectKeys,
      headers: (a, b, prop) => mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true)
    };
    utils$1.forEach(Object.keys({ ...config1, ...config2 }), function computeConfigValue(prop) {
      if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
      const merge2 = utils$1.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
      const a = utils$1.hasOwnProp(config1, prop) ? config1[prop] : void 0;
      const b = utils$1.hasOwnProp(config2, prop) ? config2[prop] : void 0;
      const configValue = merge2(a, b, prop);
      utils$1.isUndefined(configValue) && merge2 !== mergeDirectKeys || (config[prop] = configValue);
    });
    return config;
  }
  const resolveConfig = (config) => {
    const newConfig = mergeConfig$1({}, config);
    const own2 = (key) => utils$1.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
    const data = own2("data");
    let withXSRFToken = own2("withXSRFToken");
    const xsrfHeaderName = own2("xsrfHeaderName");
    const xsrfCookieName = own2("xsrfCookieName");
    let headers = own2("headers");
    const auth = own2("auth");
    const baseURL = own2("baseURL");
    const allowAbsoluteUrls = own2("allowAbsoluteUrls");
    const url = own2("url");
    newConfig.headers = headers = AxiosHeaders$1.from(headers);
    newConfig.url = buildURL(
      buildFullPath(baseURL, url, allowAbsoluteUrls),
      config.params,
      config.paramsSerializer
    );
    if (auth) {
      headers.set(
        "Authorization",
        "Basic " + btoa(
          (auth.username || "") + ":" + (auth.password ? unescape(encodeURIComponent(auth.password)) : "")
        )
      );
    }
    if (utils$1.isFormData(data)) {
      if (platform.hasStandardBrowserEnv || platform.hasStandardBrowserWebWorkerEnv) {
        headers.setContentType(void 0);
      } else if (utils$1.isFunction(data.getHeaders)) {
        const formHeaders = data.getHeaders();
        const allowedHeaders = ["content-type", "content-length"];
        Object.entries(formHeaders).forEach(([key, val]) => {
          if (allowedHeaders.includes(key.toLowerCase())) {
            headers.set(key, val);
          }
        });
      }
    }
    if (platform.hasStandardBrowserEnv) {
      if (utils$1.isFunction(withXSRFToken)) {
        withXSRFToken = withXSRFToken(newConfig);
      }
      const shouldSendXSRF = withXSRFToken === true || withXSRFToken == null && isURLSameOrigin(newConfig.url);
      if (shouldSendXSRF) {
        const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies.read(xsrfCookieName);
        if (xsrfValue) {
          headers.set(xsrfHeaderName, xsrfValue);
        }
      }
    }
    return newConfig;
  };
  const isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
  const xhrAdapter = isXHRAdapterSupported && function(config) {
    return new Promise(function dispatchXhrRequest(resolve, reject) {
      const _config = resolveConfig(config);
      let requestData = _config.data;
      const requestHeaders = AxiosHeaders$1.from(_config.headers).normalize();
      let { responseType, onUploadProgress, onDownloadProgress } = _config;
      let onCanceled;
      let uploadThrottled, downloadThrottled;
      let flushUpload, flushDownload;
      function done() {
        flushUpload && flushUpload();
        flushDownload && flushDownload();
        _config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
        _config.signal && _config.signal.removeEventListener("abort", onCanceled);
      }
      let request = new XMLHttpRequest();
      request.open(_config.method.toUpperCase(), _config.url, true);
      request.timeout = _config.timeout;
      function onloadend() {
        if (!request) {
          return;
        }
        const responseHeaders = AxiosHeaders$1.from(
          "getAllResponseHeaders" in request && request.getAllResponseHeaders()
        );
        const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
        const response = {
          data: responseData,
          status: request.status,
          statusText: request.statusText,
          headers: responseHeaders,
          config,
          request
        };
        settle(
          function _resolve(value) {
            resolve(value);
            done();
          },
          function _reject(err) {
            reject(err);
            done();
          },
          response
        );
        request = null;
      }
      if ("onloadend" in request) {
        request.onloadend = onloadend;
      } else {
        request.onreadystatechange = function handleLoad() {
          if (!request || request.readyState !== 4) {
            return;
          }
          if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf("file:") === 0)) {
            return;
          }
          setTimeout(onloadend);
        };
      }
      request.onabort = function handleAbort() {
        if (!request) {
          return;
        }
        reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
        request = null;
      };
      request.onerror = function handleError(event) {
        const msg = event && event.message ? event.message : "Network Error";
        const err = new AxiosError$1(msg, AxiosError$1.ERR_NETWORK, config, request);
        err.event = event || null;
        reject(err);
        request = null;
      };
      request.ontimeout = function handleTimeout() {
        let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
        const transitional = _config.transitional || transitionalDefaults;
        if (_config.timeoutErrorMessage) {
          timeoutErrorMessage = _config.timeoutErrorMessage;
        }
        reject(
          new AxiosError$1(
            timeoutErrorMessage,
            transitional.clarifyTimeoutError ? AxiosError$1.ETIMEDOUT : AxiosError$1.ECONNABORTED,
            config,
            request
          )
        );
        request = null;
      };
      requestData === void 0 && requestHeaders.setContentType(null);
      if ("setRequestHeader" in request) {
        utils$1.forEach(requestHeaders.toJSON(), function setRequestHeader(val, key) {
          request.setRequestHeader(key, val);
        });
      }
      if (!utils$1.isUndefined(_config.withCredentials)) {
        request.withCredentials = !!_config.withCredentials;
      }
      if (responseType && responseType !== "json") {
        request.responseType = _config.responseType;
      }
      if (onDownloadProgress) {
        [downloadThrottled, flushDownload] = progressEventReducer(onDownloadProgress, true);
        request.addEventListener("progress", downloadThrottled);
      }
      if (onUploadProgress && request.upload) {
        [uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
        request.upload.addEventListener("progress", uploadThrottled);
        request.upload.addEventListener("loadend", flushUpload);
      }
      if (_config.cancelToken || _config.signal) {
        onCanceled = (cancel) => {
          if (!request) {
            return;
          }
          reject(!cancel || cancel.type ? new CanceledError$1(null, config, request) : cancel);
          request.abort();
          request = null;
        };
        _config.cancelToken && _config.cancelToken.subscribe(onCanceled);
        if (_config.signal) {
          _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
        }
      }
      const protocol = parseProtocol(_config.url);
      if (protocol && platform.protocols.indexOf(protocol) === -1) {
        reject(
          new AxiosError$1(
            "Unsupported protocol " + protocol + ":",
            AxiosError$1.ERR_BAD_REQUEST,
            config
          )
        );
        return;
      }
      request.send(requestData || null);
    });
  };
  const composeSignals = (signals, timeout) => {
    const { length } = signals = signals ? signals.filter(Boolean) : [];
    if (timeout || length) {
      let controller = new AbortController();
      let aborted;
      const onabort = function(reason) {
        if (!aborted) {
          aborted = true;
          unsubscribe();
          const err = reason instanceof Error ? reason : this.reason;
          controller.abort(
            err instanceof AxiosError$1 ? err : new CanceledError$1(err instanceof Error ? err.message : err)
          );
        }
      };
      let timer = timeout && setTimeout(() => {
        timer = null;
        onabort(new AxiosError$1(`timeout of ${timeout}ms exceeded`, AxiosError$1.ETIMEDOUT));
      }, timeout);
      const unsubscribe = () => {
        if (signals) {
          timer && clearTimeout(timer);
          timer = null;
          signals.forEach((signal2) => {
            signal2.unsubscribe ? signal2.unsubscribe(onabort) : signal2.removeEventListener("abort", onabort);
          });
          signals = null;
        }
      };
      signals.forEach((signal2) => signal2.addEventListener("abort", onabort));
      const { signal } = controller;
      signal.unsubscribe = () => utils$1.asap(unsubscribe);
      return signal;
    }
  };
  const streamChunk = function* (chunk, chunkSize) {
    let len = chunk.byteLength;
    if (len < chunkSize) {
      yield chunk;
      return;
    }
    let pos = 0;
    let end;
    while (pos < len) {
      end = pos + chunkSize;
      yield chunk.slice(pos, end);
      pos = end;
    }
  };
  const readBytes = async function* (iterable, chunkSize) {
    for await (const chunk of readStream(iterable)) {
      yield* streamChunk(chunk, chunkSize);
    }
  };
  const readStream = async function* (stream) {
    if (stream[Symbol.asyncIterator]) {
      yield* stream;
      return;
    }
    const reader = stream.getReader();
    try {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) {
          break;
        }
        yield value;
      }
    } finally {
      await reader.cancel();
    }
  };
  const trackStream = (stream, chunkSize, onProgress, onFinish) => {
    const iterator2 = readBytes(stream, chunkSize);
    let bytes = 0;
    let done;
    let _onFinish = (e) => {
      if (!done) {
        done = true;
        onFinish && onFinish(e);
      }
    };
    return new ReadableStream(
      {
        async pull(controller) {
          try {
            const { done: done2, value } = await iterator2.next();
            if (done2) {
              _onFinish();
              controller.close();
              return;
            }
            let len = value.byteLength;
            if (onProgress) {
              let loadedBytes = bytes += len;
              onProgress(loadedBytes);
            }
            controller.enqueue(new Uint8Array(value));
          } catch (err) {
            _onFinish(err);
            throw err;
          }
        },
        cancel(reason) {
          _onFinish(reason);
          return iterator2.return();
        }
      },
      {
        highWaterMark: 2
      }
    );
  };
  const DEFAULT_CHUNK_SIZE = 64 * 1024;
  const { isFunction } = utils$1;
  const globalFetchAPI = (({ Request, Response }) => ({
    Request,
    Response
  }))(utils$1.global);
  const { ReadableStream: ReadableStream$1, TextEncoder } = utils$1.global;
  const test = (fn, ...args) => {
    try {
      return !!fn(...args);
    } catch (e) {
      return false;
    }
  };
  const factory = (env) => {
    env = utils$1.merge.call(
      {
        skipUndefined: true
      },
      globalFetchAPI,
      env
    );
    const { fetch: envFetch, Request, Response } = env;
    const isFetchSupported = envFetch ? isFunction(envFetch) : typeof fetch === "function";
    const isRequestSupported = isFunction(Request);
    const isResponseSupported = isFunction(Response);
    if (!isFetchSupported) {
      return false;
    }
    const isReadableStreamSupported = isFetchSupported && isFunction(ReadableStream$1);
    const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? /* @__PURE__ */ ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Request(str).arrayBuffer()));
    const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
      let duplexAccessed = false;
      const request = new Request(platform.origin, {
        body: new ReadableStream$1(),
        method: "POST",
        get duplex() {
          duplexAccessed = true;
          return "half";
        }
      });
      const hasContentType = request.headers.has("Content-Type");
      if (request.body != null) {
        request.body.cancel();
      }
      return duplexAccessed && !hasContentType;
    });
    const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils$1.isReadableStream(new Response("").body));
    const resolvers = {
      stream: supportsResponseStream && ((res) => res.body)
    };
    isFetchSupported && (() => {
      ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((type) => {
        !resolvers[type] && (resolvers[type] = (res, config) => {
          let method = res && res[type];
          if (method) {
            return method.call(res);
          }
          throw new AxiosError$1(
            `Response type '${type}' is not supported`,
            AxiosError$1.ERR_NOT_SUPPORT,
            config
          );
        });
      });
    })();
    const getBodyLength = async (body) => {
      if (body == null) {
        return 0;
      }
      if (utils$1.isBlob(body)) {
        return body.size;
      }
      if (utils$1.isSpecCompliantForm(body)) {
        const _request = new Request(platform.origin, {
          method: "POST",
          body
        });
        return (await _request.arrayBuffer()).byteLength;
      }
      if (utils$1.isArrayBufferView(body) || utils$1.isArrayBuffer(body)) {
        return body.byteLength;
      }
      if (utils$1.isURLSearchParams(body)) {
        body = body + "";
      }
      if (utils$1.isString(body)) {
        return (await encodeText(body)).byteLength;
      }
    };
    const resolveBodyLength = async (headers, body) => {
      const length = utils$1.toFiniteNumber(headers.getContentLength());
      return length == null ? getBodyLength(body) : length;
    };
    return async (config) => {
      let {
        url,
        method,
        data,
        signal,
        cancelToken,
        timeout,
        onDownloadProgress,
        onUploadProgress,
        responseType,
        headers,
        withCredentials = "same-origin",
        fetchOptions
      } = resolveConfig(config);
      let _fetch = envFetch || fetch;
      responseType = responseType ? (responseType + "").toLowerCase() : "text";
      let composedSignal = composeSignals(
        [signal, cancelToken && cancelToken.toAbortSignal()],
        timeout
      );
      let request = null;
      const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
        composedSignal.unsubscribe();
      });
      let requestContentLength;
      try {
        if (onUploadProgress && supportsRequestStream && method !== "get" && method !== "head" && (requestContentLength = await resolveBodyLength(headers, data)) !== 0) {
          let _request = new Request(url, {
            method: "POST",
            body: data,
            duplex: "half"
          });
          let contentTypeHeader;
          if (utils$1.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) {
            headers.setContentType(contentTypeHeader);
          }
          if (_request.body) {
            const [onProgress, flush] = progressEventDecorator(
              requestContentLength,
              progressEventReducer(asyncDecorator(onUploadProgress))
            );
            data = trackStream(_request.body, DEFAULT_CHUNK_SIZE, onProgress, flush);
          }
        }
        if (!utils$1.isString(withCredentials)) {
          withCredentials = withCredentials ? "include" : "omit";
        }
        const isCredentialsSupported = isRequestSupported && "credentials" in Request.prototype;
        if (utils$1.isFormData(data)) {
          const contentType = headers.getContentType();
          if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) {
            headers.delete("content-type");
          }
        }
        const resolvedOptions = {
          ...fetchOptions,
          signal: composedSignal,
          method: method.toUpperCase(),
          headers: headers.normalize().toJSON(),
          body: data,
          duplex: "half",
          credentials: isCredentialsSupported ? withCredentials : void 0
        };
        request = isRequestSupported && new Request(url, resolvedOptions);
        let response = await (isRequestSupported ? _fetch(request, fetchOptions) : _fetch(url, resolvedOptions));
        const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
        if (supportsResponseStream && (onDownloadProgress || isStreamResponse && unsubscribe)) {
          const options = {};
          ["status", "statusText", "headers"].forEach((prop) => {
            options[prop] = response[prop];
          });
          const responseContentLength = utils$1.toFiniteNumber(response.headers.get("content-length"));
          const [onProgress, flush] = onDownloadProgress && progressEventDecorator(
            responseContentLength,
            progressEventReducer(asyncDecorator(onDownloadProgress), true)
          ) || [];
          response = new Response(
            trackStream(response.body, DEFAULT_CHUNK_SIZE, onProgress, () => {
              flush && flush();
              unsubscribe && unsubscribe();
            }),
            options
          );
        }
        responseType = responseType || "text";
        let responseData = await resolvers[utils$1.findKey(resolvers, responseType) || "text"](
          response,
          config
        );
        !isStreamResponse && unsubscribe && unsubscribe();
        return await new Promise((resolve, reject) => {
          settle(resolve, reject, {
            data: responseData,
            headers: AxiosHeaders$1.from(response.headers),
            status: response.status,
            statusText: response.statusText,
            config,
            request
          });
        });
      } catch (err) {
        unsubscribe && unsubscribe();
        if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
          throw Object.assign(
            new AxiosError$1(
              "Network Error",
              AxiosError$1.ERR_NETWORK,
              config,
              request,
              err && err.response
            ),
            {
              cause: err.cause || err
            }
          );
        }
        throw AxiosError$1.from(err, err && err.code, config, request, err && err.response);
      }
    };
  };
  const seedCache = /* @__PURE__ */ new Map();
  const getFetch = (config) => {
    let env = config && config.env || {};
    const { fetch: fetch2, Request, Response } = env;
    const seeds = [Request, Response, fetch2];
    let len = seeds.length, i = len, seed, target, map = seedCache;
    while (i--) {
      seed = seeds[i];
      target = map.get(seed);
      target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
      map = target;
    }
    return target;
  };
  getFetch();
  const knownAdapters = {
    http: httpAdapter,
    xhr: xhrAdapter,
    fetch: {
      get: getFetch
    }
  };
  utils$1.forEach(knownAdapters, (fn, value) => {
    if (fn) {
      try {
        Object.defineProperty(fn, "name", { value });
      } catch (e) {
      }
      Object.defineProperty(fn, "adapterName", { value });
    }
  });
  const renderReason = (reason) => `- ${reason}`;
  const isResolvedHandle = (adapter) => utils$1.isFunction(adapter) || adapter === null || adapter === false;
  function getAdapter$1(adapters2, config) {
    adapters2 = utils$1.isArray(adapters2) ? adapters2 : [adapters2];
    const { length } = adapters2;
    let nameOrAdapter;
    let adapter;
    const rejectedReasons = {};
    for (let i = 0; i < length; i++) {
      nameOrAdapter = adapters2[i];
      let id;
      adapter = nameOrAdapter;
      if (!isResolvedHandle(nameOrAdapter)) {
        adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
        if (adapter === void 0) {
          throw new AxiosError$1(`Unknown adapter '${id}'`);
        }
      }
      if (adapter && (utils$1.isFunction(adapter) || (adapter = adapter.get(config)))) {
        break;
      }
      rejectedReasons[id || "#" + i] = adapter;
    }
    if (!adapter) {
      const reasons = Object.entries(rejectedReasons).map(
        ([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build")
      );
      let s = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
      throw new AxiosError$1(
        `There is no suitable adapter to dispatch the request ` + s,
        "ERR_NOT_SUPPORT"
      );
    }
    return adapter;
  }
  const adapters = {
    /**
     * Resolve an adapter from a list of adapter names or functions.
     * @type {Function}
     */
    getAdapter: getAdapter$1,
    /**
     * Exposes all known adapters
     * @type {Object<string, Function|Object>}
     */
    adapters: knownAdapters
  };
  function throwIfCancellationRequested(config) {
    if (config.cancelToken) {
      config.cancelToken.throwIfRequested();
    }
    if (config.signal && config.signal.aborted) {
      throw new CanceledError$1(null, config);
    }
  }
  function dispatchRequest(config) {
    throwIfCancellationRequested(config);
    config.headers = AxiosHeaders$1.from(config.headers);
    config.data = transformData.call(config, config.transformRequest);
    if (["post", "put", "patch"].indexOf(config.method) !== -1) {
      config.headers.setContentType("application/x-www-form-urlencoded", false);
    }
    const adapter = adapters.getAdapter(config.adapter || defaults.adapter, config);
    return adapter(config).then(
      function onAdapterResolution(response) {
        throwIfCancellationRequested(config);
        response.data = transformData.call(config, config.transformResponse, response);
        response.headers = AxiosHeaders$1.from(response.headers);
        return response;
      },
      function onAdapterRejection(reason) {
        if (!isCancel$1(reason)) {
          throwIfCancellationRequested(config);
          if (reason && reason.response) {
            reason.response.data = transformData.call(
              config,
              config.transformResponse,
              reason.response
            );
            reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
          }
        }
        return Promise.reject(reason);
      }
    );
  }
  const VERSION$1 = "1.15.2";
  const validators$1 = {};
  ["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i) => {
    validators$1[type] = function validator2(thing) {
      return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
    };
  });
  const deprecatedWarnings = {};
  validators$1.transitional = function transitional(validator2, version, message) {
    function formatMessage(opt, desc) {
      return "[Axios v" + VERSION$1 + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
    }
    return (value, opt, opts) => {
      if (validator2 === false) {
        throw new AxiosError$1(
          formatMessage(opt, " has been removed" + (version ? " in " + version : "")),
          AxiosError$1.ERR_DEPRECATED
        );
      }
      if (version && !deprecatedWarnings[opt]) {
        deprecatedWarnings[opt] = true;
        console.warn(
          formatMessage(
            opt,
            " has been deprecated since v" + version + " and will be removed in the near future"
          )
        );
      }
      return validator2 ? validator2(value, opt, opts) : true;
    };
  };
  validators$1.spelling = function spelling(correctSpelling) {
    return (value, opt) => {
      console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
      return true;
    };
  };
  function assertOptions(options, schema, allowUnknown) {
    if (typeof options !== "object") {
      throw new AxiosError$1("options must be an object", AxiosError$1.ERR_BAD_OPTION_VALUE);
    }
    const keys = Object.keys(options);
    let i = keys.length;
    while (i-- > 0) {
      const opt = keys[i];
      const validator2 = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
      if (validator2) {
        const value = options[opt];
        const result = value === void 0 || validator2(value, opt, options);
        if (result !== true) {
          throw new AxiosError$1(
            "option " + opt + " must be " + result,
            AxiosError$1.ERR_BAD_OPTION_VALUE
          );
        }
        continue;
      }
      if (allowUnknown !== true) {
        throw new AxiosError$1("Unknown option " + opt, AxiosError$1.ERR_BAD_OPTION);
      }
    }
  }
  const validator = {
    assertOptions,
    validators: validators$1
  };
  const validators = validator.validators;
  let Axios$1 = class Axios {
    constructor(instanceConfig) {
      this.defaults = instanceConfig || {};
      this.interceptors = {
        request: new InterceptorManager(),
        response: new InterceptorManager()
      };
    }
    /**
     * Dispatch a request
     *
     * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
     * @param {?Object} config
     *
     * @returns {Promise} The Promise to be fulfilled
     */
    async request(configOrUrl, config) {
      try {
        return await this._request(configOrUrl, config);
      } catch (err) {
        if (err instanceof Error) {
          let dummy = {};
          Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = new Error();
          const stack = (() => {
            if (!dummy.stack) {
              return "";
            }
            const firstNewlineIndex = dummy.stack.indexOf("\n");
            return firstNewlineIndex === -1 ? "" : dummy.stack.slice(firstNewlineIndex + 1);
          })();
          try {
            if (!err.stack) {
              err.stack = stack;
            } else if (stack) {
              const firstNewlineIndex = stack.indexOf("\n");
              const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
              const stackWithoutTwoTopLines = secondNewlineIndex === -1 ? "" : stack.slice(secondNewlineIndex + 1);
              if (!String(err.stack).endsWith(stackWithoutTwoTopLines)) {
                err.stack += "\n" + stack;
              }
            }
          } catch (e) {
          }
        }
        throw err;
      }
    }
    _request(configOrUrl, config) {
      if (typeof configOrUrl === "string") {
        config = config || {};
        config.url = configOrUrl;
      } else {
        config = configOrUrl || {};
      }
      config = mergeConfig$1(this.defaults, config);
      const { transitional, paramsSerializer, headers } = config;
      if (transitional !== void 0) {
        validator.assertOptions(
          transitional,
          {
            silentJSONParsing: validators.transitional(validators.boolean),
            forcedJSONParsing: validators.transitional(validators.boolean),
            clarifyTimeoutError: validators.transitional(validators.boolean),
            legacyInterceptorReqResOrdering: validators.transitional(validators.boolean)
          },
          false
        );
      }
      if (paramsSerializer != null) {
        if (utils$1.isFunction(paramsSerializer)) {
          config.paramsSerializer = {
            serialize: paramsSerializer
          };
        } else {
          validator.assertOptions(
            paramsSerializer,
            {
              encode: validators.function,
              serialize: validators.function
            },
            true
          );
        }
      }
      if (config.allowAbsoluteUrls !== void 0) ;
      else if (this.defaults.allowAbsoluteUrls !== void 0) {
        config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
      } else {
        config.allowAbsoluteUrls = true;
      }
      validator.assertOptions(
        config,
        {
          baseUrl: validators.spelling("baseURL"),
          withXsrfToken: validators.spelling("withXSRFToken")
        },
        true
      );
      config.method = (config.method || this.defaults.method || "get").toLowerCase();
      let contextHeaders = headers && utils$1.merge(headers.common, headers[config.method]);
      headers && utils$1.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (method) => {
        delete headers[method];
      });
      config.headers = AxiosHeaders$1.concat(contextHeaders, headers);
      const requestInterceptorChain = [];
      let synchronousRequestInterceptors = true;
      this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
        if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) {
          return;
        }
        synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
        const transitional2 = config.transitional || transitionalDefaults;
        const legacyInterceptorReqResOrdering = transitional2 && transitional2.legacyInterceptorReqResOrdering;
        if (legacyInterceptorReqResOrdering) {
          requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
        } else {
          requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
        }
      });
      const responseInterceptorChain = [];
      this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
        responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
      });
      let promise;
      let i = 0;
      let len;
      if (!synchronousRequestInterceptors) {
        const chain = [dispatchRequest.bind(this), void 0];
        chain.unshift(...requestInterceptorChain);
        chain.push(...responseInterceptorChain);
        len = chain.length;
        promise = Promise.resolve(config);
        while (i < len) {
          promise = promise.then(chain[i++], chain[i++]);
        }
        return promise;
      }
      len = requestInterceptorChain.length;
      let newConfig = config;
      while (i < len) {
        const onFulfilled = requestInterceptorChain[i++];
        const onRejected = requestInterceptorChain[i++];
        try {
          newConfig = onFulfilled(newConfig);
        } catch (error) {
          onRejected.call(this, error);
          break;
        }
      }
      try {
        promise = dispatchRequest.call(this, newConfig);
      } catch (error) {
        return Promise.reject(error);
      }
      i = 0;
      len = responseInterceptorChain.length;
      while (i < len) {
        promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
      }
      return promise;
    }
    getUri(config) {
      config = mergeConfig$1(this.defaults, config);
      const fullPath = buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls);
      return buildURL(fullPath, config.params, config.paramsSerializer);
    }
  };
  utils$1.forEach(["delete", "get", "head", "options"], function forEachMethodNoData(method) {
    Axios$1.prototype[method] = function(url, config) {
      return this.request(
        mergeConfig$1(config || {}, {
          method,
          url,
          data: (config || {}).data
        })
      );
    };
  });
  utils$1.forEach(["post", "put", "patch"], function forEachMethodWithData(method) {
    function generateHTTPMethod(isForm) {
      return function httpMethod(url, data, config) {
        return this.request(
          mergeConfig$1(config || {}, {
            method,
            headers: isForm ? {
              "Content-Type": "multipart/form-data"
            } : {},
            url,
            data
          })
        );
      };
    }
    Axios$1.prototype[method] = generateHTTPMethod();
    Axios$1.prototype[method + "Form"] = generateHTTPMethod(true);
  });
  let CancelToken$1 = class CancelToken2 {
    constructor(executor) {
      if (typeof executor !== "function") {
        throw new TypeError("executor must be a function.");
      }
      let resolvePromise;
      this.promise = new Promise(function promiseExecutor(resolve) {
        resolvePromise = resolve;
      });
      const token = this;
      this.promise.then((cancel) => {
        if (!token._listeners) return;
        let i = token._listeners.length;
        while (i-- > 0) {
          token._listeners[i](cancel);
        }
        token._listeners = null;
      });
      this.promise.then = (onfulfilled) => {
        let _resolve;
        const promise = new Promise((resolve) => {
          token.subscribe(resolve);
          _resolve = resolve;
        }).then(onfulfilled);
        promise.cancel = function reject() {
          token.unsubscribe(_resolve);
        };
        return promise;
      };
      executor(function cancel(message, config, request) {
        if (token.reason) {
          return;
        }
        token.reason = new CanceledError$1(message, config, request);
        resolvePromise(token.reason);
      });
    }
    /**
     * Throws a `CanceledError` if cancellation has been requested.
     */
    throwIfRequested() {
      if (this.reason) {
        throw this.reason;
      }
    }
    /**
     * Subscribe to the cancel signal
     */
    subscribe(listener) {
      if (this.reason) {
        listener(this.reason);
        return;
      }
      if (this._listeners) {
        this._listeners.push(listener);
      } else {
        this._listeners = [listener];
      }
    }
    /**
     * Unsubscribe from the cancel signal
     */
    unsubscribe(listener) {
      if (!this._listeners) {
        return;
      }
      const index = this._listeners.indexOf(listener);
      if (index !== -1) {
        this._listeners.splice(index, 1);
      }
    }
    toAbortSignal() {
      const controller = new AbortController();
      const abort = (err) => {
        controller.abort(err);
      };
      this.subscribe(abort);
      controller.signal.unsubscribe = () => this.unsubscribe(abort);
      return controller.signal;
    }
    /**
     * Returns an object that contains a new `CancelToken` and a function that, when called,
     * cancels the `CancelToken`.
     */
    static source() {
      let cancel;
      const token = new CancelToken2(function executor(c) {
        cancel = c;
      });
      return {
        token,
        cancel
      };
    }
  };
  function spread$1(callback) {
    return function wrap(arr) {
      return callback.apply(null, arr);
    };
  }
  function isAxiosError$1(payload) {
    return utils$1.isObject(payload) && payload.isAxiosError === true;
  }
  const HttpStatusCode$1 = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511,
    WebServerIsDown: 521,
    ConnectionTimedOut: 522,
    OriginIsUnreachable: 523,
    TimeoutOccurred: 524,
    SslHandshakeFailed: 525,
    InvalidSslCertificate: 526
  };
  Object.entries(HttpStatusCode$1).forEach(([key, value]) => {
    HttpStatusCode$1[value] = key;
  });
  function createInstance(defaultConfig) {
    const context = new Axios$1(defaultConfig);
    const instance = bind(Axios$1.prototype.request, context);
    utils$1.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
    utils$1.extend(instance, context, null, { allOwnKeys: true });
    instance.create = function create(instanceConfig) {
      return createInstance(mergeConfig$1(defaultConfig, instanceConfig));
    };
    return instance;
  }
  const axios = createInstance(defaults);
  axios.Axios = Axios$1;
  axios.CanceledError = CanceledError$1;
  axios.CancelToken = CancelToken$1;
  axios.isCancel = isCancel$1;
  axios.VERSION = VERSION$1;
  axios.toFormData = toFormData$1;
  axios.AxiosError = AxiosError$1;
  axios.Cancel = axios.CanceledError;
  axios.all = function all2(promises) {
    return Promise.all(promises);
  };
  axios.spread = spread$1;
  axios.isAxiosError = isAxiosError$1;
  axios.mergeConfig = mergeConfig$1;
  axios.AxiosHeaders = AxiosHeaders$1;
  axios.formToJSON = (thing) => formDataToJSON(utils$1.isHTMLForm(thing) ? new FormData(thing) : thing);
  axios.getAdapter = adapters.getAdapter;
  axios.HttpStatusCode = HttpStatusCode$1;
  axios.default = axios;
  const {
    Axios,
    AxiosError,
    CanceledError,
    isCancel,
    CancelToken,
    VERSION,
    all,
    Cancel,
    isAxiosError,
    spread,
    toFormData,
    AxiosHeaders,
    HttpStatusCode,
    formToJSON,
    getAdapter,
    mergeConfig
  } = axios;
  async function createAuthedAxios() {
    const [token, apiBase] = await Promise.all([getAuthToken(), getApiBase()]);
    if (!token) throw new Error("NOT_AUTHENTICATED");
    const instance = axios.create({
      baseURL: apiBase,
      headers: { Authorization: `Bearer ${token}` }
    });
    instance.interceptors.response.use(void 0, async (error) => {
      const status = error?.response?.status;
      if (status === 401) {
        await clearAuthToken();
      }
      return Promise.reject(
        error instanceof Error ? error : new Error(String(error))
      );
    });
    return instance;
  }
  async function createEditorWorkerAxios() {
    const token = await getAuthToken();
    if (!token) throw new Error("NOT_AUTHENTICATED");
    const instance = axios.create({
      baseURL: EDITOR_WORKER_BASE,
      headers: { Authorization: `Bearer ${token}` }
    });
    instance.interceptors.response.use(void 0, (error) => {
      return Promise.reject(
        error instanceof Error ? error : new Error(String(error))
      );
    });
    return instance;
  }
  const EXTENSION_CANVAS_RESOURCE_UPLOAD_SCENE = "main_chat";
  async function listProjects() {
    const http = await createAuthedAxios();
    const api = new GenerateApi(http);
    const resp = await api.getProjectList();
    if (resp.code !== 0) throw new Error(resp.message ?? `API error: code ${resp.code}`);
    return resp.data;
  }
  async function getUploadPresignedURL(projectId, filename, scene = EXTENSION_CANVAS_RESOURCE_UPLOAD_SCENE) {
    const http = await createAuthedAxios();
    const api = new GenerateApi(http);
    const resp = await api.getSignedUrlWithProject({ projectId, filename, scene });
    if (resp.code !== 0) throw new Error(resp.message ?? `API error: code ${resp.code}`);
    return resp.data;
  }
  async function uploadToS3(presignedUrl, blob) {
    const resp = await fetch(presignedUrl, {
      method: "PUT",
      body: blob,
      headers: { "Content-Type": "application/octet-stream" }
    });
    if (!resp.ok) throw new Error(`S3 upload failed: ${resp.status}`);
  }
  async function notifyUploadDone(projectId, key, filename, scene = EXTENSION_CANVAS_RESOURCE_UPLOAD_SCENE) {
    const http = await createAuthedAxios();
    const api = new GenerateApi(http);
    const resp = await api.uploadFileDoneWithProject(projectId, filename, key, void 0, scene);
    if (resp.code !== 0) throw new Error(resp.message ?? `API error: code ${resp.code}`);
    return resp.data;
  }
  async function uploadFile(projectId, blob, filename) {
    const { url, key } = await getUploadPresignedURL(projectId, filename);
    await uploadToS3(url, blob);
    return notifyUploadDone(projectId, key, filename);
  }
  async function insertToCanvas(projectId, resourceId) {
    const http = await createAuthedAxios();
    const canvasApi = new CanvasApi(http);
    const canvasResp = await canvasApi.getElements(projectId);
    if (canvasResp.code !== 0) {
      return { inserted: false, reason: `canvas_api_error_${canvasResp.code}` };
    }
    const canvasId = canvasResp.data?.canvas_id;
    if (!canvasId) return { inserted: false, reason: "no_canvas_id" };
    try {
      const editorHttp = await createEditorWorkerAxios();
      const editorWorker = new EditorWorkerApi(editorHttp);
      await editorWorker.createElement(canvasId, {
        type: "image",
        resourceId,
        resourceLoading: false
      });
      return { inserted: true };
    } catch (err) {
      const status = err?.response?.status;
      return {
        inserted: false,
        reason: status ? `editor_service_${status}` : "editor_service_error"
      };
    }
  }
  async function uploadPreparedImage(projectId, asset, options = {}) {
    const resource = await uploadFile(projectId, asset.blob, asset.filename);
    let inserted = false;
    if (options.pasteToCanvas && resource.resource_id) {
      const result = await insertToCanvas(projectId, resource.resource_id);
      inserted = result.inserted;
    }
    return { resource, inserted };
  }
  const TEMP_CORS_RULE_ID = 1000001;
  let corsFetchQueue = Promise.resolve();
  const corsCleanupReady = removeTempCorsRule().catch((err) => {
    console.warn("[Framia] failed to clear stale CORS rule:", err);
  });
  async function removeTempCorsRule() {
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [],
      removeRuleIds: [TEMP_CORS_RULE_ID]
    });
  }
  function fetchCrossOrigin(url) {
    const run = () => fetchWithTempCorsRule(url);
    const next = corsFetchQueue.then(run, run);
    corsFetchQueue = next.then(
      () => void 0,
      () => void 0
    );
    return next;
  }
  async function fetchWithTempCorsRule(url) {
    await corsCleanupReady;
    const hostname = new URL(url).hostname;
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [buildTempCorsRule(hostname)],
      removeRuleIds: [TEMP_CORS_RULE_ID]
    });
    try {
      return await fetch(url);
    } finally {
      await removeTempCorsRule().catch((err) => {
        console.warn("[Framia] failed to remove CORS rule:", err);
      });
    }
  }
  function buildTempCorsRule(hostname) {
    return {
      id: TEMP_CORS_RULE_ID,
      priority: 100,
      action: {
        type: "modifyHeaders",
        responseHeaders: [
          {
            header: "access-control-allow-origin",
            operation: "set",
            value: "*"
          }
        ]
      },
      condition: {
        regexFilter: `^https?://${escapeRegex(hostname)}(?::[0-9]+)?/`,
        resourceTypes: [
          "xmlhttprequest",
          "other"
        ]
      }
    };
  }
  function escapeRegex(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  async function fetchImageAsset(srcUrl) {
    const resp = await fetchCrossOrigin(srcUrl);
    if (!resp.ok) throw new Error(`Failed to fetch image: ${resp.status}`);
    const blob = await resp.blob();
    return { blob, dataUrl: await blobToDataUrl(blob), filename: buildImageFilename(srcUrl) };
  }
  async function handleUploadBatch(items) {
    const projectId = await getBoundProjectId();
    let successCount = 0;
    let failCount = 0;
    for (const item of items) {
      try {
        let blob;
        if (item.dataUrl) {
          blob = dataUrlToBlob(item.dataUrl);
        } else if (item.url) {
          const resp = await fetchCrossOrigin(item.url);
          if (!resp.ok) {
            failCount++;
            continue;
          }
          blob = await resp.blob();
        } else {
          continue;
        }
        const filename = item.filename ?? generateFilename("batch");
        const resource = await uploadFile(projectId, blob, filename);
        if (resource.resource_id) {
          await insertToCanvas(projectId, resource.resource_id);
        }
        successCount++;
      } catch {
        failCount++;
      }
    }
    return { ok: true, successCount, failCount };
  }
  async function ensureContentScript(tabId) {
    try {
      await chrome.tabs.sendMessage(tabId, { action: "PING" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    }
  }
  function dataUrlToBlob(dataUrl) {
    const commaIdx = dataUrl.indexOf(",");
    if (commaIdx < 0) {
      throw new Error("Malformed data URL: missing comma separator");
    }
    const header = dataUrl.slice(0, commaIdx);
    const data = dataUrl.slice(commaIdx + 1);
    const mimeMatch = header.match(/^data:([^;,]+)/);
    const mime = mimeMatch?.[1] ?? "application/octet-stream";
    let binary;
    try {
      binary = atob(data);
    } catch {
      throw new Error("Malformed data URL: invalid base64 payload");
    }
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }
  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
  function generateFilename(prefix = "capture") {
    const ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
    return `${prefix}_${ts}.png`;
  }
  function buildImageFilename(srcUrl) {
    return `image_${Date.now()}.${guessExt(srcUrl)}`;
  }
  function guessExt(url) {
    try {
      const pathname = new URL(url).pathname;
      const ext = pathname.split(".").pop()?.toLowerCase();
      if (ext && ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp"].includes(ext)) return ext;
    } catch {
    }
    return "png";
  }
  const STORAGE_KEY = "extClientId";
  let cachedId = null;
  let inflight = null;
  function generateId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `cid-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  }
  async function getOrCreateClientId() {
    if (cachedId) return cachedId;
    if (inflight) return inflight;
    inflight = (async () => {
      try {
        const r = await chrome.storage.local.get(STORAGE_KEY);
        const existing = r[STORAGE_KEY];
        if (typeof existing === "string" && existing.length >= 8) {
          cachedId = existing;
          return existing;
        }
        const fresh = generateId();
        try {
          await chrome.storage.local.set({ [STORAGE_KEY]: fresh });
        } catch {
        }
        cachedId = fresh;
        return fresh;
      } finally {
        inflight = null;
      }
    })();
    return inflight;
  }
  class RateLimitError extends Error {
    constructor(limit, used, scope, resetAt, requestId) {
      super(`RATE_LIMITED scope=${scope} used=${used} limit=${limit}`);
      this.limit = limit;
      this.used = used;
      this.scope = scope;
      this.resetAt = resetAt;
      this.requestId = requestId;
      this.name = "RateLimitError";
    }
    limit;
    used;
    scope;
    resetAt;
    requestId;
    code = "RATE_LIMITED";
  }
  class PromptServiceError extends Error {
    constructor(code, message, status, requestId, details, retryable) {
      super(message);
      this.code = code;
      this.status = status;
      this.requestId = requestId;
      this.details = details;
      this.retryable = retryable;
      this.name = "PromptServiceError";
    }
    code;
    status;
    requestId;
    details;
    retryable;
  }
  async function extractPromptFromImage(dataUrl) {
    const url = `${CHROME_APP_WORKER_BASE}/image-to-prompt`;
    const [clientId, token] = await Promise.all([
      getOrCreateClientId(),
      requireAuthToken()
    ]);
    let resp;
    try {
      resp = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Client-Id": clientId,
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ dataUrl })
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      throw new PromptServiceError(
        "PROMPT_SERVICE_UNREACHABLE",
        `Prompt service is unreachable: ${reason}`,
        void 0,
        void 0,
        void 0,
        true
      );
    }
    if (resp.status === 401) {
      await clearAuthToken();
      const body = await readErrorBody(resp);
      throw new PromptServiceError(
        "NOT_AUTHENTICATED",
        body.message ?? "Not authenticated",
        401,
        typeof body.requestId === "string" ? body.requestId : void 0,
        body.details,
        false
      );
    }
    if (resp.status === 429) {
      const body = await readErrorBody(resp);
      throw new RateLimitError(
        typeof body.limit === "number" ? body.limit : 30,
        typeof body.used === "number" ? body.used : 0,
        body.scope === "ip" ? "ip" : "client",
        typeof body.resetAt === "string" ? body.resetAt : null,
        typeof body.requestId === "string" ? body.requestId : void 0
      );
    }
    if (!resp.ok) {
      throw await formatWorkerError(resp);
    }
    const payload = await resp.json();
    if (!payload.json && !payload.chinese && !payload.english) {
      throw new PromptServiceError(
        "PROMPT_SERVICE_EMPTY_RESPONSE",
        "Prompt service returned an empty response",
        502,
        void 0,
        void 0,
        true
      );
    }
    return {
      json: payload.json ?? null,
      chinese: payload.chinese ?? null,
      english: payload.english ?? null
    };
  }
  async function readErrorBody(resp) {
    try {
      return await resp.json();
    } catch {
      return {};
    }
  }
  async function formatWorkerError(resp) {
    let text = "";
    try {
      text = await resp.text();
    } catch {
    }
    if (!text) {
      return new PromptServiceError(
        `PROMPT_SERVICE_HTTP_${resp.status}`,
        `Prompt service request failed (${resp.status})`,
        resp.status,
        void 0,
        void 0,
        resp.status >= 500
      );
    }
    try {
      const payload = JSON.parse(text);
      return new PromptServiceError(
        payload.code ?? payload.error ?? `PROMPT_SERVICE_HTTP_${resp.status}`,
        payload.message ?? payload.error ?? `Prompt service request failed (${resp.status})`,
        resp.status,
        payload.requestId,
        payload.details,
        payload.retryable
      );
    } catch {
    }
    return new PromptServiceError(
      `PROMPT_SERVICE_HTTP_${resp.status}`,
      text.slice(0, 240),
      resp.status,
      void 0,
      void 0,
      resp.status >= 500
    );
  }
  function getPromptImageSizeCode(dimensions) {
    const shortEdge = Math.min(dimensions.width, dimensions.height);
    const longEdge = Math.max(dimensions.width, dimensions.height);
    const pixels = dimensions.width * dimensions.height;
    if (shortEdge < PROMPT_IMAGE_MIN_SHORT_EDGE || pixels < PROMPT_IMAGE_MIN_PIXELS) {
      return "IMAGE_TOO_SMALL";
    }
    if (longEdge > PROMPT_IMAGE_MAX_LONG_EDGE || pixels > PROMPT_IMAGE_MAX_PIXELS) {
      return "IMAGE_TOO_LARGE";
    }
    return null;
  }
  function getPromptScale(dimensions) {
    const longEdge = Math.max(dimensions.width, dimensions.height);
    const pixels = dimensions.width * dimensions.height;
    return Math.min(
      1,
      PROMPT_IMAGE_MAX_LONG_EDGE / longEdge,
      Math.sqrt(PROMPT_IMAGE_MAX_PIXELS / pixels)
    );
  }
  class PromptImageError extends Error {
    constructor(code, details) {
      super(code);
      this.code = code;
      this.details = details;
      this.name = "PromptImageError";
    }
    code;
    details;
  }
  async function prepareImageForPrompt(asset, options = {}) {
    let bitmap;
    try {
      bitmap = await createImageBitmap(asset.blob);
    } catch {
      throw new PromptImageError("INVALID_IMAGE_FORMAT", {
        mimeType: asset.blob.type || "unknown"
      });
    }
    try {
      const dimensions = { width: bitmap.width, height: bitmap.height };
      const sizeCode = getPromptImageSizeCode(dimensions);
      if (sizeCode === "IMAGE_TOO_SMALL") {
        const renderedDimensions = normalizeRenderedDimensions(options);
        if (!renderedDimensions) {
          throw new PromptImageError(sizeCode, dimensions);
        }
        return await resizeBitmapToPromptAsset(bitmap, asset.filename, renderedDimensions);
      }
      const scale = getPromptScale(dimensions);
      if (scale >= 1) return asset;
      return await resizeBitmapToPromptAsset(bitmap, asset.filename, {
        width: Math.max(1, Math.round(dimensions.width * scale)),
        height: Math.max(1, Math.round(dimensions.height * scale)),
        sourceWidth: dimensions.width,
        sourceHeight: dimensions.height
      });
    } finally {
      bitmap.close();
    }
  }
  function normalizeRenderedDimensions(options) {
    const sourceWidth = Math.round(options.renderedWidth ?? 0);
    const sourceHeight = Math.round(options.renderedHeight ?? 0);
    if (sourceWidth <= 0 || sourceHeight <= 0) return null;
    if (Math.min(sourceWidth, sourceHeight) < PROMPT_IMAGE_MIN_SHORT_EDGE || sourceWidth * sourceHeight < PROMPT_IMAGE_MIN_PIXELS) {
      return null;
    }
    const scale = Math.min(
      1,
      PROMPT_IMAGE_MAX_LONG_EDGE / Math.max(sourceWidth, sourceHeight),
      Math.sqrt(PROMPT_IMAGE_MAX_PIXELS / (sourceWidth * sourceHeight))
    );
    const width = Math.round(sourceWidth * scale);
    const height = Math.round(sourceHeight * scale);
    if (Math.min(width, height) < PROMPT_IMAGE_MIN_SHORT_EDGE || width * height < PROMPT_IMAGE_MIN_PIXELS) {
      return null;
    }
    return {
      width,
      height,
      sourceWidth,
      sourceHeight
    };
  }
  async function resizeBitmapToPromptAsset(bitmap, filename, dimensions) {
    if (typeof OffscreenCanvas === "undefined") {
      throw new PromptImageError("IMAGE_TOO_LARGE", {
        width: dimensions.sourceWidth,
        height: dimensions.sourceHeight,
        reason: "OFFSCREEN_CANVAS_UNAVAILABLE"
      });
    }
    const canvas = new OffscreenCanvas(dimensions.width, dimensions.height);
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new PromptImageError("IMAGE_TOO_LARGE", {
        width: dimensions.sourceWidth,
        height: dimensions.sourceHeight,
        reason: "CANVAS_CONTEXT_UNAVAILABLE"
      });
    }
    ctx.drawImage(bitmap, 0, 0, dimensions.width, dimensions.height);
    const blob = await canvas.convertToBlob({
      type: PROMPT_IMAGE_OUTPUT_TYPE,
      quality: PROMPT_IMAGE_OUTPUT_QUALITY
    });
    return {
      blob,
      dataUrl: await blobToDataUrl(blob),
      filename: replaceImageExtension(filename, "jpg")
    };
  }
  function replaceImageExtension(filename, ext) {
    return filename.replace(/\.[a-z0-9]+$/i, "") + `.${ext}`;
  }
  async function notifyKey(key, vars) {
    const locale = await getLocale();
    const raw = t(key, locale);
    notifyUser(vars ? format(raw, vars) : raw);
  }
  async function handleScreenshot(tab) {
    const projectId = await getBoundProjectId();
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    const filename = generateFilename("screenshot");
    const blob = dataUrlToBlob(dataUrl);
    const { inserted } = await uploadPreparedImage(
      projectId,
      { blob, filename },
      { pasteToCanvas: true }
    );
    await notifyKey(
      inserted ? "notify.screenshot_inserted" : "notify.screenshot_uploaded"
    );
    return { ok: true };
  }
  async function handleSaveImage(srcUrl) {
    const projectId = await getBoundProjectId();
    const asset = await fetchImageAsset(srcUrl);
    const { inserted } = await uploadPreparedImage(projectId, asset, { pasteToCanvas: true });
    await notifyKey(inserted ? "notify.image_inserted" : "notify.image_saved");
    return { ok: true };
  }
  async function handleSaveImageQuick(srcUrl, projectId) {
    const asset = await fetchImageAsset(srcUrl);
    const { inserted } = await uploadPreparedImage(projectId, asset, { pasteToCanvas: true });
    return { ok: true, inserted };
  }
  async function handleCollectAll(tab) {
    if (!tab.id) throw new Error("No tab id");
    await ensureContentScript(tab.id);
    const results = await chrome.tabs.sendMessage(tab.id, { action: "EXTRACT_IMAGES" });
    if (!results?.images?.length) {
      await notifyKey("notify.no_images");
      return { ok: true, count: 0 };
    }
    const items = results.images.map((url, i) => ({
      url,
      filename: `collect_${Date.now()}_${i}.png`
    }));
    const { successCount, failCount } = await handleUploadBatch(items);
    await notifyKey("notify.upload_complete", { success: successCount, fail: failCount });
    return { ok: true, count: successCount };
  }
  async function handleUploadBlob(dataUrl, filename) {
    const projectId = await getBoundProjectId();
    const blob = dataUrlToBlob(dataUrl);
    const fname = filename ?? generateFilename();
    await uploadPreparedImage(projectId, { blob, filename: fname }, { pasteToCanvas: true });
    return { ok: true };
  }
  async function handleExtractImagePrompt(srcUrl, options = {}) {
    const asset = await fetchImageAsset(srcUrl);
    try {
      const promptAsset = await prepareImageForPrompt(asset, {
        renderedWidth: options.renderedWidth,
        renderedHeight: options.renderedHeight
      });
      const extraction = await extractPromptFromImage(promptAsset.dataUrl);
      return { ok: true, ...extraction };
    } catch (err) {
      if (err instanceof RateLimitError) {
        return {
          ok: false,
          error: "RATE_LIMITED",
          limit: err.limit,
          used: err.used,
          requestId: err.requestId
        };
      }
      if (err instanceof PromptImageError) {
        return {
          ok: false,
          error: err.code,
          details: err.details
        };
      }
      if (err instanceof PromptServiceError) {
        return {
          ok: false,
          error: err.code,
          message: err.message,
          requestId: err.requestId,
          details: err.details
        };
      }
      throw err;
    }
  }
  function notifyUser(message) {
    chrome.action.setBadgeText({ text: "!" }).catch(() => {
    });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }).catch(() => {
    }), 3e3);
    chrome.runtime.sendMessage({ action: "NOTIFICATION", message }).catch(() => {
    });
  }
  async function uploadForMainChat(blob, filename) {
    const http = await createAuthedAxios();
    const api = new GenerateApi(http);
    const signed = await api.getSignedUrlWithProject({ filename, scene: "main_chat" });
    if (signed.code !== 0) {
      throw new Error(signed.message ?? `get_upload_presigned_url failed: code ${signed.code}`);
    }
    const { url, key } = signed.data;
    const put = await fetch(url, {
      method: "PUT",
      body: blob,
      headers: { "Content-Type": "application/octet-stream" }
    });
    if (!put.ok) throw new Error(`S3 upload failed: ${put.status}`);
    return { key };
  }
  async function submitImageWithPromptAsNewProject(srcUrl, prompt) {
    const trimmedPrompt = prompt.trim();
    if (!trimmedPrompt) throw new Error("Empty prompt");
    const asset = await fetchImageAsset(srcUrl);
    const { key } = await uploadForMainChat(asset.blob, asset.filename);
    const http = await createAuthedAxios();
    const api = new GenerateApi(http);
    const resp = await api.submitUserQuery({
      prompt: trimmedPrompt,
      resource: [
        {
          id: generateResourceId(),
          path: key,
          name: asset.filename,
          type: "upload"
        }
      ]
    });
    if (resp.code !== 0) {
      throw new Error(resp.message ?? `submitUserQuery failed: code ${resp.code}`);
    }
    const { project_id: projectId, thread_id: threadId } = resp.data;
    if (!projectId) throw new Error("submitUserQuery returned empty project_id");
    return { projectId, threadId };
  }
  function generateResourceId() {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return crypto.randomUUID();
    }
    return `res_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  }
  const captureTokenFromRequest = (details) => {
    const authHeader = details.requestHeaders?.find(
      (h) => h.name.toLowerCase() === "authorization"
    );
    if (!authHeader?.value?.startsWith("Bearer ")) return;
    const token = authHeader.value.slice(7);
    if (token.length <= 20) return;
    getAuthToken().then((existing) => {
      if (existing !== token) {
        saveAuthToken(token);
      }
    });
  };
  const API_URL_FILTER = {
    urls: [
      "https://api.framia.pro/*",
      "https://*.framia.pro/video/api/*",
      "https://framia.pro/video/api/*"
    ]
  };
  try {
    chrome.webRequest.onBeforeSendHeaders.addListener(captureTokenFromRequest, API_URL_FILTER, [
      "requestHeaders",
      "extraHeaders"
    ]);
  } catch {
    chrome.webRequest.onBeforeSendHeaders.addListener(captureTokenFromRequest, API_URL_FILTER, [
      "requestHeaders"
    ]);
  }
  async function rebuildContextMenus() {
    const locale = await getLocale();
    await new Promise((resolve) => chrome.contextMenus.removeAll(() => resolve()));
    chrome.contextMenus.create({
      id: "framia-save-image",
      title: t("contextMenu.save_image", locale),
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "framia-extract-prompt",
      title: t("contextMenu.extract_prompt", locale),
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "framia-vary-strong",
      title: t("contextMenu.vary_strong", locale),
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "framia-shuffle",
      title: t("contextMenu.shuffle", locale),
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "framia-custom-generate",
      title: t("contextMenu.custom_generate", locale),
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: "framia-screenshot-visible",
      title: t("contextMenu.screenshot_visible", locale),
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "framia-collect-all",
      title: t("contextMenu.collect_all", locale),
      contexts: ["page"]
    });
  }
  chrome.runtime.onInstalled.addListener(() => {
    void rebuildContextMenus();
  });
  chrome.runtime.onStartup.addListener(() => {
    void rebuildContextMenus();
  });
  onLocaleChange(() => {
    void rebuildContextMenus();
  });
  chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab) return;
    try {
      const token = await getAuthToken();
      if (!token) {
        const locale = await getLocale();
        notifyUser(t("toast.not_authenticated", locale));
        return;
      }
      if (info.menuItemId === "framia-save-image" && info.srcUrl) {
        await handleSaveImage(info.srcUrl);
      } else if (info.menuItemId === "framia-extract-prompt" && info.srcUrl) {
        await sendImageContextAction(tab, "CTX_EXTRACT_PROMPT", info.srcUrl);
      } else if ((info.menuItemId === "framia-vary-strong" || info.menuItemId === "framia-shuffle") && info.srcUrl) {
        const locale = await getLocale();
        const actionKey = info.menuItemId === "framia-vary-strong" ? "vary-strong" : "shuffle";
        const prompt = VARIATION_PROMPTS[locale][actionKey];
        const { projectId } = await submitImageWithPromptAsNewProject(info.srcUrl, prompt);
        await chrome.tabs.create({
          url: buildFramiaUrl(`/project/${encodeURIComponent(projectId)}`, "agent_submit"),
          active: true
        });
      } else if (info.menuItemId === "framia-custom-generate" && info.srcUrl) {
        await sendImageContextAction(tab, "CTX_CUSTOM_GENERATE", info.srcUrl);
      } else if (info.menuItemId === "framia-screenshot-visible") {
        await handleScreenshot(tab);
      } else if (info.menuItemId === "framia-collect-all") {
        await handleCollectAll(tab);
      }
    } catch (err) {
      notifyUser(err.message);
    }
  });
  async function sendImageContextAction(tab, action, srcUrl) {
    if (tab.id == null) throw new Error("No active tab");
    await ensureContentScript(tab.id);
    await chrome.tabs.sendMessage(tab.id, { action, srcUrl });
  }
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      handleMessage(message).then(sendResponse).catch((err) => {
        console.error("[Framia] message error:", err);
        sendResponse({ error: err.message });
      });
      return true;
    }
  );
  async function handleMessage(msg) {
    switch (msg.action) {
      case "GET_AUTH_STATUS": {
        const token = await getAuthToken();
        return { authenticated: !!token };
      }
      case "INIT_POPUP": {
        const CACHE_TTL_MS = 45e3;
        const [token, storage] = await Promise.all([
          getAuthToken(),
          chrome.storage.local.get(["boundProject", "popup_boot_cache"])
        ]);
        const authenticated = !!token;
        const boundProject = storage["boundProject"] ?? null;
        if (!authenticated) {
          const result = {
            authenticated: false,
            boundProject,
            projects: [],
            projectsError: null
          };
          return result;
        }
        const bootCache = storage["popup_boot_cache"];
        const cacheAge = bootCache?.cacheTime != null ? Date.now() - bootCache.cacheTime : Infinity;
        if (cacheAge < CACHE_TTL_MS && Array.isArray(bootCache?.projects) && bootCache.projects.length > 0) {
          const result = {
            authenticated: true,
            boundProject,
            projects: bootCache.projects,
            projectsError: null
          };
          return result;
        }
        try {
          const data = await listProjects();
          const result = {
            authenticated: true,
            boundProject,
            projects: data.projects ?? [],
            projectsError: null
          };
          return result;
        } catch (err) {
          const result = {
            authenticated: true,
            boundProject,
            projects: [],
            projectsError: err.message
          };
          return result;
        }
      }
      case "SET_AUTH_TOKEN": {
        const incoming = msg.token;
        if (typeof incoming !== "string" || incoming.length <= 20) {
          return { ok: false, error: "INVALID_TOKEN" };
        }
        const existing = await getAuthToken();
        if (existing !== incoming) {
          await saveAuthToken(incoming);
        }
        return { ok: true };
      }
      case "OPEN_LOGIN_PAGE": {
        await chrome.tabs.create({
          url: buildFramiaUrl("/", "login"),
          active: true
        });
        return { ok: true };
      }
      case "LOGOUT": {
        await clearAuthToken();
        await chrome.storage.local.remove(["boundProject", "popup_boot_cache"]);
        return { ok: true };
      }
      case "LIST_PROJECTS": {
        const data = await listProjects();
        return { projects: data.projects ?? [] };
      }
      case "BIND_PROJECT": {
        await chrome.storage.local.set({ boundProject: msg.project });
        return { ok: true };
      }
      case "GET_BOUND_PROJECT": {
        const result = await chrome.storage.local.get("boundProject");
        return { project: result["boundProject"] ?? null };
      }
      case "SCREENSHOT_VISIBLE": {
        await requireAuthToken();
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) throw new Error("No active tab");
        return handleScreenshot(tab);
      }
      case "COLLECT_ALL_IMAGES": {
        await requireAuthToken();
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) throw new Error("No active tab");
        return handleCollectAll(tab);
      }
      case "UPLOAD_IMAGE": {
        await requireAuthToken();
        const m = msg;
        return handleUploadBlob(m.dataUrl, m.filename);
      }
      case "QUICK_SAVE_IMAGE": {
        await requireAuthToken();
        const result = await chrome.storage.local.get("boundProject");
        const project = result["boundProject"];
        if (!project?.project_id) return { error: "NO_PROJECT_BOUND" };
        return handleSaveImageQuick(msg.srcUrl, project.project_id);
      }
      case "EXTRACT_IMAGE_PROMPT": {
        await requireAuthToken();
        const m = msg;
        const resp = await handleExtractImagePrompt(m.srcUrl, {
          renderedWidth: m.renderedWidth,
          renderedHeight: m.renderedHeight
        });
        return resp;
      }
      case "AGENT_SUBMIT_WITH_IMAGE": {
        await requireAuthToken();
        const m = msg;
        try {
          const { projectId } = await submitImageWithPromptAsNewProject(
            m.srcUrl,
            m.prompt
          );
          await chrome.tabs.create({
            url: buildFramiaUrl(`/project/${encodeURIComponent(projectId)}`, "agent_submit"),
            active: true
          });
          return { ok: true, projectId };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      }
      case "DROP_SAVE_IMAGE": {
        const m = msg;
        if (!m.projectId) return { ok: false, error: "NO_PROJECT" };
        const token = await getAuthToken();
        if (!token) return { ok: false, error: "NOT_AUTHENTICATED" };
        try {
          let asset;
          if (m.dataUrl) {
            const blob = dataUrlToBlob(m.dataUrl);
            asset = {
              blob,
              dataUrl: m.dataUrl,
              filename: m.filename ?? generateFilename("drop")
            };
          } else if (m.srcUrl) {
            asset = await fetchImageAsset(m.srcUrl);
            if (m.filename) asset.filename = m.filename;
          } else {
            return { ok: false, error: "NO_IMAGE" };
          }
          const { inserted } = await uploadPreparedImage(m.projectId, asset, {
            pasteToCanvas: true
          });
          return { ok: true, inserted };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      }
      case "UPLOAD_BATCH": {
        await requireAuthToken();
        return handleUploadBatch(msg.items);
      }
      default:
        return { error: "Unknown action" };
    }
  }
})();
